import Icon from "../icons.jsx";
import {
  acres,
  deadlineText,
  fmtDate,
  fmtTimeRange,
  money,
  opLabel,
  plural,
} from "../format.js";
import { FarmMap } from "../components/MapView.jsx";
import RequestCard from "../components/RequestCard.jsx";
import BookingLine from "../components/BookingLine.jsx";
import {
  Alert,
  Empty,
  PageHead,
  RiskBadge,
  SectionHead,
  Stat,
  StatusBadge,
} from "../components/ui.jsx";

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

export default function FarmerOverview({ state, api, refresh, push, go, openRequest }) {
  const { user, stats, today } = state;
  const plots = state.plots.filter((plot) => state.my_plots.includes(plot.id));
  const active = state.requests.filter((request) =>
    ["pending", "accepted", "scheduled", "rescheduled"].includes(request.status),
  );
  const atRisk = state.at_risk;
  const highRisk = atRisk.filter((request) => request.risk_level === "high");
  const upcoming = state.bookings.filter((booking) => booking.date >= today);
  const nextJob = upcoming[0] || null;
  const recent = state.requests.slice(0, 3);

  return (
    <div className="stack">
      <PageHead
        title={`${greeting()}, ${user.name.split(" ")[0]}`}
        sub={`${user.farm_name} · ${plural(plots.length, "plot")} · ${plural(active.length, "active request")}.`}
        actions={
          <>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("schedule")}>
              <Icon name="calendar" size={14} />
              My schedule
            </button>
            <button type="button" className="btn btn-primary btn-sm" onClick={() => openRequest()}>
              <Icon name="plus" size={14} />
              Request a machine
            </button>
          </>
        }
      />

      <div className="hero-card">
        <div>
          <div className="hero-eyebrow">
            <Icon name="sun" size={13} /> {fmtDate(today, { weekday: true })}
          </div>
          <h2 className="hero-title">
            {nextJob ? (
              <>
                <em>{nextJob.equipment_name}</em> is coming to {nextJob.plot_name}
              </>
            ) : (
              <>
                Your fields, <em>on schedule.</em>
              </>
            )}
          </h2>
          <p className="hero-text">
            {nextJob
              ? `${nextJob.equipment_name} from ${nextJob.owner_farm || "your neighbour"} arrives ${fmtDate(
                  nextJob.date,
                )} between ${nextJob.start_time} and ${nextJob.end_time}. The block already includes ${nextJob.travel_time} minutes of travel and 30 minutes of setup.`
              : "Send a request to a nearby owner. We rank every competing job by deadline, so the tightest window is served first — and you get a plain-English explanation for every decision."}
          </p>
          <div className="hero-actions">
            <button type="button" className="btn btn-gold btn-sm" onClick={() => openRequest()}>
              <Icon name="plus" size={14} />
              New request
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("requests")}>
              Track my requests
            </button>
          </div>
        </div>
        <div className="hero-side">
          <div className="hero-mini">
            <span className="hero-mini-ic">
              <Icon name="clock" size={15} />
            </span>
            <div>
              <strong>{nextJob ? fmtDate(nextJob.date) : "Nothing booked"}</strong>
              {nextJob ? `${nextJob.start_time}–${nextJob.end_time}` : "Send a request to start"}
            </div>
          </div>
          <div className="hero-mini">
            <span className="hero-mini-ic">
              <Icon name="alert" size={15} />
            </span>
            <div>
              <strong>{plural(atRisk.length, "tight deadline")}</strong>
              Watch the warnings below
            </div>
          </div>
          <div className="hero-mini">
            <span className="hero-mini-ic">
              <Icon name="leaf" size={15} />
            </span>
            <div>
              <strong>{acres(stats.acres)}</strong>
              Across {plural(plots.length, "plot")}
            </div>
          </div>
        </div>
      </div>

      <div className="stat-grid">
        <Stat label="My plots" value={plots.length} foot={acres(stats.acres)} icon="map" />
        <Stat
          label="Active requests"
          value={active.length}
          foot={`${stats.scheduled} scheduled · ${stats.pending} waiting`}
          icon="list"
        />
        <Stat
          label="At-risk deadlines"
          value={atRisk.length}
          foot={highRisk.length ? `${highRisk.length} need action now` : "Deadlines look comfortable"}
          icon="alert"
          variant={atRisk.length ? "warn" : ""}
        />
        <Stat
          label="Next job"
          value={nextJob ? fmtDate(nextJob.date, { short: true }) : "—"}
          foot={nextJob ? `${nextJob.equipment_name} · ${money(nextJob.cost)}` : "No upcoming booking"}
          icon="tractor"
          variant="accent"
        />
      </div>

      {atRisk.length > 0 && (
        <div className="card">
          <SectionHead
            title="Deadline warnings"
            sub="Any request without room to spare is flagged here."
            action={<RiskBadge level={highRisk.length ? "high" : "medium"}>{plural(atRisk.length, "flag")}</RiskBadge>}
          />
          <div className="list-tight">
            {atRisk.map((request) => (
              <div className={`queue-item ${request.risk_level === "high" ? "urgent" : ""}`} key={request.id}>
                <span className="queue-num" style={request.risk_level === "high" ? { background: "var(--clay)" } : undefined}>
                  !
                </span>
                <div className="grow">
                  <div className="queue-title">
                    {request.plot_name} · {opLabel(request.operation)}{" "}
                    <span className="muted small">
                      {deadlineText(request.days_left)} · {fmtDate(request.window_end)}
                    </span>
                  </div>
                  <div className="queue-sub">{request.risk_note}</div>
                </div>
                <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                  <RiskBadge level={request.risk_level} />
                  <StatusBadge status={request.status} />
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("requests")}>
                    Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="split">
        <div className="stack">
          <div className="card">
            <SectionHead
              title="Recent requests"
              sub="Status, explanation and priority notes in one place."
              action={
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("requests")}>
                  View all
                  <Icon name="chevronRight" size={13} />
                </button>
              }
            />
            {recent.length ? (
              <div className="list-tight">
                {recent.map((request) => (
                  <RequestCard
                    key={request.id}
                    request={request}
                    api={api}
                    refresh={refresh}
                    push={push}
                    role="farmer"
                    onFollowUp={(oldRequest) =>
                      openRequest({
                        plot_id: oldRequest.plot_id,
                        owner_id: oldRequest.owner_id,
                        operation: oldRequest.operation,
                        preferred_type: oldRequest.preferred_type,
                        window_start: oldRequest.window_end,
                        window_end: oldRequest.window_end,
                        followUp: true,
                      })
                    }
                  />
                ))}
              </div>
            ) : (
              <Empty
                icon="mail"
                title="No requests yet"
                text="Ask a nearby owner for a machine. You can pick a plot, an operation and a deadline."
                action={
                  <button type="button" className="btn btn-primary btn-sm" onClick={() => openRequest()}>
                    Create a request
                  </button>
                }
              />
            )}
          </div>

          <div className="card">
            <SectionHead
              title="Upcoming jobs"
              sub="Machines already booked for your plots."
              action={
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("schedule")}>
                  My schedule
                  <Icon name="chevronRight" size={13} />
                </button>
              }
            />
            {upcoming.length ? (
              <div className="list-tight">
                {upcoming.slice(0, 3).map((booking) => (
                  <BookingLine key={booking.id} booking={booking} role="farmer" />
                ))}
              </div>
            ) : (
              <Empty icon="calendar" title="No jobs booked" text="Scheduled work will show up here with times and costs." />
            )}
          </div>
        </div>

        <div className="stack sticky-side">
          <div className="card pad-sm">
            <SectionHead
              title="My fields"
              sub="Tap a pin to see the plot."
              action={
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("plots")}>
                  Manage plots
                </button>
              }
            />
            {plots.length ? (
              <FarmMap plots={state.plots} machines={state.equipment} height={230} myId={user.id} role="farmer" compact />
            ) : (
              <Empty
                icon="map"
                title="No plots yet"
                text="Add your fields with a map pin so owners can plan travel time accurately."
                action={
                  <button type="button" className="btn btn-primary btn-sm" onClick={() => go("plots")}>
                    Add a plot
                  </button>
                }
              />
            )}
          </div>

          <div className="card pad-sm">
            <SectionHead title="How the queue works" sub="Plain and fair." />
            <div className="check-list">
              <div className="check-item">
                <span className="feature-mark" style={{ background: "var(--sage)", color: "var(--green-700)", border: 0 }}>
                  <Icon name="clock" size={12} />
                </span>
                Jobs with the fewest days left are served first.
              </div>
              <div className="check-item">
                <span className="feature-mark" style={{ background: "var(--sage)", color: "var(--green-700)", border: 0 }}>
                  <Icon name="user" size={12} />
                </span>
                Equal deadlines? The request that arrived first wins.
              </div>
              <div className="check-item">
                <span className="feature-mark" style={{ background: "var(--sage)", color: "var(--green-700)", border: 0 }}>
                  <Icon name="route" size={12} />
                </span>
                Travel time and 30 minutes of setup are always reserved.
              </div>
            </div>
          </div>

          <div className="card pad-sm">
            <SectionHead
              title="Alerts"
              sub="Notifications from owners and the scheduler."
              action={
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("notifications")}>
                  Open
                </button>
              }
            />
            {state.notifications.length ? (
              <div className="list-tight">
                {state.notifications.slice(0, 3).map((notification) => (
                  <div className="queue-item" key={notification.id}>
                    <span className={`notif-kind ${notification.kind || "info"}`}>
                      <Icon name={notification.kind === "danger" ? "alert" : notification.kind === "warning" ? "alert" : "info"} size={12} />
                    </span>
                    <div className="grow">
                      <div className="queue-title">{notification.title}</div>
                      <div className="queue-sub">{notification.body}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Empty icon="bell" title="No alerts" text="Updates will appear here." />
            )}
          </div>
        </div>
      </div>

      {highRisk.length > 0 && (
        <Alert tone="warn" icon="alert" title="Next step for at-risk jobs">
          Open the request for the story and the suggested alternative. You can also send a follow-up
          request for a later window with one tap. Tightest first:{" "}
          {highRisk.slice(0, 3).map((request) => `${request.plot_name} (${deadlineText(request.days_left)})`).join(", ")}.
        </Alert>
      )}
    </div>
  );
}
