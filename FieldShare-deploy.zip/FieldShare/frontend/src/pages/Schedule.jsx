import { useEffect, useMemo, useState } from "react";
import Icon from "../icons.jsx";
import {
  addDaysISO,
  acres,
  deadlineText,
  fmtDate,
  fmtDayMonth,
  fmtTimeRange,
  money,
  opLabel,
  plural,
} from "../format.js";
import Timeline from "../components/Timeline.jsx";
import BookingLine from "../components/BookingLine.jsx";
import {
  Alert,
  Empty,
  MachineIcon,
  Modal,
  PageHead,
  RiskBadge,
  SectionHead,
  StatusBadge,
} from "../components/ui.jsx";

function timeOptions() {
  const rows = [];
  for (let minutes = 7 * 60; minutes <= 18 * 60; minutes += 15) {
    const h = String(Math.floor(minutes / 60)).padStart(2, "0");
    const m = String(minutes % 60).padStart(2, "0");
    rows.push(`${h}:${m}`);
  }
  return rows;
}

function BookingDetails({ booking, request, role, api, refresh, push, onClose }) {
  const [date, setDate] = useState(booking.date);
  const [startTime, setStartTime] = useState(booking.start_time);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [availability, setAvailability] = useState(null);

  useEffect(() => {
    setDate(booking.date);
    setStartTime(booking.start_time);
    setNote("");
    setError("");
  }, [booking.id, booking.date, booking.start_time]);

  useEffect(() => {
    if (role !== "owner") return undefined;
    let alive = true;
    api
      .availability(booking.equipment_id, date)
      .then((data) => {
        if (alive) setAvailability(data);
      })
      .catch(() => {
        if (alive) setAvailability(null);
      });
    return () => {
      alive = false;
    };
  }, [api, booking.equipment_id, date, role]);

  async function move(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const result = await api.moveBooking(booking.id, { date, start_time: startTime, note: note.trim() });
      await refresh();
      push(result.message, "success", "Booking moved");
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title={`${booking.plot_name} · ${opLabel(booking.operation)}`}
      subtitle={`${fmtDate(booking.date, { weekday: true })} · ${fmtTimeRange(booking.start_time, booking.end_time)} · ${booking.equipment_name}`}
      wide
      footer={
        <>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onClose}>
            Close
          </button>
          {role === "owner" && (
            <button type="submit" form="move-form" className="btn btn-primary btn-sm" disabled={busy}>
              <Icon name="calendar" size={13} />
              {busy ? "Checking…" : "Move booking"}
            </button>
          )}
        </>
      }
    >
      <BookingLine booking={booking} role={role} />

      {request?.priority_note && (
        <div className="explain" style={{ marginTop: 10 }}>
          <span className="explain-label">
            <Icon name="sparkles" size={11} />
            Deadline priority
          </span>
          {request.priority_note}
        </div>
      )}
      {request?.explanation && (
        <div className="explain" style={{ marginTop: 8 }}>
          <span className="explain-label">
            <Icon name="info" size={11} />
            Explanation
          </span>
          {request.explanation}
        </div>
      )}

      {role === "owner" ? (
        <form id="move-form" onSubmit={move} style={{ marginTop: 14 }}>
          <div className="section-title" style={{ fontSize: 17 }}>
            Move this job
          </div>
          <div className="section-sub">
            Travel time and setup are recalculated automatically. Clashes are refused with the exact
            reason.
          </div>
          {error && (
            <Alert tone="danger" icon="alert" title="That move clashes">
              {error}
            </Alert>
          )}
          <div className="form-grid">
            <label className="field">
              <span className="label">New date</span>
              <input
                className="input"
                type="date"
                value={date}
                onChange={(event) => setDate(event.target.value)}
                required
              />
            </label>
            <label className="field">
              <span className="label">Job start (work starts)</span>
              <select
                className="select"
                value={startTime}
                onChange={(event) => setStartTime(event.target.value)}
              >
                {timeOptions().map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
            <label className="field full">
              <span className="label">Note for the farmer (optional)</span>
              <input
                className="input"
                value={note}
                onChange={(event) => setNote(event.target.value)}
                placeholder="Example: The harvester is needed on another field in the morning."
              />
            </label>
          </div>
          <div className="hint" style={{ marginTop: 6 }}>
            Travel starts at 20 km/h from the previous job (or the machine base). The block on the
            timeline begins with travel and 30 minutes of setup.
          </div>

          {availability && (
            <div className="explain" style={{ marginTop: 10 }}>
              <span className="explain-label">
                <Icon name="calendar" size={11} />
                {availability.equipment_name} on {fmtDate(date)}
              </span>
              {availability.weather_block ? (
                <span className="text-danger">
                  Rain day: {availability.weather_block.reason} Machine work is blocked.
                </span>
              ) : availability.broken ? (
                <span className="text-danger">This machine is marked broken on that day.</span>
              ) : availability.bookings.length ? (
                <div className="list-tight" style={{ marginTop: 5 }}>
                  {availability.bookings.map((row) => (
                    <div className="row between small" key={row.id}>
                      <span>
                        {fmtTimeRange(row.start_time, row.end_time)} · {row.plot_name}
                      </span>
                      <span className="muted">{row.farmer_name}</span>
                    </div>
                  ))}
                </div>
              ) : (
                "No other bookings on this machine that day."
              )}
            </div>
          )}
        </form>
      ) : (
        <div className="rule" style={{ marginTop: 12 }}>
          Need a different day? Ask the owner from the requests page, or send a follow-up request for a
          later window. Any change is confirmed by notification.
        </div>
      )}
    </Modal>
  );
}

export default function Schedule({
  state,
  api,
  refresh,
  push,
  role,
  runOptimize,
  busy,
  openRain,
  openBreakdown,
  openRequest,
}) {
  const [days, setDays] = useState(14);
  const [includePending, setIncludePending] = useState(true);
  const [selected, setSelected] = useState(null);

  const isOwner = role === "owner";
  const myMachines = isOwner
    ? state.equipment.filter((machine) => state.my_machines.includes(machine.id))
    : state.equipment.filter((machine) =>
        state.bookings.some((booking) => booking.equipment_id === machine.id),
      );

  const machineIds = useMemo(() => new Set(myMachines.map((machine) => machine.id)), [myMachines]);
  const weather = state.weather.filter((block) => block.date >= state.today);
  const breakdowns = state.breakdowns.filter(
    (block) => machineIds.has(block.equipment_id) && block.end_date >= state.today,
  );

  const upcoming = state.bookings.filter((booking) => booking.date >= state.today);
  const dayList = Array.from({ length: Math.min(days, 30) }, (_, index) => addDaysISO(state.today, index)).filter(
    (day) => upcoming.some((booking) => booking.date === day),
  );
  const accepted = state.requests.filter((request) => request.status === "accepted").length;
  const unfulfilled = state.requests.filter((request) => request.status === "unfulfilled").length;
  const atRisk = state.at_risk;

  const selectedRequest = selected
    ? state.requests.find((request) => request.id === selected.request_id)
    : null;

  return (
    <div className="stack">
      <PageHead
        title="Schedule"
        sub={
          isOwner
            ? "One row per machine. Blocks include travel and setup, so what you see cannot clash."
            : "Your booked jobs across every machine. Times include travel and setup."
        }
        actions={
          isOwner ? (
            <>
              <button type="button" className="btn btn-ghost btn-sm" onClick={openRain}>
                <Icon name="rain" size={13} />
                Simulate rain
              </button>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => openBreakdown()}>
                <Icon name="wrench" size={13} />
                Break down machine
              </button>
              <button
                type="button"
                className="btn btn-primary btn-sm"
                onClick={() => runOptimize(includePending)}
                disabled={busy === "optimize"}
              >
                <Icon name="sparkles" size={14} />
                {busy === "optimize" ? "Optimizing…" : "Optimize schedule"}
              </button>
            </>
          ) : (
            <button type="button" className="btn btn-primary btn-sm" onClick={() => openRequest()}>
              <Icon name="plus" size={14} />
              New request
            </button>
          )
        }
      />

      {isOwner && (
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Schedule optimizer</div>
              <div className="card-sub">
                {plural(accepted, "approved request")} waiting · {plural(unfulfilled, "request")} not yet
                scheduled.
              </div>
            </div>
            <label className="check-toggle">
              <input
                type="checkbox"
                checked={includePending}
                onChange={(event) => setIncludePending(event.target.checked)}
              />
              Also auto-approve waiting requests
            </label>
          </div>
          <div className="explain">
            <span className="explain-label">
              <Icon name="sparkles" size={11} />
              The rules
            </span>
            Jobs are tried in order of <strong>fewest days left</strong> (earlier request breaks a tie).
            Each job checks work duration, travel from the previous field at 20 km/h, and 30 minutes of
            setup. If no machine fits before the deadline, the request is marked{" "}
            <strong>Not scheduled</strong> with a reason and a suggested alternative. Unaffected
            bookings are never moved by the optimizer.
          </div>
          <div className="card-actions" style={{ marginTop: 10 }}>
            <button
              type="button"
              className="btn btn-primary btn-sm"
              onClick={() => runOptimize(includePending)}
              disabled={busy === "optimize"}
            >
              <Icon name="sparkles" size={13} />
              {busy === "optimize" ? "Building the plan…" : "Run optimizer"}
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={openRain}>
              <Icon name="rain" size={13} />
              Heavy rain test
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => openBreakdown()}>
              <Icon name="wrench" size={13} />
              Breakdown test
            </button>
          </div>
        </div>
      )}

      {atRisk.length > 0 && (
        <Alert tone="warn" icon="alert" title={plural(atRisk.length, "deadline") + " need attention"}>
          {atRisk
            .slice(0, 4)
            .map((request) => `${request.plot_name} (${deadlineText(request.days_left)})`)
            .join(", ")}
          {atRisk.length > 4 ? "…" : ""}
          <div style={{ marginTop: 6 }}>
            <RiskBadge level="high" /> Open the requests page for the reason and the suggested
            alternative.
          </div>
        </Alert>
      )}

      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">Machine timeline</div>
            <div className="card-sub">Workday 7:00–19:00. Tap a block for details.</div>
          </div>
          <div className="segmented" role="group" aria-label="Timeline length">
            {[7, 14, 30].map((option) => (
              <button
                type="button"
                key={option}
                className={days === option ? "active" : ""}
                onClick={() => setDays(option)}
              >
                {option} days
              </button>
            ))}
          </div>
        </div>
        <Timeline
          bookings={state.bookings}
          machines={myMachines}
          days={days}
          today={state.today}
          weather={state.weather}
          breakdowns={state.breakdowns}
          role={role}
          onSelectBooking={setSelected}
        />
      </div>

      <div className="split">
        <div className="stack">
          <div className="card">
            <SectionHead
              title="Upcoming jobs"
              sub={isOwner ? "Grouped by day, with every buffer spelled out." : "Everything booked for your plots."}
            />
            {dayList.length ? (
              <div className="schedule-day-list">
                {dayList.map((day) => {
                  const rows = upcoming.filter((booking) => booking.date === day);
                  const rain = state.weather.find((block) => block.date === day);
                  return (
                    <div className="schedule-day" key={day}>
                      <div className="schedule-date">
                        <div className="sd-dow">
                          {new Date(`${day}T00:00:00`).toLocaleDateString(undefined, { weekday: "short" })}
                        </div>
                        <div className="sd-dom">{fmtDayMonth(day)}</div>
                        {rain && (
                          <div className="tiny" style={{ color: "var(--blue)", marginTop: 2 }}>
                            <Icon name="rain" size={10} /> rain
                          </div>
                        )}
                      </div>
                      <div>
                        {rows.map((booking) => (
                          <div className="job-row" key={booking.id}>
                            <span className="job-icon">
                              <MachineIcon type={booking.equipment_type} size={17} />
                            </span>
                            <div className="grow" style={{ minWidth: 0 }}>
                              <div className="job-title">
                                {booking.plot_name} · {opLabel(booking.operation)}
                              </div>
                              <div className="job-sub">
                                {booking.equipment_name} ·{" "}
                                {isOwner ? booking.farmer_name : booking.owner_farm || booking.owner_name}
                              </div>
                              <div className="job-sub">
                                {acres(booking.plot_area)} · {booking.travel_km} km travel ·{" "}
                                {booking.travel_time} min + {booking.setup_time} min setup ·{" "}
                                {money(booking.cost)}
                              </div>
                            </div>
                            <div style={{ textAlign: "right" }}>
                              <div className="job-time">
                                {fmtTimeRange(booking.start_time, booking.end_time)}
                              </div>
                              <button
                                type="button"
                                className="btn btn-ghost btn-sm"
                                onClick={() => setSelected(booking)}
                              >
                                Details
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <Empty
                icon="calendar"
                title="No upcoming jobs"
                text={
                  isOwner
                    ? "Approve a request and run the optimizer — new jobs land here."
                    : "Ask an owner for a machine and it will appear here once scheduled."
                }
              />
            )}
          </div>
        </div>

        <div className="stack sticky-side">
          <div className="card pad-sm">
            <SectionHead title="Disruptions" sub="Automatic re-planning, tightest deadline first." />
            {isOwner ? (
              <div className="stack-sm">
                <button type="button" className="btn btn-secondary btn-block btn-sm" onClick={openRain}>
                  <Icon name="rain" size={13} />
                  Simulate heavy rain
                </button>
                <button type="button" className="btn btn-secondary btn-block btn-sm" onClick={() => openBreakdown()}>
                  <Icon name="wrench" size={13} />
                  Break down a machine
                </button>
              </div>
            ) : (
              <div className="hint">Owners can block rain days and mark machines broken. Your jobs are re-planned automatically and you get a notification.</div>
            )}

            <div className="divider" style={{ margin: "10px 0" }} />

            {weather.length === 0 && breakdowns.length === 0 ? (
              <div className="hint">No active rain blocks or breakdowns.</div>
            ) : (
              <div className="list-tight">
                {weather.map((block) => (
                  <div className="queue-item" key={`rain-${block.id}`}>
                    <span className="notif-kind info">
                      <Icon name="rain" size={12} />
                    </span>
                    <div className="grow">
                      <div className="queue-title">Rain · {fmtDate(block.date)}</div>
                      <div className="queue-sub">{block.reason}</div>
                    </div>
                  </div>
                ))}
                {breakdowns.map((block) => {
                  const machine = state.equipment.find((item) => item.id === block.equipment_id);
                  return (
                    <div className="queue-item" key={`break-${block.id}`}>
                      <span className="notif-kind danger">
                        <Icon name="wrench" size={12} />
                      </span>
                      <div className="grow">
                        <div className="queue-title">
                          {machine?.name || "Machine"} · {fmtDate(block.start_date)}
                          {block.start_date !== block.end_date ? ` → ${fmtDate(block.end_date)}` : ""}
                        </div>
                        <div className="queue-sub">{block.note}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="card pad-sm">
            <SectionHead title="Protection rules" sub="Applied to every booking." />
            <div className="check-list">
              <div className="check-item">
                <Icon name="clock" size={13} /> Job time = acres ÷ work rate (minutes, rounded up).
              </div>
              <div className="check-item">
                <Icon name="route" size={13} /> Travel = distance ÷ 20 km/h from the previous field.
              </div>
              <div className="check-item">
                <Icon name="wrench" size={13} /> Setup = 30 minutes, reserved before work.
              </div>
              <div className="check-item">
                <Icon name="shield" size={13} /> No two jobs may overlap, including travel and setup.
              </div>
              <div className="check-item">
                <Icon name="calendar" size={13} /> Workday is 7:00–19:00; jobs cannot cross it.
              </div>
            </div>
          </div>

          <div className="card pad-sm">
            <SectionHead
              title="At-risk deadlines"
              sub="No room left before the window closes."
              action={atRisk.length ? <StatusBadge status="unfulfilled" /> : undefined}
            />
            {atRisk.length ? (
              <div className="queue">
                {atRisk.slice(0, 4).map((request) => (
                  <div className={`queue-item ${request.risk_level === "high" ? "urgent" : ""}`} key={request.id}>
                    <span className="queue-num" style={{ background: request.risk_level === "high" ? "var(--clay)" : undefined }}>
                      !
                    </span>
                    <div className="grow">
                      <div className="queue-title">
                        {request.plot_name} · {opLabel(request.operation)}
                      </div>
                      <div className="queue-sub">{request.risk_note}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="hint">Every assigned job has room before its deadline.</div>
            )}
          </div>
        </div>
      </div>

      {selected && (
        <BookingDetails
          booking={selected}
          request={selectedRequest}
          role={role}
          api={api}
          refresh={refresh}
          push={push}
          onClose={() => setSelected(null)}
        />
      )}
    </div>
  );
}
