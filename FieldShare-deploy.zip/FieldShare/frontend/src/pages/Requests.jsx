import { useMemo, useState } from "react";
import Icon from "../icons.jsx";
import { fmtDate, opLabel } from "../format.js";
import RequestCard from "../components/RequestCard.jsx";
import { Empty, PageHead, RiskBadge } from "../components/ui.jsx";

const FILTERS = [
  { key: "all", label: "All" },
  { key: "pending", label: "Waiting" },
  { key: "accepted", label: "Approved" },
  { key: "scheduled", label: "Scheduled" },
  { key: "rescheduled", label: "Rescheduled" },
  { key: "unfulfilled", label: "Not scheduled" },
  { key: "rejected", label: "Declined" },
];

export default function Requests({ state, api, refresh, push, role, runOptimize, busy, openRequest }) {
  const [filter, setFilter] = useState("all");
  const [urgentOnly, setUrgentOnly] = useState(false);

  const counts = useMemo(() => {
    const result = { all: state.requests.length };
    FILTERS.forEach((item) => {
      if (item.key !== "all") {
        result[item.key] = state.requests.filter((request) => request.status === item.key).length;
      }
    });
    return result;
  }, [state.requests]);

  const rows = useMemo(() => {
    let list = state.requests;
    if (filter !== "all") list = list.filter((request) => request.status === filter);
    if (urgentOnly) list = list.filter((request) => request.risk_level !== "low");
    if (role === "owner") {
      list = [...list].sort((a, b) =>
        a.window_end === b.window_end
          ? a.created_at.localeCompare(b.created_at)
          : a.window_end.localeCompare(b.window_end),
      );
    }
    return list;
  }, [state.requests, filter, urgentOnly, role]);

  const highRisk = state.requests.filter((request) => request.risk_level === "high" && request.status !== "rejected");

  return (
    <div className="stack">
      <PageHead
        title={role === "owner" ? "Requests" : "My requests"}
        sub={
          role === "owner"
            ? "Every request on your machines, ordered by deadline so the tightest window is on top."
            : "Follow each request from approval to the booked time. Deadlines and reasons are always explained."
        }
        actions={
          role === "owner" ? (
            <>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => setUrgentOnly((value) => !value)}
              >
                <Icon name="alert" size={13} />
                {urgentOnly ? "Show everything" : `At risk (${state.at_risk.length})`}
              </button>
              <button
                type="button"
                className="btn btn-primary btn-sm"
                onClick={() => runOptimize(true)}
                disabled={busy === "optimize"}
              >
                <Icon name="sparkles" size={14} />
                {busy === "optimize" ? "Optimizing…" : "Optimize schedule"}
              </button>
            </>
          ) : (
            <button type="button" className="btn btn-primary btn-sm" onClick={() => openRequest()}>
              <Icon name="plus" size={14} />
              New request
            </button>
          )
        }
      />

      {highRisk.length > 0 && (
        <div className="explain danger">
          <span className="explain-label">
            <Icon name="alert" size={11} />
            {highRisk.length === 1 ? "1 deadline needs attention" : `${highRisk.length} deadlines need attention`}
          </span>
          {highRisk
            .slice(0, 3)
            .map((request) => `${request.plot_name} (${opLabel(request.operation)})`)
            .join(", ")}
          {highRisk.length > 3 ? "…" : ""} — open the card to see the reason and the suggested alternative.{" "}
          <RiskBadge level="high" />
        </div>
      )}

      <div className="filter-row">
        <div className="segmented" role="tablist" aria-label="Filter requests">
          {FILTERS.map((item) => (
            <button
              type="button"
              key={item.key}
              role="tab"
              aria-selected={filter === item.key}
              className={filter === item.key ? "active" : ""}
              onClick={() => setFilter(item.key)}
            >
              {item.label}
              <span className="seg-count">{counts[item.key] ?? 0}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="stack">
        {rows.length ? (
          rows.map((request) => (
            <RequestCard
              key={request.id}
              request={request}
              api={api}
              refresh={refresh}
              push={push}
              role={role}
              onOptimize={() => runOptimize(true)}
              onFollowUp={(oldRequest) =>
                openRequest({
                  plot_id: oldRequest.plot_id,
                  owner_id: oldRequest.owner_id,
                  operation: oldRequest.operation,
                  preferred_type: oldRequest.preferred_type,
                  window_start: oldRequest.window_end,
                  window_end: oldRequest.window_end,
                  followUp: true,
                })
              }
            />
          ))
        ) : (
          <div className="card">
            <Empty
              icon={filter === "all" ? "mail" : "check"}
              title={urgentOnly ? "No at-risk requests in this view" : "Nothing in this list"}
              text={
                filter === "all"
                  ? role === "owner"
                    ? "New farmer requests will appear here as soon as they are sent."
                    : "Create a request to get a machine from a nearby owner."
                  : "Try another filter — the counts above show where the work is."
              }
              action={
                filter !== "all" || urgentOnly ? (
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    onClick={() => {
                      setFilter("all");
                      setUrgentOnly(false);
                    }}
                  >
                    Show all requests
                  </button>
                ) : role === "farmer" ? (
                  <button type="button" className="btn btn-primary btn-sm" onClick={() => openRequest()}>
                    <Icon name="plus" size={13} />
                    New request
                  </button>
                ) : undefined
              }
            />
          </div>
        )}
      </div>

      <div className="rule">
        <strong>How priority works:</strong> the request whose deadline is closest is served first, even
        if it arrived later. When two deadlines land on the same day, the earlier request is the
        tie-breaker. Travel time (distance ÷ 20 km/h) and 30 minutes of setup are always reserved, so
        no two jobs can overlap.{" "}
        <span className="muted small">Latest deadline in this view: {fmtDate(state.requests.at(-1)?.window_end || state.today)}.</span>
      </div>
    </div>
  );
}
