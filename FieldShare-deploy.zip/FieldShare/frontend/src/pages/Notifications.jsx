import { useState } from "react";
import Icon from "../icons.jsx";
import { opLabel, relativeTime } from "../format.js";
import { Empty, PageHead, StatusBadge } from "../components/ui.jsx";

const KIND_ICON = {
  success: "check",
  warning: "alert",
  danger: "alert",
  info: "info",
};

export default function Notifications({ state, api, refresh, push }) {
  const [busy, setBusy] = useState(false);
  const [unreadOnly, setUnreadOnly] = useState(false);

  const rows = unreadOnly ? state.notifications.filter((item) => !item.read) : state.notifications;

  async function markAll() {
    setBusy(true);
    try {
      await api.readAll();
      await refresh();
      push("All notifications marked as read.", "info");
    } catch (error) {
      push(error.message, "error");
    } finally {
      setBusy(false);
    }
  }

  async function markOne(notification) {
    if (notification.read) return;
    try {
      await api.readNotification(notification.id);
      await refresh();
    } catch (error) {
      push(error.message, "error");
    }
  }

  return (
    <div className="stack">
      <PageHead
        title="Notifications"
        sub="Owner decisions, reschedules, rain alerts and deadline warnings — all in plain language."
        actions={
          <>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={() => setUnreadOnly((value) => !value)}
            >
              <Icon name="filter" size={13} />
              {unreadOnly ? "Show all" : `Unread only (${state.unread})`}
            </button>
            <button type="button" className="btn btn-secondary btn-sm" onClick={markAll} disabled={busy || !state.unread}>
              <Icon name="check" size={13} />
              Mark all read
            </button>
          </>
        }
      />

      <div className="card flush">
        {rows.length ? (
          <div className="notif-list-page">
            {rows.map((notification) => {
              const request = state.requests.find((item) => item.id === notification.request_id);
              return (
                <button
                  type="button"
                  key={notification.id}
                  className={`notif-page-item ${notification.read ? "" : "unread"}`}
                  onClick={() => markOne(notification)}
                >
                  <span className={`notif-kind ${notification.kind || "info"}`}>
                    <Icon name={KIND_ICON[notification.kind] || "info"} size={14} />
                  </span>
                  <span className="grow" style={{ minWidth: 0, textAlign: "left" }}>
                    <span className="notif-page-title">
                      {notification.title}
                      {!notification.read && <span className="unread-dot" />}
                    </span>
                    <span className="notif-page-body">{notification.body}</span>
                    <span className="notif-page-foot">
                      <span>{relativeTime(notification.created_at)}</span>
                      {request && (
                        <>
                          <span className="dot-sep">·</span>
                          <span>
                            {opLabel(request.operation)} · {request.plot_name}
                          </span>
                          <StatusBadge status={request.status} />
                        </>
                      )}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        ) : (
          <Empty
            icon="bell"
            title={unreadOnly ? "No unread notifications" : "No notifications yet"}
            text={
              unreadOnly
                ? "You are all caught up. Switch back to see older updates."
                : "When an owner approves a request, rain moves a job, or a deadline gets tight, the update appears here."
            }
            action={
              unreadOnly ? (
                <button type="button" className="btn btn-secondary btn-sm" onClick={() => setUnreadOnly(false)}>
                  Show all
                </button>
              ) : undefined
            }
          />
        )}
      </div>

      <div className="rule">
        Every impacted farmer gets a personal notification when a job is approved, rescheduled,
        declined, or flagged as at risk. Tap a notification to mark it read — the bell in the header
        keeps the unread count.
      </div>
    </div>
  );
}
