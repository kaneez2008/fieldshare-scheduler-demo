import { useState } from "react";
import Icon from "../icons.jsx";
import {
  MACHINE_TYPES,
  acres,
  fmtDate,
  money,
  rateLabel,
  typeLabel,
} from "../format.js";
import { FarmMap, LocationPicker } from "../components/MapView.jsx";
import { Alert, Empty, MachineIcon, Modal, PageHead, Stat } from "../components/ui.jsx";

function NumberField({ label, value, onChange, min, step, suffix, required = true }) {
  return (
    <label className="field">
      <span className="label">{label}</span>
      <div className="input-suffix">
        <input
          className="input"
          type="number"
          min={min}
          step={step}
          value={value}
          onChange={(event) => onChange(event.target.value)}
          required={required}
        />
        {suffix && <span className="suffix">{suffix}</span>}
      </div>
    </label>
  );
}

export default function Registry({ state, api, refresh, push, role, openBreakdown, openRequest, runOptimize, busy }) {
  const isOwner = role === "owner";
  const [addOpen, setAddOpen] = useState(false);
  const [busyForm, setBusyForm] = useState(false);
  const [error, setError] = useState("");
  const [machineForm, setMachineForm] = useState(null);
  const [plotForm, setPlotForm] = useState(null);

  const machines = state.equipment.filter((machine) => state.my_machines.includes(machine.id));
  const plots = state.plots.filter((plot) => state.my_plots.includes(plot.id));

  function openAdd() {
    setError("");
    setBusyForm(false);
    const home = {
      lat: state.user.lat ?? 36.755,
      lng: state.user.lng ?? -119.76,
    };
    if (isOwner) {
      setMachineForm({
        name: "",
        type: "tractor",
        rate_type: "hourly",
        rate: "",
        work_rate: "",
        notes: "",
        ...home,
      });
    } else {
      setPlotForm({
        name: "",
        area: "",
        crop: "",
        notes: "",
        ...home,
      });
    }
    setAddOpen(true);
  }

  async function submitMachine(event) {
    event.preventDefault();
    setBusyForm(true);
    setError("");
    try {
      await api.addEquipment({
        name: machineForm.name.trim(),
        type: machineForm.type,
        rate_type: machineForm.rate_type,
        rate: Number(machineForm.rate),
        work_rate: Number(machineForm.work_rate),
        lat: Number(machineForm.lat),
        lng: Number(machineForm.lng),
        notes: machineForm.notes.trim(),
      });
      await refresh();
      push(`${machineForm.name} was added to your registry.`, "success", "Machine added");
      setAddOpen(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyForm(false);
    }
  }

  async function submitPlot(event) {
    event.preventDefault();
    setBusyForm(true);
    setError("");
    try {
      await api.addPlot({
        name: plotForm.name.trim(),
        area: Number(plotForm.area),
        crop: plotForm.crop.trim(),
        lat: Number(plotForm.lat),
        lng: Number(plotForm.lng),
        notes: plotForm.notes.trim(),
      });
      await refresh();
      push(`${plotForm.name} was added with its map location.`, "success", "Plot added");
      setAddOpen(false);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyForm(false);
    }
  }

  const brokenCount = machines.filter((machine) => machine.status === "broken").length;

  return (
    <div className="stack">
      <PageHead
        title={isOwner ? "My machines" : "My plots"}
        sub={
          isOwner
            ? "Register each machine with its work rate and base location. Travel time is measured from here."
            : "Register your fields with a map pin. Owners use the pin to plan travel time."
        }
        actions={
          <>
            {isOwner && (
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => runOptimize(true)}
                disabled={busy === "optimize"}
              >
                <Icon name="sparkles" size={13} />
                Optimize
              </button>
            )}
            <button type="button" className="btn btn-primary btn-sm" onClick={openAdd}>
              <Icon name="plus" size={14} />
              {isOwner ? "Add machine" : "Add plot"}
            </button>
          </>
        }
      />

      <div className="stat-grid">
        {isOwner ? (
          <>
            <Stat label="Machines" value={machines.length} icon="tractor" foot={brokenCount ? `${brokenCount} broken` : "All active"} variant={brokenCount ? "warn" : ""} />
            <Stat
              label="Machines ready now"
              value={machines.length - brokenCount}
              icon="check"
              foot="Available for new jobs"
            />
            <Stat
              label="Jobs on my machines"
              value={state.bookings.length}
              icon="calendar"
              foot="All time in this demo"
              variant="accent"
            />
            <Stat
              label="Fleet value"
              value={money(state.bookings.reduce((sum, booking) => sum + (booking.cost || 0), 0))}
              icon="dollar"
              foot="Estimated booked work"
            />
          </>
        ) : (
          <>
            <Stat label="Plots" value={plots.length} icon="map" foot={acres(plots.reduce((sum, plot) => sum + plot.area, 0))} />
            <Stat
              label="Requests made"
              value={state.requests.length}
              icon="mail"
              foot={`${state.requests.filter((request) => request.status === "scheduled" || request.status === "rescheduled").length} scheduled`}
            />
            <Stat
              label="At-risk deadlines"
              value={state.at_risk.length}
              icon="alert"
              foot={state.at_risk.length ? "Open requests for details" : "All comfortable"}
              variant={state.at_risk.length ? "warn" : ""}
            />
            <Stat
              label="Booked value"
              value={money(state.bookings.reduce((sum, booking) => sum + (booking.cost || 0), 0))}
              icon="dollar"
              foot="Estimated cost of scheduled jobs"
              variant="accent"
            />
          </>
        )}
      </div>

      {isOwner ? (
        machines.length ? (
          <div className="grid-3">
            {machines.map((machine) => (
              <div className={`machine-card ${machine.status === "broken" ? "broken" : ""}`} key={machine.id}>
                <div className="machine-top">
                  <span className="machine-icon">
                    <MachineIcon type={machine.type} size={22} />
                  </span>
                  <div className="grow">
                    <div className="machine-name">{machine.name}</div>
                    <div className="machine-meta">
                      <span className="spec">{typeLabel(machine.type)}</span>
                      <span className="spec">
                        <Icon name="chart" size={11} /> {machine.work_rate} ac/h
                      </span>
                    </div>
                  </div>
                  <span className={`badge tone-${machine.status === "broken" ? "red" : "green"}`}>
                    <span className="dot" />
                    {machine.status === "broken" ? "Broken" : "Active"}
                  </span>
                </div>

                <div className="machine-meta">
                  <span className="spec">
                    <Icon name="dollar" size={12} /> {money(machine.rate)} {rateLabel(machine.rate_type)}
                  </span>
                  <span className="spec">
                    <Icon name="calendar" size={12} /> {machine.bookings_count} bookings
                  </span>
                  <span className="spec">
                    <Icon name="pin" size={12} /> {machine.lat.toFixed(3)}, {machine.lng.toFixed(3)}
                  </span>
                </div>

                {machine.notes && <div className="hint">{machine.notes}</div>}

                {machine.active_breakdown && (
                  <div className="explain danger">
                    <span className="explain-label">
                      <Icon name="wrench" size={11} />
                      Broken now
                    </span>
                    {machine.active_breakdown.note} Repair until {fmtDate(machine.active_breakdown.end_date)}.
                  </div>
                )}
                {!machine.active_breakdown && machine.upcoming_breakdown && (
                  <div className="explain warn">
                    <span className="explain-label">
                      <Icon name="wrench" size={11} />
                      Upcoming repair
                    </span>
                    {fmtDate(machine.upcoming_breakdown.start_date)} → {fmtDate(machine.upcoming_breakdown.end_date)}:{" "}
                    {machine.upcoming_breakdown.note}
                  </div>
                )}

                <div className="machine-actions">
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => openBreakdown(machine.id)}>
                    <Icon name="wrench" size={12} />
                    Break down
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="card">
            <Empty
              icon="tractor"
              title="Register your first machine"
              text="Add a tractor, harvester, sprayer or seeder with its rate, work rate and base location. Farmers can then request it."
              action={
                <button type="button" className="btn btn-primary btn-sm" onClick={openAdd}>
                  <Icon name="plus" size={13} />
                  Add machine
                </button>
              }
            />
          </div>
        )
      ) : plots.length ? (
        <div className="grid-3">
          {plots.map((plot) => (
            <div className="plot-card" key={plot.id}>
              <div className="plot-visual" style={{ background: "linear-gradient(135deg,#b5cd99,#7da863)" }}>
                <span>{acres(plot.area)}</span>
              </div>
              <div>
                <div className="plot-name">{plot.name}</div>
                <div className="machine-meta" style={{ marginTop: 4 }}>
                  <span className="spec">
                    <Icon name="wheat" size={12} /> {plot.crop}
                  </span>
                  <span className="spec">
                    <Icon name="mail" size={12} /> {plot.requests_count} requests
                  </span>
                </div>
              </div>
              <div className="machine-meta">
                <span className="spec">
                  <Icon name="pin" size={12} /> {plot.lat.toFixed(3)}, {plot.lng.toFixed(3)}
                </span>
              </div>
              {plot.notes && <div className="hint">{plot.notes}</div>}
              <div className="machine-actions">
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => openRequest({ plot_id: plot.id })}
                >
                  <Icon name="plus" size={12} />
                  Request work
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card">
          <Empty
            icon="map"
            title="Add your fields"
            text="Plot locations let owners calculate travel time to your field, which is reserved in every booking."
            action={
              <button type="button" className="btn btn-primary btn-sm" onClick={openAdd}>
                <Icon name="plus" size={13} />
                Add plot
              </button>
            }
          />
        </div>
      )}

      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">{isOwner ? "Machine locations" : "Plot locations"}</div>
            <div className="card-sub">Green pins are farm plots, clay pins are machine bases.</div>
          </div>
        </div>
        <FarmMap
          plots={state.plots}
          machines={state.equipment}
          myId={state.user.id}
          role={role}
          height={300}
        />
      </div>

      <Modal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        wide
        title={isOwner ? "Add a machine" : "Add a plot"}
        subtitle={isOwner ? "Tell farmers what the machine can do and where it lives." : "Pin the field so travel time is calculated correctly."}
        footer={
          <>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setAddOpen(false)}>
              Cancel
            </button>
            <button
              type="submit"
              form={isOwner ? "machine-form" : "plot-form"}
              className="btn btn-primary btn-sm"
              disabled={busyForm}
            >
              {busyForm ? "Saving…" : isOwner ? "Add machine" : "Add plot"}
            </button>
          </>
        }
      >
        {error && (
          <Alert tone="danger" icon="alert" title="Could not save">
            {error}
          </Alert>
        )}

        {isOwner && machineForm && (
          <form id="machine-form" onSubmit={submitMachine}>
            <div className="form-grid">
              <label className="field full">
                <span className="label">Machine name</span>
                <input
                  className="input"
                  value={machineForm.name}
                  onChange={(event) => setMachineForm({ ...machineForm, name: event.target.value })}
                  placeholder="Example: Green Giant"
                  required
                />
              </label>
              <label className="field">
                <span className="label">Type</span>
                <select
                  className="select"
                  value={machineForm.type}
                  onChange={(event) => setMachineForm({ ...machineForm, type: event.target.value })}
                >
                  {Object.keys(MACHINE_TYPES).map((type) => (
                    <option key={type} value={type}>
                      {typeLabel(type)}
                    </option>
                  ))}
                </select>
              </label>
              <div className="field">
                <span className="label">Price basis</span>
                <div className="segmented">
                  {["hourly", "per_acre"].map((option) => (
                    <button
                      type="button"
                      key={option}
                      className={machineForm.rate_type === option ? "active" : ""}
                      onClick={() => setMachineForm({ ...machineForm, rate_type: option })}
                    >
                      {rateLabel(option)}
                    </button>
                  ))}
                </div>
              </div>
              <NumberField
                label={machineForm.rate_type === "hourly" ? "Rate per hour ($)" : "Rate per acre ($)"}
                value={machineForm.rate}
                min="1"
                step="0.5"
                onChange={(value) => setMachineForm({ ...machineForm, rate: value })}
              />
              <NumberField
                label="Work rate (acres per hour)"
                value={machineForm.work_rate}
                min="0.1"
                step="0.1"
                onChange={(value) => setMachineForm({ ...machineForm, work_rate: value })}
              />
              <label className="field full">
                <span className="label">Notes for farmers (optional)</span>
                <input
                  className="input"
                  value={machineForm.notes}
                  onChange={(event) => setMachineForm({ ...machineForm, notes: event.target.value })}
                  placeholder="Example: Comes with a 6 m header."
                />
              </label>
              <div className="field full">
                <span className="label">Base location — click the map</span>
                <LocationPicker
                  value={{ lat: machineForm.lat, lng: machineForm.lng }}
                  onChange={(point) => setMachineForm({ ...machineForm, lat: point.lat, lng: point.lng })}
                />
              </div>
            </div>
            <div className="rule" style={{ marginTop: 10 }}>
              Job time is calculated as <strong>plot acres ÷ work rate</strong>, then rounded up to 5
              minutes. Travel is added separately at 20 km/h, plus 30 minutes of setup.
            </div>
          </form>
        )}

        {!isOwner && plotForm && (
          <form id="plot-form" onSubmit={submitPlot}>
            <div className="form-grid">
              <label className="field full">
                <span className="label">Plot name</span>
                <input
                  className="input"
                  value={plotForm.name}
                  onChange={(event) => setPlotForm({ ...plotForm, name: event.target.value })}
                  placeholder="Example: North 40"
                  required
                />
              </label>
              <NumberField
                label="Area (acres)"
                value={plotForm.area}
                min="0.1"
                step="0.1"
                onChange={(value) => setPlotForm({ ...plotForm, area: value })}
              />
              <label className="field">
                <span className="label">Crop</span>
                <input
                  className="input"
                  value={plotForm.crop}
                  onChange={(event) => setPlotForm({ ...plotForm, crop: event.target.value })}
                  placeholder="Example: Corn"
                  required
                />
              </label>
              <label className="field full">
                <span className="label">Notes (optional)</span>
                <input
                  className="input"
                  value={plotForm.notes}
                  onChange={(event) => setPlotForm({ ...plotForm, notes: event.target.value })}
                  placeholder="Example: Soft ground near the creek."
                />
              </label>
              <div className="field full">
                <span className="label">Plot location — click the map</span>
                <LocationPicker
                  value={{ lat: plotForm.lat, lng: plotForm.lng }}
                  onChange={(point) => setPlotForm({ ...plotForm, lat: point.lat, lng: point.lng })}
                />
              </div>
            </div>
            <div className="rule" style={{ marginTop: 10 }}>
              The pin is used for travel distance. A misplaced pin means a wrong travel buffer, so zoom in
              before clicking.
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}
