import Icon from "../icons.jsx";
import {
  acres,
  deadlineText,
  fmtDate,
  fmtTimeRange,
  money,
  opLabel,
  plural,
  relativeTime,
} from "../format.js";
import { FarmMap } from "../components/MapView.jsx";
import RequestCard from "../components/RequestCard.jsx";
import {
  Alert,
  Empty,
  MachineIcon,
  PageHead,
  RiskBadge,
  SectionHead,
  Stat,
  StatusBadge,
} from "../components/ui.jsx";

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function UpcomingJobs({ bookings, limit = 3 }) {
  if (!bookings.length) {
    return (
      <Empty
        icon="calendar"
        title="No upcoming jobs"
        text="Approve a request and run the optimizer to fill the calendar."
      />
    );
  }
  return (
    <div className="list-tight">
      {bookings.slice(0, limit).map((booking) => (
        <div className="job-row" key={booking.id}>
          <span className="job-icon">
            <MachineIcon type={booking.equipment_type} size={17} />
          </span>
          <div className="grow" style={{ minWidth: 0 }}>
            <div className="job-title">
              {booking.plot_name} · {opLabel(booking.operation)}
            </div>
            <div className="job-sub">
              {booking.equipment_name} · {booking.farmer_name}
            </div>
            <div className="job-sub">
              {fmtDate(booking.date, { weekday: true })} · {acres(booking.plot_area)} ·{" "}
              {booking.travel_km} km travel
            </div>
          </div>
          <div className="job-time">
            {fmtTimeRange(booking.start_time, booking.end_time)}
            <div className="job-sub" style={{ textAlign: "right" }}>
              {money(booking.cost)}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function OwnerOverview({ state, api, refresh, push, go, runOptimize, busy, openRain, openBreakdown, openRequest }) {
  const { user, stats, today } = state;
  const myMachines = state.equipment.filter((machine) => state.my_machines.includes(machine.id));
  const pending = state.requests.filter((request) => request.status === "pending");
  const queue = state.requests
    .filter((request) => ["pending", "accepted", "unfulfilled"].includes(request.status))
    .sort((a, b) => (a.window_end + a.created_at).localeCompare(b.window_end + b.created_at));
  const atRisk = state.at_risk.filter((request) => request.risk_level === "high");
  const upcoming = state.bookings.filter((booking) => booking.date >= today);
  const rainDays = state.weather.filter((block) => block.date >= today);
  const active = myMachines.filter((machine) => machine.status !== "broken").length;
  const nextJob = stats.next_job;

  return (
    <div className="stack">
      <PageHead
        title={`${greeting()}, ${user.name.split(" ")[0]}`}
        sub={`${user.farm_name} · ${plural(pending.length, "request")} waiting, ${plural(upcoming.length, "booked job")} ahead.`}
        actions={
          <>
            <button type="button" className="btn btn-ghost btn-sm" onClick={openRain}>
              <Icon name="rain" size={14} />
              Simulate rain
            </button>
            <button type="button" className="btn btn-primary btn-sm" onClick={() => runOptimize(true)} disabled={busy === "optimize"}>
              <Icon name="sparkles" size={14} />
              {busy === "optimize" ? "Optimizing…" : "Optimize schedule"}
            </button>
          </>
        }
      />

      <div className="hero-card">
        <div>
          <div className="hero-eyebrow">
            <Icon name="sun" size={13} /> {fmtDate(today, { weekday: true })}
          </div>
          <h2 className="hero-title">
            {nextJob ? (
              <>
                Next up: <em>{nextJob.plot_name}</em>
              </>
            ) : (
              <>
                Your fleet is <em>ready.</em>
              </>
            )}
          </h2>
          <p className="hero-text">
            {nextJob
              ? `${nextJob.equipment_name} heads to ${nextJob.plot_name} for ${nextJob.farmer_name} on ${fmtDate(nextJob.date)} at ${nextJob.start_time}. Travel and setup are already built into the block, so the timeline keeps everyone clash-free.`
              : "No jobs booked yet. Approve incoming requests, then let the optimizer fit them around travel time, rain days and each farmer's deadline."}
          </p>
          <div className="hero-actions">
            <button type="button" className="btn btn-gold btn-sm" onClick={() => go("schedule")}>
              <Icon name="calendar" size={14} />
              Open schedule
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("requests")}>
              Review {plural(pending.length, "request")}
            </button>
          </div>
        </div>
        <div className="hero-side">
          <div className="hero-mini">
            <span className="hero-mini-ic">
              <Icon name="wrench" size={15} />
            </span>
            <div>
              <strong>
                {active}/{myMachines.length} ready
              </strong>
              Machines available today
            </div>
          </div>
          <div className="hero-mini">
            <span className="hero-mini-ic">
              <Icon name="rain" size={15} />
            </span>
            <div>
              <strong>{plural(rainDays.length, "rain day")}</strong>
              Blocked in the next weeks
            </div>
          </div>
          <div className="hero-mini">
            <span className="hero-mini-ic">
              <Icon name="alert" size={15} />
            </span>
            <div>
              <strong>{plural(atRisk.length, "tight deadline")}</strong>
              Needs attention now
            </div>
          </div>
        </div>
      </div>

      <div className="stat-grid">
        <Stat
          label="Machines"
          value={`${active}/${myMachines.length}`}
          foot={stats.broken_machines ? `${stats.broken_machines} broken` : "All active"}
          icon="tractor"
          variant={stats.broken_machines ? "warn" : ""}
        />
        <Stat label="Requests waiting" value={pending.length} foot={`${stats.accepted} approved, not timed`} icon="mail" />
        <Stat
          label="At-risk deadlines"
          value={stats.at_risk}
          foot={stats.at_risk ? "Tight or unassigned" : "All deadlines comfortable"}
          icon="alert"
          variant={stats.at_risk ? "warn" : ""}
        />
        <Stat
          label="Work booked"
          value={`${stats.booked_hours} h`}
          foot={`${stats.travel_km} km travel · ${money(stats.value)} value`}
          icon="chart"
          variant="accent"
        />
      </div>

      <div className="split">
        <div className="stack">
          <div className="card">
            <SectionHead
              title="Incoming requests"
              sub="Approve first, then let the optimizer assign machines by deadline."
              action={
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("requests")}>
                  View all
                  <Icon name="chevronRight" size={13} />
                </button>
              }
            />
            {pending.length ? (
              <div className="list-tight">
                {pending.slice(0, 2).map((request) => (
                  <RequestCard
                    key={request.id}
                    request={request}
                    api={api}
                    refresh={refresh}
                    push={push}
                    role="owner"
                    onOptimize={() => runOptimize(true)}
                  />
                ))}
              </div>
            ) : (
              <Empty
                icon="check"
                title="No requests waiting"
                text="New farmer requests will appear here with the deadline clearly marked."
              />
            )}
          </div>

          <div className="card">
            <SectionHead
              title="Next jobs"
              sub="Blocks include travel time and 30 minutes of setup."
              action={
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("schedule")}>
                  Timeline
                  <Icon name="chevronRight" size={13} />
                </button>
              }
            />
            <UpcomingJobs bookings={upcoming} />
          </div>

          <div className="card">
            <SectionHead
              title="Your machines"
              sub="Mark a machine broken to trigger automatic re-planning."
              action={
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("machines")}>
                  Manage
                  <Icon name="chevronRight" size={13} />
                </button>
              }
            />
            {myMachines.length ? (
              <div className="list-tight">
                {myMachines.map((machine) => (
                  <div className="queue-item" key={machine.id}>
                    <span className="hero-mini-ic" style={{ width: 30, height: 30 }}>
                      <MachineIcon type={machine.type} size={15} />
                    </span>
                    <div className="grow">
                      <div className="queue-title">
                        {machine.name}{" "}
                        {machine.status === "broken" ? (
                          <span className="badge tone-red">
                            <span className="dot" />
                            Broken
                          </span>
                        ) : (
                          <span className="badge tone-green">
                            <span className="dot" />
                            Active
                          </span>
                        )}
                      </div>
                      <div className="queue-sub">
                        {machine.work_rate} acres/hour · {machine.bookings_count} bookings ·{" "}
                        {money(machine.rate)} {machine.rate_type === "per_acre" ? "per acre" : "per hour"}
                      </div>
                    </div>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => openBreakdown(machine.id)}>
                      <Icon name="wrench" size={12} />
                      Break down
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <Empty
                icon="tractor"
                title="No machines yet"
                text="Add your first machine with its location to start taking requests."
                action={
                  <button type="button" className="btn btn-primary btn-sm" onClick={() => go("machines")}>
                    Add a machine
                  </button>
                }
              />
            )}
          </div>
        </div>

        <div className="stack sticky-side">
          <div className="card pad-sm">
            <SectionHead title="Deadline priority" sub="Fewest days left goes first." />
            {queue.length ? (
              <div className="queue">
                {queue.slice(0, 6).map((request, index) => (
                  <button
                    type="button"
                    className={`queue-item ${request.days_left <= 3 ? "urgent" : ""}`}
                    key={request.id}
                    onClick={() => go("requests")}
                    style={{ textAlign: "left", cursor: "pointer" }}
                  >
                    <span className="queue-num">{index + 1}</span>
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="queue-title" style={{ display: "block" }}>
                        {request.plot_name} · {opLabel(request.operation)}
                      </span>
                      <span className="queue-sub" style={{ display: "block" }}>
                        {request.farmer_name} · {deadlineText(request.days_left)} ·{" "}
                        {fmtDate(request.window_end)}
                      </span>
                    </span>
                    <StatusBadge status={request.status} />
                  </button>
                ))}
              </div>
            ) : (
              <Empty icon="check" title="Queue is clear" text="Nothing is waiting for a machine." />
            )}
            <div className="rule" style={{ marginTop: 10 }}>
              <strong>Rule:</strong> tightest deadline first. If two deadlines fall on the same day, the
              request that arrived earlier wins the tie.
            </div>
          </div>

          {atRisk.length > 0 && (
            <div className="card pad-sm">
              <SectionHead title="At-risk deadlines" sub="These need action." />
              <div className="list-tight">
                {atRisk.slice(0, 3).map((request) => (
                  <button
                    type="button"
                    className="queue-item urgent"
                    key={request.id}
                    onClick={() => go("requests")}
                    style={{ textAlign: "left", cursor: "pointer" }}
                  >
                    <span className="queue-num" style={{ background: "var(--clay)" }}>
                      !
                    </span>
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="queue-title" style={{ display: "block" }}>
                        {request.plot_name} · {opLabel(request.operation)}
                      </span>
                      <span className="queue-sub" style={{ display: "block" }}>
                        {request.risk_note}
                      </span>
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="card pad-sm">
            <SectionHead
              title="Farms nearby"
              sub="Plot and machine locations around you."
              action={
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => go("map")}>
                  Bigger map
                </button>
              }
            />
            <FarmMap plots={state.plots} machines={state.equipment} height={230} myId={user.id} role="owner" compact />
          </div>
        </div>
      </div>

      {atRisk.length > 0 && (
        <Alert tone="warn" icon="alert" title={`${plural(atRisk.length, "deadline")} at risk`}>
          Tight deadlines: {atRisk.slice(0, 3).map((request) => request.plot_name).join(", ")}. Open the
          requests list to see the reason and the suggested alternatives.
          <div style={{ marginTop: 6 }}>
            <RiskBadge level="high" />
            <span className="muted small" style={{ marginLeft: 6 }}>
              Updated {relativeTime(new Date().toISOString())}
            </span>
          </div>
        </Alert>
      )}
    </div>
  );
}
