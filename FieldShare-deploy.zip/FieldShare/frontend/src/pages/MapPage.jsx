import Icon from "../icons.jsx";
import { acres, fmtDate, money, rateLabel, typeLabel } from "../format.js";
import { FarmMap } from "../components/MapView.jsx";
import { MachineIcon, PageHead, SectionHead } from "../components/ui.jsx";

export default function MapPage({ state, role }) {
  const plots = [...state.plots].sort((a, b) => a.name.localeCompare(b.name));
  const machines = [...state.equipment].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className="stack">
      <PageHead
        title="Farm map"
        sub="Every plot and machine base in this cooperative. Pins come from the registry, and the same coordinates drive travel time."
      />

      <div className="split">
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Plots and machines</div>
              <div className="card-sub">
                {plots.length} plots · {machines.length} machines · OpenStreetMap
              </div>
            </div>
            <span className="chip">
              <Icon name="pin" size={12} /> Click a pin
            </span>
          </div>
          <FarmMap plots={state.plots} machines={state.equipment} myId={state.user.id} role={role} height={520} />
        </div>

        <div className="stack">
          <div className="card pad-sm">
            <SectionHead title="Farm plots" sub="Green pins. Yours are darker." />
            <div className="list-tight">
              {plots.map((plot) => (
                <div className="queue-item" key={plot.id}>
                  <span className="notif-kind success">
                    <Icon name="leaf" size={12} />
                  </span>
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="queue-title">
                      {plot.name}
                      {plot.farmer_id === state.user.id && <span className="badge tone-green" style={{ marginLeft: 6 }}>Yours</span>}
                    </div>
                    <div className="queue-sub">
                      {plot.crop} · {acres(plot.area)} · {plot.farmer_farm || plot.farmer_name}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card pad-sm">
            <SectionHead title="Machines" sub="Clay pins. Broken machines turn red." />
            <div className="list-tight">
              {machines.map((machine) => (
                <div className="queue-item" key={machine.id}>
                  <span className={`notif-kind ${machine.status === "broken" ? "danger" : "warning"}`}>
                    <MachineIcon type={machine.type} size={13} />
                  </span>
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="queue-title">
                      {machine.name}
                      {machine.owner_id === state.user.id && (
                        <span className="badge tone-green" style={{ marginLeft: 6 }}>
                          Yours
                        </span>
                      )}
                    </div>
                    <div className="queue-sub">
                      {typeLabel(machine.type)} · {machine.work_rate} ac/h · {money(machine.rate)}{" "}
                      {rateLabel(machine.rate_type)} · {machine.owner_farm}
                    </div>
                    {machine.active_breakdown && (
                      <div className="queue-sub text-danger">
                        Broken until {fmtDate(machine.active_breakdown.end_date)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rule">
            <strong>Travel time:</strong> each job reserves the straight-line (Haversine) distance from
            the previous field to this plot, driven at 20 km/h. A pin dropped in the wrong place creates
            a wrong buffer — update it in the registry if a field moves.
          </div>
        </div>
      </div>
    </div>
  );
}
