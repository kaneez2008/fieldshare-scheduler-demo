const TOKEN_KEY = "fieldshare.token";

export function getStoredToken() {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function storeToken(token) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* storage can be blocked; session still works in memory */
  }
}

export class ApiError extends Error {
  constructor(message, status, payload) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.payload = payload;
  }
}

export function createApi(token, onAuthError) {
  async function request(path, { method = "GET", body } = {}) {
    const headers = { Accept: "application/json" };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (token) headers.Authorization = `Bearer ${token}`;
    let response;
    try {
      response = await fetch(`/api${path}`, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch {
      throw new ApiError("Cannot reach the server. Check that the backend is running.", 0, null);
    }
    let data = null;
    const text = await response.text();
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = { detail: text };
      }
    }
    if (response.status === 401) {
      onAuthError?.();
      throw new ApiError(data?.detail || "Your session has expired.", 401, data);
    }
    if (!response.ok) {
      const detail = data?.detail;
      const message =
        typeof detail === "string"
          ? detail
          : Array.isArray(detail)
            ? detail.map((d) => d.msg).join(", ")
            : "Something went wrong. Please try again.";
      throw new ApiError(message, response.status, data);
    }
    return data;
  }

  return {
    request,
    state: () => request("/state"),
    login: (email, password) => request("/auth/login", { method: "POST", body: { email, password } }),
    demoLogin: (role, userId) =>
      request("/auth/demo", { method: "POST", body: { role, user_id: userId || null } }),
    logout: () => request("/auth/logout", { method: "POST" }),
    addEquipment: (payload) => request("/equipment", { method: "POST", body: payload }),
    updateEquipment: (id, payload) => request(`/equipment/${id}`, { method: "PATCH", body: payload }),
    addPlot: (payload) => request("/plots", { method: "POST", body: payload }),
    createRequest: (payload) => request("/requests", { method: "POST", body: payload }),
    acceptRequest: (id) => request(`/requests/${id}/accept`, { method: "POST", body: {} }),
    rejectRequest: (id, reason) =>
      request(`/requests/${id}/reject`, { method: "POST", body: { reason } }),
    optimize: (includePending = true) =>
      request("/optimize", { method: "POST", body: { include_pending: includePending } }),
    moveBooking: (id, payload) => request(`/bookings/${id}/move`, { method: "POST", body: payload }),
    simulateRain: (payload) => request("/disruptions/rain", { method: "POST", body: payload }),
    simulateBreakdown: (payload) =>
      request("/disruptions/breakdown", { method: "POST", body: payload }),
    readAll: () => request("/notifications/read-all", { method: "POST", body: {} }),
    readNotification: (id) => request(`/notifications/${id}/read`, { method: "POST", body: {} }),
    resetDemo: () => request("/demo/reset", { method: "POST", body: {} }),
    availability: (id, day) => request(`/equipment/${id}/availability?date=${day}`),
    demoAccounts: () => request("/demo/accounts"),
  };
}
