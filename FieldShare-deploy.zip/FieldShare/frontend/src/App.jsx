import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Icon from "./icons.jsx";
import { ApiError, createApi, getStoredToken, storeToken } from "./api.js";
import { Avatar, Brand, Modal, Toasts, useToasts } from "./components/ui.jsx";
import Login from "./components/Login.jsx";
import NotificationBell from "./components/NotificationBell.jsx";
import OptimizeResultModal from "./components/OptimizeResultModal.jsx";
import { BreakdownDialog, RainDialog } from "./components/Disruptions.jsx";
import RequestFormModal from "./components/RequestFormModal.jsx";
import OwnerOverview from "./pages/OwnerOverview.jsx";
import FarmerOverview from "./pages/FarmerOverview.jsx";
import Requests from "./pages/Requests.jsx";
import Schedule from "./pages/Schedule.jsx";
import Registry from "./pages/Registry.jsx";
import MapPage from "./pages/MapPage.jsx";
import Notifications from "./pages/Notifications.jsx";

const OWNER_NAV = [
  { key: "overview", label: "Overview", icon: "dashboard" },
  { key: "requests", label: "Requests", icon: "list" },
  { key: "schedule", label: "Schedule", icon: "calendar" },
  { key: "machines", label: "Machines", icon: "tractor" },
  { key: "map", label: "Map", icon: "map" },
];

const FARMER_NAV = [
  { key: "overview", label: "Overview", icon: "dashboard" },
  { key: "requests", label: "My requests", icon: "list" },
  { key: "schedule", label: "Schedule", icon: "calendar" },
  { key: "plots", label: "My plots", icon: "map" },
  { key: "map", label: "Map", icon: "pin" },
];

function Boot({ error, onRetry, onSignOut }) {
  if (error) {
    return (
      <div className="boot boot-error">
        <span className="brand-mark">
          <Icon name="leaf" size={23} />
        </span>
        <h1 style={{ color: "var(--green-950)", fontSize: 26 }}>Cannot load FieldShare</h1>
        <p>{error}</p>
        <div className="row" style={{ gap: 8 }}>
          <button type="button" className="btn btn-primary btn-sm" onClick={onRetry}>
            <Icon name="refresh" size={13} />
            Try again
          </button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onSignOut}>
            Sign in again
          </button>
        </div>
      </div>
    );
  }
  return (
    <div className="boot">
      <span className="brand-mark">
        <Icon name="leaf" size={23} />
      </span>
      <Brand subtitle={false} />
      <p>Loading the farm schedule…</p>
    </div>
  );
}

export default function App() {
  const [token, setToken] = useState(() => getStoredToken());
  const [state, setState] = useState(null);
  const [booting, setBooting] = useState(true);
  const [bootError, setBootError] = useState("");
  const [bootKey, setBootKey] = useState(0);
  const [page, setPage] = useState("overview");
  const [menuOpen, setMenuOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [optResult, setOptResult] = useState(null);
  const [optimizing, setOptimizing] = useState(false);
  const [rainOpen, setRainOpen] = useState(false);
  const [breakdown, setBreakdown] = useState(null);
  const [requestOpen, setRequestOpen] = useState(false);
  const [requestDefaults, setRequestDefaults] = useState({});
  const menuRef = useRef(null);
  const { toasts, push, dismiss } = useToasts();

  const api = useMemo(
    () =>
      createApi(token, () => {
        storeToken(null);
        setToken(null);
        setState(null);
        setBootError("Your session ended. Choose a demo account to sign in again.");
        setBooting(false);
      }),
    [token],
  );

  useEffect(() => {
    let alive = true;
    if (!token) {
      setBooting(false);
      return () => {
        alive = false;
      };
    }
    setBooting(true);
    setBootError("");
    api
      .state()
      .then((data) => {
        if (alive) {
          setState(data);
          setBootError("");
        }
      })
      .catch((error) => {
        if (!alive) return;
        if (error.status !== 401) setBootError(error.message || "Something went wrong while loading your farm.");
      })
      .finally(() => {
        if (alive) setBooting(false);
      });
    return () => {
      alive = false;
    };
  }, [api, token, bootKey]);

  useEffect(() => {
    if (!menuOpen) return undefined;
    const close = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) setMenuOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [menuOpen]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [page]);

  const refresh = useCallback(async () => {
    try {
      const data = await api.state();
      setState(data);
      return data;
    } catch (error) {
      if (error.status !== 401) push(error.message, "error");
      return null;
    }
  }, [api, push]);

  const go = useCallback((next) => {
    setPage(next);
    setMenuOpen(false);
  }, []);

  const signOut = useCallback(async () => {
    try {
      await api.logout();
    } catch {
      /* local sign-out still works */
    }
    storeToken(null);
    setToken(null);
    setState(null);
    setPage("overview");
    setBootError("");
    setBooting(false);
  }, [api]);

  function onAuth(nextToken) {
    storeToken(nextToken);
    setState(null);
    setBootError("");
    setPage("overview");
    setBooting(true);
    setToken(nextToken);
  }

  async function runOptimize(includePending = true) {
    setOptimizing(true);
    try {
      const result = await api.optimize(includePending);
      setOptResult(result);
      await refresh();
      push(result.message, result.unfulfilled ? "warning" : "success", "Optimizer finished");
    } catch (error) {
      push(error.message, "error");
    } finally {
      setOptimizing(false);
    }
  }

  async function readNotification(notification) {
    if (notification.read) return;
    try {
      await api.readNotification(notification.id);
      await refresh();
    } catch (error) {
      push(error.message, "error");
    }
  }

  async function readAllNotifications() {
    try {
      await api.readAll();
      await refresh();
    } catch (error) {
      push(error.message, "error");
    }
  }

  async function confirmReset() {
    setResetOpen(false);
    try {
      await api.resetDemo();
    } catch (error) {
      if (!(error instanceof ApiError) || error.status !== 401) {
        push(error.message, "error");
        return;
      }
    }
    storeToken(null);
    setToken(null);
    setState(null);
    setPage("overview");
    setBooting(false);
    setBootError("Demo data was reset. Sign in again with any demo account.");
  }

  function openRequest(defaults = {}) {
    setRequestDefaults(defaults);
    setRequestOpen(true);
  }

  function openBreakdown(machineId = "") {
    setBreakdown({ machineId });
  }

  if (!token) {
    return (
      <>
        <Login api={api} onAuth={onAuth} notice={bootError} />
        <Toasts items={toasts} onDismiss={dismiss} />
      </>
    );
  }

  if (booting || !state) {
    return (
      <>
        <Boot
          error={bootError}
          onRetry={() => {
            setBootKey((value) => value + 1);
          }}
          onSignOut={signOut}
        />
        <Toasts items={toasts} onDismiss={dismiss} />
      </>
    );
  }

  const user = state.user;
  const isOwner = state.role === "owner";
  const navItems = isOwner ? OWNER_NAV : FARMER_NAV;
  const myMachines = state.equipment.filter((machine) => state.my_machines.includes(machine.id));
  const pendingCount = state.requests.filter((request) => request.status === "pending").length;

  const pageProps = {
    state,
    api,
    refresh,
    push,
    role: state.role,
    go,
    runOptimize,
    busy: optimizing ? "optimize" : "",
    openRain: isOwner ? () => setRainOpen(true) : undefined,
    openBreakdown: isOwner ? openBreakdown : undefined,
    openRequest,
  };

  let content = null;
  if (page === "overview") {
    content = isOwner ? (
      <OwnerOverview {...pageProps} />
    ) : (
      <FarmerOverview {...pageProps} />
    );
  } else if (page === "requests") {
    content = <Requests {...pageProps} />;
  } else if (page === "schedule") {
    content = <Schedule {...pageProps} />;
  } else if (page === "machines" || page === "plots") {
    content = <Registry {...pageProps} />;
  } else if (page === "map") {
    content = <MapPage {...pageProps} />;
  } else if (page === "notifications") {
    content = <Notifications {...pageProps} />;
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div className="topbar-inner">
          <Brand onClick={() => go("overview")} />
          <nav className="nav" aria-label="Main navigation">
            {navItems.map((item) => {
              const active = page === item.key;
              return (
                <button
                  type="button"
                  key={item.key}
                  className={`nav-link ${active ? "active" : ""}`}
                  onClick={() => go(item.key)}
                >
                  <Icon name={item.icon} size={14} />
                  {item.label}
                  {isOwner && item.key === "requests" && pendingCount > 0 && (
                    <span className="nav-badge">{pendingCount}</span>
                  )}
                </button>
              );
            })}
          </nav>
          <div className="topbar-right">
            <NotificationBell
              notifications={state.notifications}
              unread={state.unread}
              onRead={readNotification}
              onReadAll={readAllNotifications}
            />
            <div className="user-menu" ref={menuRef}>
              <button type="button" className="user-chip" onClick={() => setMenuOpen((value) => !value)}>
                <Avatar name={user.name} role={user.role} />
                <span className="user-meta">
                  <span className="user-name">{user.name}</span>
                  <span className="user-role">{isOwner ? user.farm_name : "Farmer"}</span>
                </span>
                <Icon name="chevronDown" size={14} />
              </button>
              {menuOpen && (
                <div className="menu-pop">
                  <div className="menu-head">
                    <Avatar name={user.name} role={user.role} size="lg" />
                    <div style={{ minWidth: 0 }}>
                      <div className="user-name">{user.name}</div>
                      <div className="small muted">{user.email}</div>
                      <div className="small muted">{user.farm_name}</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="menu-item"
                    onClick={() => {
                      go("notifications");
                      setMenuOpen(false);
                    }}
                  >
                    <Icon name="bell" size={14} />
                    Notifications
                    {state.unread > 0 && <span className="menu-count">{state.unread}</span>}
                  </button>
                  <button
                    type="button"
                    className="menu-item"
                    onClick={() => {
                      setMenuOpen(false);
                      setResetOpen(true);
                    }}
                  >
                    <Icon name="refresh" size={14} />
                    Reset demo data
                  </button>
                  <button type="button" className="menu-item danger" onClick={signOut}>
                    <Icon name="logout" size={14} />
                    Log out
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="content">{content}</main>

      <footer className="footer-note">
        <strong>FieldShare</strong> · demo data · {isOwner ? "Owner" : "Farmer"} view ·{" "}
        {state.today} · travel 20 km/h · setup 30 min
      </footer>

      <OptimizeResultModal
        result={optResult}
        onClose={() => setOptResult(null)}
        onViewSchedule={
          isOwner && optResult
            ? () => {
                setOptResult(null);
                go("schedule");
              }
            : undefined
        }
      />

      {isOwner && (
        <RainDialog
          open={rainOpen}
          onClose={() => setRainOpen(false)}
          api={api}
          refresh={refresh}
          push={push}
          today={state.today}
          onViewSchedule={() => go("schedule")}
        />
      )}

      {isOwner && (
        <BreakdownDialog
          open={Boolean(breakdown)}
          onClose={() => setBreakdown(null)}
          api={api}
          refresh={refresh}
          push={push}
          today={state.today}
          machines={myMachines}
          initialMachineId={breakdown?.machineId || ""}
          onViewSchedule={() => go("schedule")}
        />
      )}

      {!isOwner && (
        <RequestFormModal
          open={requestOpen}
          defaults={requestDefaults}
          state={state}
          api={api}
          refresh={refresh}
          push={push}
          onClose={() => setRequestOpen(false)}
          go={go}
        />
      )}

      <Modal
        open={resetOpen}
        onClose={() => setResetOpen(false)}
        title="Reset demo data?"
        subtitle="This rebuilds the 3 owners, 5 farmers, 8 machines, 12 plots and 15 sample requests."
        sm
        footer={
          <>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setResetOpen(false)}>
              Cancel
            </button>
            <button type="button" className="btn btn-danger btn-sm" onClick={confirmReset}>
              Reset and sign out
            </button>
          </>
        }
      >
        Anything you added or changed in this demo will be replaced with the original dataset. You will
        need to sign in again.
      </Modal>

      <Toasts items={toasts} onDismiss={dismiss} />
    </div>
  );
}
