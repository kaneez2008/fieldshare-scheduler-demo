import { useEffect, useMemo, useState } from "react";
import Icon from "../icons.jsx";
import {
  OPERATIONS,
  addDaysISO,
  acres,
  fmtDate,
  fmtMinutes,
  opLabel,
  typeLabel,
} from "../format.js";
import { Alert, Modal } from "./ui.jsx";

function estimateMinutes(area, workRate) {
  if (!area || !workRate) return 0;
  return Math.max(15, Math.ceil((area / workRate) * 60 / 5) * 5);
}

export default function RequestFormModal({ open, defaults = {}, state, api, refresh, push, onClose, go }) {
  const plots = state.plots.filter((plot) => state.my_plots.includes(plot.id));
  const today = state.today;

  const [plotId, setPlotId] = useState("");
  const [operation, setOperation] = useState("harvesting");
  const [preferredType, setPreferredType] = useState("harvester");
  const [ownerId, setOwnerId] = useState("");
  const [windowStart, setWindowStart] = useState(addDaysISO(today, 1));
  const [windowEnd, setWindowEnd] = useState(addDaysISO(today, 4));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const ownersForType = useMemo(() => {
    const ids = new Set(
      state.equipment.filter((machine) => machine.type === preferredType).map((machine) => machine.owner_id),
    );
    return state.users.filter((user) => user.role === "owner" && ids.has(user.id));
  }, [state.equipment, state.users, preferredType]);

  useEffect(() => {
    if (!open) return;
    const nextOperation = defaults.operation || "harvesting";
    const types = OPERATIONS[nextOperation]?.types || ["harvester"];
    const nextType = types.includes(defaults.preferred_type) ? defaults.preferred_type : types[0];
    const eligible = state.equipment.filter((machine) => machine.type === nextType);
    const ownerChoices = new Set(eligible.map((machine) => machine.owner_id));
    const fallbackOwner = state.users.find((user) => user.role === "owner" && ownerChoices.has(user.id))?.id;
    const plot = defaults.plot_id || plots[0]?.id || "";
    const oldEnd = defaults.followUp && defaults.window_end ? defaults.window_end : null;
    const start = oldEnd
      ? [addDaysISO(today, 1), addDaysISO(oldEnd, 1)].sort().at(-1)
      : defaults.window_start || addDaysISO(today, 1);
    const end = oldEnd ? addDaysISO(start, 7) : defaults.window_end || addDaysISO(today, 4);

    setPlotId(plot);
    setOperation(nextOperation);
    setPreferredType(nextType);
    setOwnerId(ownerChoices.has(defaults.owner_id) ? defaults.owner_id : fallbackOwner || "");
    setWindowStart(start);
    setWindowEnd(end < start ? addDaysISO(start, 3) : end);
    setError("");
    setBusy(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  function changeOperation(nextOperation) {
    const types = OPERATIONS[nextOperation]?.types || [];
    const nextType = types[0];
    const ownerChoices = new Set(
      state.equipment.filter((machine) => machine.type === nextType).map((machine) => machine.owner_id),
    );
    const fallbackOwner = state.users.find((user) => user.role === "owner" && ownerChoices.has(user.id))?.id;
    setOperation(nextOperation);
    setPreferredType(nextType);
    setOwnerId(fallbackOwner || "");
  }

  function changeType(nextType) {
    const ownerChoices = new Set(
      state.equipment.filter((machine) => machine.type === nextType).map((machine) => machine.owner_id),
    );
    const fallbackOwner = state.users.find((user) => user.role === "owner" && ownerChoices.has(user.id))?.id;
    setPreferredType(nextType);
    if (!ownerChoices.has(ownerId)) setOwnerId(fallbackOwner || "");
  }

  const plot = plots.find((item) => item.id === plotId);
  const sampleMachine = state.equipment.find(
    (machine) => machine.owner_id === ownerId && machine.type === preferredType,
  );
  const duration = sampleMachine && plot ? estimateMinutes(plot.area, sampleMachine.work_rate) : 0;

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (!plotId) {
      setError("Choose one of your plots first.");
      return;
    }
    if (!ownerId) {
      setError(`No owner offers a ${typeLabel(preferredType)} right now. Pick another operation.`);
      return;
    }
    if (windowEnd < windowStart) {
      setError("The deadline cannot be before the start date.");
      return;
    }
    setBusy(true);
    try {
      await api.createRequest({
        plot_id: plotId,
        owner_id: ownerId,
        operation,
        preferred_type: preferredType,
        window_start: windowStart,
        window_end: windowEnd,
      });
      await refresh();
      push(
        `Your ${opLabel(operation).toLowerCase()} request for ${plot?.name || "your plot"} was sent to the owner.`,
        "success",
        "Request sent",
      );
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={defaults.followUp ? "Request another window" : "Request a machine"}
      subtitle={
        defaults.followUp
          ? "A new request for the same plot and operation, with a little more room before the deadline."
          : "Pick a plot, an operation and the latest date you can accept."
      }
      footer={
        <>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" form="request-form" className="btn btn-primary btn-sm" disabled={busy || !plots.length}>
            <Icon name="mail" size={13} />
            {busy ? "Sending…" : "Send request"}
          </button>
        </>
      }
    >
      {!plots.length ? (
        <Alert
          tone="warn"
          icon="map"
          title="Add a plot first"
          action={
            <button
              type="button"
              className="btn btn-primary btn-sm"
              onClick={() => {
                onClose();
                go?.("plots");
              }}
            >
              Add plot
            </button>
          }
        >
          Owners need a field location to calculate travel time. Add a plot with a map pin, then come
          back to request a machine.
        </Alert>
      ) : (
        <form id="request-form" onSubmit={submit}>
          {error && (
            <Alert tone="danger" icon="alert" title="Could not send the request">
              {error}
            </Alert>
          )}

          <div className="form-grid">
            <label className="field full">
              <span className="label">Plot</span>
              <select className="select" value={plotId} onChange={(event) => setPlotId(event.target.value)} required>
                {plots.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name} · {acres(item.area)} · {item.crop}
                  </option>
                ))}
              </select>
            </label>

            <div className="field full">
              <span className="label">Operation</span>
              <div className="segmented">
                {Object.keys(OPERATIONS).map((key) => (
                  <button
                    type="button"
                    key={key}
                    className={operation === key ? "active" : ""}
                    onClick={() => changeOperation(key)}
                  >
                    {opLabel(key)}
                  </button>
                ))}
              </div>
            </div>

            <label className="field">
              <span className="label">Machine type</span>
              <select
                className="select"
                value={preferredType}
                onChange={(event) => changeType(event.target.value)}
              >
                {(OPERATIONS[operation]?.types || []).map((type) => (
                  <option key={type} value={type}>
                    {typeLabel(type)}
                  </option>
                ))}
              </select>
            </label>

            <label className="field">
              <span className="label">Owner</span>
              <select
                className="select"
                value={ownerId}
                onChange={(event) => setOwnerId(event.target.value)}
                required
              >
                {ownersForType.length ? (
                  ownersForType.map((owner) => (
                    <option key={owner.id} value={owner.id}>
                      {owner.farm_name || owner.name}
                    </option>
                  ))
                ) : (
                  <option value="">No owner offers this machine type</option>
                )}
              </select>
            </label>

            <label className="field">
              <span className="label">Earliest date</span>
              <input
                className="input"
                type="date"
                value={windowStart}
                min={today}
                onChange={(event) => {
                  setWindowStart(event.target.value);
                  if (event.target.value > windowEnd) setWindowEnd(event.target.value);
                }}
                required
              />
            </label>

            <label className="field">
              <span className="label">Deadline (hard stop)</span>
              <input
                className="input"
                type="date"
                value={windowEnd}
                min={windowStart || today}
                onChange={(event) => setWindowEnd(event.target.value)}
                required
              />
            </label>
          </div>

          <div className="split-even" style={{ marginTop: 14 }}>
            <div className="explain">
              <span className="explain-label">
                <Icon name="clock" size={11} />
                Estimated work
              </span>
              {duration && plot ? (
                <>
                  About <strong>{fmtMinutes(duration)}</strong> of field work ({acres(plot.area)} at{" "}
                  {sampleMachine.work_rate} acres/hour). The scheduler adds travel and 30 minutes of setup
                  on top, inside your window.
                </>
              ) : (
                "Choose a plot and an owner to see the estimated duration."
              )}
            </div>
            <div className="explain good">
              <span className="explain-label">
                <Icon name="calendar" size={11} />
                Window
              </span>
              {fmtDate(windowStart)} → {fmtDate(windowEnd)}. Jobs are ranked by the deadline — an earlier
              deadline means higher priority, so allow realistic room.
            </div>
          </div>

          <div className="rule" style={{ marginTop: 12 }}>
            Your request goes to the owner first. Once approved, the optimizer finds a clash-free slot
            that includes travel time and setup. You can track the status here and in notifications.
          </div>
        </form>
      )}
    </Modal>
  );
}
