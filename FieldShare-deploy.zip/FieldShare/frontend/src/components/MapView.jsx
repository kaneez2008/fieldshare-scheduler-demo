import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { acres, money, rateLabel, typeLabel } from "../format.js";

const TILES = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
const ATTRIBUTION = "&copy; OpenStreetMap contributors";

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function popup(title, lines) {
  return `<div class="map-pop-title">${esc(title)}</div>${lines
    .filter(Boolean)
    .map((line) => `<div class="map-pop-line">${esc(line)}</div>`)
    .join("")}`;
}

export function FarmMap({ plots = [], machines = [], height = 340, myId, role, compact = false }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const layerRef = useRef(null);
  const fitRef = useRef("");

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return undefined;
    const map = L.map(containerRef.current, {
      scrollWheelZoom: false,
      zoomControl: !compact,
      attributionControl: !compact,
    }).setView([36.755, -119.76], 10);
    L.tileLayer(TILES, { attribution: ATTRIBUTION, maxZoom: 19 }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    const timer = setTimeout(() => map.invalidateSize(), 120);
    return () => {
      clearTimeout(timer);
      map.remove();
      mapRef.current = null;
      layerRef.current = null;
    };
  }, [compact]);

  useEffect(() => {
    const map = mapRef.current;
    const layer = layerRef.current;
    if (!map || !layer) return;
    layer.clearLayers();
    const points = [];

    plots.forEach((plot) => {
      if (plot.lat == null || plot.lng == null) return;
      const mine = role === "farmer" && plot.farmer_id === myId;
      points.push([plot.lat, plot.lng]);
      const marker = L.circleMarker([plot.lat, plot.lng], {
        radius: mine ? 9 : 7,
        color: "#ffffff",
        weight: 2,
        fillColor: mine ? "#1d4e34" : "#4a9065",
        fillOpacity: 0.92,
      }).addTo(layer);
      marker.bindPopup(
        popup(`Plot · ${plot.name}`, [
          `${plot.crop} · ${acres(plot.area)}`,
          plot.farmer_farm || plot.farmer_name,
          mine ? "Your plot" : "",
          `${plot.requests_count || 0} request${plot.requests_count === 1 ? "" : "s"}`,
        ]),
      );
    });

    machines.forEach((machine) => {
      if (machine.lat == null || machine.lng == null) return;
      const mine = role === "owner" && machine.owner_id === myId;
      const broken = machine.status === "broken";
      points.push([machine.lat, machine.lng]);
      const marker = L.circleMarker([machine.lat, machine.lng], {
        radius: mine ? 9 : 7,
        color: "#ffffff",
        weight: 2,
        fillColor: broken ? "#a8432c" : mine ? "#8a5326" : "#bb7048",
        fillOpacity: 0.92,
      }).addTo(layer);
      marker.bindPopup(
        popup(`Machine · ${machine.name}`, [
          `${typeLabel(machine.type)} · ${machine.work_rate} acres/hour`,
          machine.owner_farm || machine.owner_name,
          `${money(machine.rate)} ${rateLabel(machine.rate_type)}`,
          broken ? "Currently broken" : "Available",
          machine.active_breakdown
            ? `Repair until ${machine.active_breakdown.end_date}`
            : machine.upcoming_breakdown
              ? `Breakdown booked ${machine.upcoming_breakdown.start_date}–${machine.upcoming_breakdown.end_date}`
              : "",
        ]),
      );
    });

    const signature = `${plots.length}:${machines.length}:${points.length}`;
    if (points.length && fitRef.current !== signature) {
      fitRef.current = signature;
      map.fitBounds(L.latLngBounds(points).pad(0.16), { maxZoom: 13, animate: false });
    }
    const timer = setTimeout(() => map.invalidateSize(), 80);
    return () => clearTimeout(timer);
  }, [plots, machines, myId, role]);

  return (
    <div className="map-wrap" style={{ height }}>
      <div className="map" ref={containerRef} />
      {!compact && (
        <div className="map-legend">
          <span className="legend-item">
            <span className="legend-dot" style={{ background: "#4a9065" }} /> Farm plot
          </span>
          <span className="legend-item">
            <span className="legend-dot" style={{ background: "#bb7048" }} /> Machine base
          </span>
          <span className="legend-item">
            <span className="legend-dot" style={{ background: "#a8432c" }} /> Broken machine
          </span>
        </div>
      )}
      {!plots.length && !machines.length && (
        <div className="map-badge" style={{ top: "auto", bottom: 12, left: "auto", right: 12 }}>
          No locations yet
        </div>
      )}
    </div>
  );
}

export function LocationPicker({ value, onChange, height = 220 }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const markerRef = useRef(null);
  const changeRef = useRef(onChange);
  changeRef.current = onChange;

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return undefined;
    const start = value ? [value.lat, value.lng] : [36.755, -119.76];
    const map = L.map(containerRef.current, { scrollWheelZoom: true }).setView(start, value ? 13 : 10);
    L.tileLayer(TILES, { attribution: ATTRIBUTION, maxZoom: 19 }).addTo(map);
    map.on("click", (event) => {
      const next = {
        lat: Number(event.latlng.lat.toFixed(6)),
        lng: Number(event.latlng.lng.toFixed(6)),
      };
      changeRef.current?.(next);
    });
    mapRef.current = map;
    const timer = setTimeout(() => map.invalidateSize(), 120);
    return () => {
      clearTimeout(timer);
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !value) return;
    if (!markerRef.current) {
      markerRef.current = L.circleMarker([value.lat, value.lng], {
        radius: 9,
        color: "#fff",
        weight: 3,
        fillColor: "#1d4e34",
        fillOpacity: 1,
      }).addTo(map);
      markerRef.current.bindTooltip("Selected location", { permanent: false });
    } else {
      markerRef.current.setLatLng([value.lat, value.lng]);
    }
    map.setView([value.lat, value.lng], Math.max(map.getZoom(), 12), { animate: true });
  }, [value]);

  return (
    <div>
      <div className="picker-map" style={{ height }} ref={containerRef} />
      <div className="coord-hint">
        <span style={{ color: "var(--green-600)" }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M20 10c0 5.2-8 12-8 12S4 15.2 4 10a8 8 0 1 1 16 0Z" />
            <circle cx="12" cy="10" r="2.8" />
          </svg>
        </span>
        {value
          ? `Pinned at ${value.lat.toFixed(5)}, ${value.lng.toFixed(5)} — click again to adjust.`
          : "Click the map to drop a pin for this location."}
      </div>
    </div>
  );
}
