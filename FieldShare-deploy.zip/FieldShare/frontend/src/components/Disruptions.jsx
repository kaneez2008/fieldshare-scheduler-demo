import { useEffect, useState } from "react";
import Icon from "../icons.jsx";
import { addDaysISO, deadlineText, fmtDate, opLabel, plural } from "../format.js";
import { Alert, Modal, RiskBadge, StatusBadge } from "./ui.jsx";

function DisruptionResult({ result, onClose, onViewSchedule }) {
  return (
    <Modal
      open
      onClose={onClose}
      wide
      title="Disruption handled"
      subtitle="Only affected jobs were re-planned. Everything else stays where it was."
      footer={
        <>
          {onViewSchedule && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={onViewSchedule}>
              <Icon name="calendar" size={13} />
              View timeline
            </button>
          )}
          <button type="button" className="btn btn-primary btn-sm" onClick={onClose}>
            Done
          </button>
        </>
      }
    >
      <Alert
        tone={result.unfulfilled?.length ? "warn" : "good"}
        icon={result.meta?.kind === "breakdown" ? "wrench" : "rain"}
        title={result.cause}
      >
        {plural(result.moved?.length || 0, "booking")} moved automatically ·{" "}
        {plural(result.unfulfilled?.length || 0, "job")} could not be re-scheduled ·{" "}
        {plural(result.unchanged_bookings || 0, "other booking")} left untouched.
      </Alert>

      <div className="result-summary" style={{ marginTop: 14 }}>
        <div className="result-stat">
          <div className="v">{result.moved?.length || 0}</div>
          <div className="l">Moved</div>
        </div>
        <div className="result-stat">
          <div className="v">{result.unfulfilled?.length || 0}</div>
          <div className="l">At risk</div>
        </div>
        <div className="result-stat">
          <div className="v">{result.notifications_sent || 0}</div>
          <div className="l">Notifications</div>
        </div>
      </div>

      {result.integrity && !result.integrity.ok && (
        <Alert tone="danger" icon="alert" title="Schedule check needs attention">
          {result.integrity.problems.join(" ")}
        </Alert>
      )}

      {result.moved?.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <div className="section-title" style={{ fontSize: 17 }}>
            Before → after
          </div>
          <div className="ba-list">
            {result.moved.map((item) => (
              <div className="ba-item" key={item.request_id}>
                <div className="ba-name">
                  <span>
                    {item.plot_name} · {opLabel(item.operation)}
                  </span>
                  <span className="muted small">{item.farmer_name}</span>
                  <StatusBadge status="rescheduled" />
                </div>
                <div className="ba-flow">
                  <div className="ba-box">
                    <span className="ba-label">Before</span>
                    {item.before}
                  </div>
                  <div className="ba-arrow">
                    <Icon name="arrowRight" size={16} />
                  </div>
                  <div className="ba-box after">
                    <span className="ba-label">After</span>
                    {item.after}
                  </div>
                </div>
                {item.priority_note && (
                  <div className="ba-explain">
                    <strong>Priority: </strong>
                    {item.priority_note}
                  </div>
                )}
                {item.explanation && <div className="ba-explain">{item.explanation}</div>}
              </div>
            ))}
          </div>
        </div>
      )}

      {result.unfulfilled?.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <div className="section-title" style={{ fontSize: 17 }}>
            Could not be re-scheduled
          </div>
          <div className="ba-list">
            {result.unfulfilled.map((item) => (
              <div className="ba-item" key={item.request_id}>
                <div className="ba-name">
                  <span>
                    {item.plot_name} · {opLabel(item.operation)}
                  </span>
                  <span className="muted small">{item.farmer_name}</span>
                  <StatusBadge status="unfulfilled" />
                </div>
                <div className="ba-flow" style={{ gridTemplateColumns: "1fr" }}>
                  <div className="ba-box">
                    <span className="ba-label">Before</span>
                    {item.before}
                  </div>
                </div>
                <div className="ba-explain">
                  <strong>Why: </strong>
                  {item.reason}
                </div>
                {item.suggestion && (
                  <div className="ba-explain">
                    <strong>Suggestion: </strong>
                    {item.suggestion}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {result.at_risk?.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <div className="section-title" style={{ fontSize: 17 }}>
            Deadlines still tight
          </div>
          <div className="list-tight">
            {result.at_risk.slice(0, 6).map((request) => (
              <div className="queue-item" key={request.id}>
                <span className="queue-num" style={{ background: "var(--clay)" }}>
                  !
                </span>
                <div className="grow">
                  <div className="queue-title">
                    {request.plot_name} · {opLabel(request.operation)}{" "}
                    <span className="muted small">{deadlineText(request.days_left)}</span>
                  </div>
                  <div className="queue-sub">{request.risk_note}</div>
                </div>
                <RiskBadge level={request.risk_level} />
              </div>
            ))}
          </div>
        </div>
      )}

      {result.moved?.length > 0 && (
        <div className="rule" style={{ marginTop: 14 }}>
          Every impacted farmer received a notification explaining what changed and why. Unaffected
          bookings were not touched.
        </div>
      )}
    </Modal>
  );
}

export function RainDialog({ open, onClose, api, refresh, push, today, onViewSchedule }) {
  const [start, setStart] = useState(addDaysISO(today, 1));
  const [end, setEnd] = useState(addDaysISO(today, 1));
  const [reason, setReason] = useState("Heavy rain — fields too wet for machinery.");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  useEffect(() => {
    if (open) {
      setStart(addDaysISO(today, 1));
      setEnd(addDaysISO(today, 1));
      setReason("Heavy rain — fields too wet for machinery.");
      setResult(null);
      setError("");
    }
  }, [open, today]);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const data = await api.simulateRain({ start_date: start, end_date: end, reason: reason.trim() });
      setResult(data);
      await refresh();
      push(
        `${plural(data.moved.length, "booking")} moved, ${plural(data.unfulfilled.length, "job")} at risk.`,
        data.unfulfilled.length ? "warning" : "success",
        "Rain simulated",
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const closeResult = () => {
    setResult(null);
    onClose();
  };

  if (open && result) {
    return (
      <DisruptionResult
        result={result}
        onClose={closeResult}
        onViewSchedule={
          onViewSchedule
            ? () => {
                closeResult();
                onViewSchedule();
              }
            : undefined
        }
      />
    );
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Simulate heavy rain"
      subtitle="Block field work for one or more days. Affected jobs are re-planned by deadline."
      footer={
        <>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" form="rain-form" className="btn btn-primary btn-sm" disabled={busy}>
            <Icon name="rain" size={13} />
            {busy ? "Re-planning…" : "Block rain days"}
          </button>
        </>
      }
    >
      <form id="rain-form" onSubmit={submit}>
        {error && (
          <Alert tone="danger" icon="alert" title="Could not simulate rain">
            {error}
          </Alert>
        )}
        <div className="form-grid">
          <label className="field">
            <span className="label">First rain day</span>
            <input
              className="input"
              type="date"
              value={start}
              min={today}
              onChange={(event) => {
                setStart(event.target.value);
                if (event.target.value > end) setEnd(event.target.value);
              }}
              required
            />
          </label>
          <label className="field">
            <span className="label">Last rain day</span>
            <input
              className="input"
              type="date"
              value={end}
              min={start || today}
              onChange={(event) => setEnd(event.target.value)}
              required
            />
          </label>
          <label className="field full">
            <span className="label">Reason shown to farmers</span>
            <textarea
              className="textarea"
              rows={2}
              value={reason}
              onChange={(event) => setReason(event.target.value)}
              placeholder="Heavy rain — fields too wet for machinery."
            />
          </label>
        </div>
        <div className="rule" style={{ marginTop: 12 }}>
          Bookings on these days are moved to the next free slot <strong>before each deadline</strong>,
          tightest deadline first. Bookings on other days are not touched. Every impacted farmer gets a
          notification with the old and new time.
        </div>
        {fmtDate(start) && (
          <div className="hint" style={{ marginTop: 8 }}>
            This will block {start === end ? fmtDate(start) : `${fmtDate(start)} to ${fmtDate(end)}`}.
          </div>
        )}
      </form>
    </Modal>
  );
}

export function BreakdownDialog({ open, onClose, api, refresh, push, today, machines, initialMachineId, onViewSchedule }) {
  const [machineId, setMachineId] = useState(initialMachineId || "");
  const [start, setStart] = useState(today);
  const [end, setEnd] = useState(addDaysISO(today, 1));
  const [note, setNote] = useState("Unexpected machine breakdown.");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  useEffect(() => {
    if (open) {
      setMachineId(initialMachineId || machines[0]?.id || "");
      setStart(today);
      setEnd(addDaysISO(today, 1));
      setNote("Unexpected machine breakdown.");
      setResult(null);
      setError("");
    }
    // Reset the form only when the dialog opens, not on every keystroke.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initialMachineId, today]);

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const data = await api.simulateBreakdown({
        equipment_id: machineId,
        start_date: start,
        end_date: end,
        note: note.trim(),
      });
      setResult(data);
      await refresh();
      push(
        `${plural(data.moved.length, "booking")} moved, ${plural(data.unfulfilled.length, "job")} at risk.`,
        data.unfulfilled.length ? "warning" : "success",
        "Breakdown recorded",
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  const closeResult = () => {
    setResult(null);
    onClose();
  };

  if (open && result) {
    return (
      <DisruptionResult
        result={result}
        onClose={closeResult}
        onViewSchedule={
          onViewSchedule
            ? () => {
                closeResult();
                onViewSchedule();
              }
            : undefined
        }
      />
    );
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Break down a machine"
      subtitle="The machine is unavailable for the selected days. Its jobs are re-planned automatically."
      footer={
        <>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onClose}>
            Cancel
          </button>
          <button
            type="submit"
            form="breakdown-form"
            className="btn btn-danger btn-sm"
            disabled={busy || !machineId}
          >
            <Icon name="wrench" size={13} />
            {busy ? "Re-planning…" : "Mark as broken"}
          </button>
        </>
      }
    >
      <form id="breakdown-form" onSubmit={submit}>
        {error && (
          <Alert tone="danger" icon="alert" title="Could not record the breakdown">
            {error}
          </Alert>
        )}
        {!machines.length ? (
          <Alert tone="warn" icon="info" title="No machines yet">
            Add a machine to your registry before simulating a breakdown.
          </Alert>
        ) : (
          <div className="form-grid">
            <label className="field full">
              <span className="label">Machine</span>
              <select
                className="select"
                value={machineId}
                onChange={(event) => setMachineId(event.target.value)}
                required
              >
                {machines.map((machine) => (
                  <option key={machine.id} value={machine.id}>
                    {machine.name} · {machine.status === "broken" ? "currently broken" : "active"}
                  </option>
                ))}
              </select>
            </label>
            <label className="field">
              <span className="label">Broken from</span>
              <input
                className="input"
                type="date"
                value={start}
                min={today}
                onChange={(event) => {
                  setStart(event.target.value);
                  if (event.target.value > end) setEnd(event.target.value);
                }}
                required
              />
            </label>
            <label className="field">
              <span className="label">Expected repair</span>
              <input
                className="input"
                type="date"
                value={end}
                min={start || today}
                onChange={(event) => setEnd(event.target.value)}
                required
              />
            </label>
            <label className="field full">
              <span className="label">What happened (shown to farmers)</span>
              <textarea
                className="textarea"
                rows={2}
                value={note}
                onChange={(event) => setNote(event.target.value)}
              />
            </label>
          </div>
        )}
        {!!machines.length && (
          <div className="rule" style={{ marginTop: 12 }}>
            Only jobs on this machine inside the broken dates are re-planned{" "}
            <strong>by deadline priority</strong>. Other machines and other days keep their bookings.
          </div>
        )}
      </form>
    </Modal>
  );
}
