import Icon from "../icons.jsx";
import { fmtDate, fmtTimeRange, opLabel, plural } from "../format.js";
import { Alert, Modal, StatusBadge } from "./ui.jsx";

export default function OptimizeResultModal({ result, onClose, onViewSchedule }) {
  if (!result) return null;
  const details = result.details || [];
  const scheduled = details.filter((detail) => detail.status === "scheduled");
  const failed = details.filter((detail) => detail.status !== "scheduled");
  const integrity = result.integrity;

  return (
    <Modal
      open
      onClose={onClose}
      wide
      title="Schedule optimizer"
      subtitle="Jobs are placed deadline-first, and travel plus setup are always included."
      footer={
        <>
          {onViewSchedule && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={onViewSchedule}>
              <Icon name="calendar" size={13} />
              Open timeline
            </button>
          )}
          <button type="button" className="btn btn-primary btn-sm" onClick={onClose}>
            Done
          </button>
        </>
      }
    >
      <div className="result-summary">
        <div className="result-stat">
          <div className="v">{result.scheduled ?? scheduled.length}</div>
          <div className="l">Scheduled</div>
        </div>
        <div className="result-stat">
          <div className="v">{result.unfulfilled ?? failed.length}</div>
          <div className="l">Could not fit</div>
        </div>
        <div className="result-stat">
          <div className="v">{result.travel_km ?? 0}</div>
          <div className="l">Travel km</div>
        </div>
      </div>

      {result.message && <div className="hint" style={{ marginBottom: 12 }}>{result.message}</div>}

      {integrity && !integrity.ok && (
        <Alert tone="danger" icon="alert" title="Schedule check needs attention">
          {integrity.problems.join(" ")}
        </Alert>
      )}

      {details.length > 0 && (
        <Alert tone="info" icon="sparkles" title="How the order was chosen">
          Requests with the fewest days left go first. Equal deadlines are broken by whoever asked first.
          Each job reserves its travel time and 30 minutes of setup, so two machines never clash.
        </Alert>
      )}

      {scheduled.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div className="section-title" style={{ fontSize: 17 }}>
            Locked in · {plural(scheduled.length, "job")}
          </div>
          {scheduled.map((detail) => (
            <div className="opt-detail" key={detail.request_id}>
              <div className="headline">
                <StatusBadge status="scheduled" />
                <span>
                  {detail.plot_name} · {opLabel(detail.operation)}
                </span>
                {detail.farmer_name && <span className="muted small">for {detail.farmer_name}</span>}
              </div>
              {detail.booking && (
                <div className="opt-when">
                  <Icon name="calendar" size={12} />
                  {fmtDate(detail.booking.date, { weekday: true })} ·{" "}
                  {fmtTimeRange(detail.booking.start_time, detail.booking.end_time)}
                  <span className="dot-sep">·</span>
                  {detail.machine_name}
                  {detail.booking.travel_km != null && (
                    <>
                      <span className="dot-sep">·</span>
                      {detail.booking.travel_km} km travel
                    </>
                  )}
                </div>
              )}
              {detail.priority_note && (
                <div className="why">
                  <strong>Why first: </strong>
                  {detail.priority_note}
                </div>
              )}
              {detail.explanation && <div className="why">{detail.explanation}</div>}
            </div>
          ))}
        </div>
      )}

      {failed.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <div className="section-title" style={{ fontSize: 17 }}>
            Could not be scheduled · {plural(failed.length, "job")}
          </div>
          {failed.map((detail) => (
            <div className="opt-detail" key={detail.request_id}>
              <div className="headline">
                <StatusBadge status="unfulfilled" />
                <span>
                  {detail.plot_name} · {opLabel(detail.operation)}
                </span>
                {detail.farmer_name && <span className="muted small">for {detail.farmer_name}</span>}
              </div>
              {detail.reason && (
                <div className="why">
                  <strong>Why: </strong>
                  {detail.reason}
                </div>
              )}
              {detail.suggestion && (
                <div className="why">
                  <strong>Suggestion: </strong>
                  {detail.suggestion}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {details.length === 0 && (
        <Alert tone="info" icon="info" title="Nothing waiting">
          {result.message || "Approve a pending request or add a new one, then run the optimizer again."}
        </Alert>
      )}
    </Modal>
  );
}
