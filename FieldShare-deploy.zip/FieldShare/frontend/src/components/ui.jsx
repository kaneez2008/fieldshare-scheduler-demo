import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import Icon from "../icons.jsx";
import { RISK, STATUS, initials } from "../format.js";

export function Brand({ onClick, light = false, subtitle = true }) {
  return (
    <button type="button" className="brand" onClick={onClick} aria-label="FieldShare home">
      <span className="brand-mark">
        <Icon name="leaf" size={23} strokeWidth={1.9} />
      </span>
      <span className="brand-text">
        <span className="brand-name">FieldShare</span>
        {subtitle && <span className="brand-tag">Shared equipment scheduler</span>}
      </span>
    </button>
  );
}

export function Avatar({ name, role, size = "md" }) {
  return (
    <span className={`avatar ${role === "farmer" ? "farmer" : ""} ${size === "lg" ? "lg" : ""}`}>
      {initials(name)}
    </span>
  );
}

export function StatusBadge({ status }) {
  const meta = STATUS[status] || { label: status, tone: "gray" };
  return (
    <span className={`badge tone-${meta.tone}`}>
      <span className="dot" />
      {meta.label}
    </span>
  );
}

export function RiskBadge({ level, children }) {
  const meta = RISK[level] || { label: level, tone: "gray" };
  return (
    <span className={`badge tone-${meta.tone}`}>
      <Icon name={level === "low" ? "shield" : "alert"} size={12} strokeWidth={2} />
      {children || meta.label}
    </span>
  );
}

export function Meta({ icon, children, title }) {
  return (
    <span className="meta" title={title}>
      {icon && <Icon name={icon} size={13} />}
      {children}
    </span>
  );
}

export function Stat({ label, value, foot, icon, variant = "" }) {
  return (
    <div className={`stat ${variant}`}>
      <div className="stat-label">
        {icon && <Icon name={icon} size={13} />}
        {label}
      </div>
      <div className="stat-value">{value}</div>
      {foot && <div className="stat-foot">{foot}</div>}
    </div>
  );
}

export function Alert({ tone = "info", icon = "info", title, children, action }) {
  return (
    <div className={`alert ${tone}`}>
      <span className="alert-icon">
        <Icon name={icon} size={18} />
      </span>
      <div className="grow">
        {title && <div className="alert-title">{title}</div>}
        {children && <div className="alert-text">{children}</div>}
      </div>
      {action}
    </div>
  );
}

export function Empty({ icon = "leaf", title, text, action }) {
  return (
    <div className="empty">
      <span className="empty-ic">
        <Icon name={icon} size={21} />
      </span>
      {title && <div className="empty-title">{title}</div>}
      {text && <div className="empty-text">{text}</div>}
      {action}
    </div>
  );
}

export function PageHead({ title, sub, actions }) {
  return (
    <div className="page-head">
      <div className="grow">
        <h1 className="page-title">{title}</h1>
        {sub && <div className="page-sub">{sub}</div>}
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </div>
  );
}

export function SectionHead({ title, sub, action }) {
  return (
    <div className="card-head" style={{ marginBottom: 10 }}>
      <div>
        <div className="card-title">{title}</div>
        {sub && <div className="card-sub">{sub}</div>}
      </div>
      {action}
    </div>
  );
}

export function Modal({ open, onClose, title, subtitle, children, footer, wide, sm }) {
  const panelRef = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      if (event.key === "Escape") onClose?.();
    };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [open, onClose]);

  if (!open) return null;
  return createPortal(
    <div
      className="modal-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose?.();
      }}
    >
      <div
        className={`modal ${wide ? "wide" : ""} ${sm ? "sm" : ""}`}
        role="dialog"
        aria-modal="true"
        aria-label={typeof title === "string" ? title : "Dialog"}
        ref={panelRef}
      >
        <div className="modal-head">
          <div className="grow">
            {title && <h2>{title}</h2>}
            {subtitle && <div className="sub">{subtitle}</div>}
          </div>
          <button type="button" className="modal-close" onClick={onClose} aria-label="Close dialog">
            <Icon name="x" size={16} />
          </button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

export function Toasts({ items, onDismiss }) {
  if (!items.length) return null;
  return createPortal(
    <div className="toasts" aria-live="polite">
      {items.map((toast) => (
        <div key={toast.id} className={`toast ${toast.tone || "success"}`}>
          <span style={{ color: "var(--green-700)", marginTop: 1 }}>
            <Icon
              name={
                toast.tone === "error"
                  ? "alert"
                  : toast.tone === "warning"
                    ? "alert"
                    : toast.tone === "info"
                      ? "info"
                      : "check"
              }
              size={17}
            />
          </span>
          <div className="grow">
            {toast.title && <div className="t-title">{toast.title}</div>}
            <div className="muted" style={{ fontSize: 12, lineHeight: 1.5 }}>
              {toast.message}
            </div>
          </div>
          <button
            type="button"
            className="btn-ghost btn-icon"
            onClick={() => onDismiss(toast.id)}
            aria-label="Dismiss"
            style={{ border: 0, background: "transparent", color: "var(--muted)" }}
          >
            <Icon name="x" size={14} />
          </button>
        </div>
      ))}
    </div>,
    document.body,
  );
}

export function MachineIcon({ type, size = 22 }) {
  const name = ["tractor", "harvester", "sprayer", "seeder"].includes(type) ? type : "tractor";
  return <Icon name={name} size={size} strokeWidth={1.6} />;
}

export function useToasts() {
  const [toasts, setToasts] = useState([]);
  const timers = useRef([]);
  const push = (message, tone = "success", title) => {
    const id = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    setToasts((current) => [...current.slice(-3), { id, message, tone, title }]);
    const timer = setTimeout(() => {
      setToasts((current) => current.filter((t) => t.id !== id));
    }, tone === "error" ? 8000 : 5000);
    timers.current.push(timer);
  };
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  const dismiss = (id) => setToasts((current) => current.filter((t) => t.id !== id));
  return { toasts, push, dismiss };
}

export function ConfidenceNote({ children }) {
  return (
    <div className="rule">
      <Icon name="shield" size={13} style={{ verticalAlign: "-2px", marginRight: 5 }} />
      {children}
    </div>
  );
}
