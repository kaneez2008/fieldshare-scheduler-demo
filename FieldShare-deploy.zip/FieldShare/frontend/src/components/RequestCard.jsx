import { useState } from "react";
import Icon from "../icons.jsx";
import {
  OPERATIONS,
  acres,
  deadlineText,
  fmtDate,
  fmtDayMonth,
  opLabel,
  relativeTime,
  typeLabel,
} from "../format.js";
import { Modal, RiskBadge, StatusBadge } from "./ui.jsx";
import BookingLine from "./BookingLine.jsx";

const OP_ICON = { sowing: "seeder", spraying: "sprayer", harvesting: "harvester" };

export default function RequestCard({
  request,
  api,
  refresh,
  push,
  role,
  onFollowUp,
  onOptimize,
  compact = false,
}) {
  const [busy, setBusy] = useState("");
  const [declineOpen, setDeclineOpen] = useState(false);
  const [declineReason, setDeclineReason] = useState("");

  const status = request.status;
  const explanationTone =
    status === "unfulfilled" ? "danger" : status === "rejected" ? "warn" : status === "scheduled" || status === "rescheduled" ? "good" : "";
  const explanationLabel =
    status === "unfulfilled"
      ? "Why it could not be scheduled"
      : status === "rejected"
        ? "Owner's decision"
        : status === "scheduled" || status === "rescheduled"
          ? "Why this slot"
          : "Next step";

  async function approve() {
    setBusy("approve");
    try {
      await api.acceptRequest(request.id);
      await refresh();
      push(`${request.plot_name} approved. Run the optimizer to lock in a time.`, "success", "Request approved");
    } catch (error) {
      push(error.message, "error");
    } finally {
      setBusy("");
    }
  }

  async function decline() {
    setBusy("decline");
    try {
      await api.rejectRequest(request.id, declineReason.trim());
      setDeclineOpen(false);
      setDeclineReason("");
      await refresh();
      push("The farmer was told about the decision.", "info", "Request declined");
    } catch (error) {
      push(error.message, "error");
    } finally {
      setBusy("");
    }
  }

  return (
    <article className="request-card">
      <div className="request-top">
        <span className="request-icon">
          <Icon name={OP_ICON[request.operation] || "tractor"} size={19} />
        </span>
        <div className="grow" style={{ minWidth: 0 }}>
          <div className="request-title">
            {opLabel(request.operation)} · {request.plot_name}
          </div>
          <div className="request-sub">
            {role === "owner"
              ? `${request.farmer_name}${request.farmer_farm ? ` · ${request.farmer_farm}` : ""}`
              : `${request.owner_farm || request.owner_name} · ${acres(request.plot_area)} of ${request.plot_crop}`}
          </div>
        </div>
        <div className="req-badges">
          <StatusBadge status={status} />
          {request.risk_level && request.risk_level !== "low" && <RiskBadge level={request.risk_level} />}
          <span className={`deadline-chip ${request.days_left <= 3 ? "urgent" : ""}`}>
            <Icon name="clock" size={11} />
            {deadlineText(request.days_left)}
          </span>
        </div>
      </div>

      <div className="meta-row">
        <span className="meta">
          <Icon name="calendar" size={13} />
          {fmtDayMonth(request.window_start)} – {fmtDate(request.window_end)} (deadline)
        </span>
        <span className="meta">
          <Icon name="tractor" size={13} />
          Wants a {typeLabel(request.preferred_type)}
        </span>
        <span className="meta">
          <Icon name="history" size={13} />
          Requested {relativeTime(request.created_at)}
        </span>
        {request.plot_area != null && (
          <span className="meta">
            <Icon name="ruler" size={13} />
            {acres(request.plot_area)}
          </span>
        )}
      </div>

      {request.booking && <BookingLine booking={request.booking} role={role} compact={compact} />}

      {request.explanation && (
        <div className={`explain ${explanationTone}`}>
          <span className="explain-label">
            <Icon name={status === "unfulfilled" ? "alert" : status === "rejected" ? "info" : "check"} size={11} />
            {explanationLabel}
          </span>
          {request.explanation}
        </div>
      )}

      {request.priority_note && (
        <div className="explain">
          <span className="explain-label">
            <Icon name="sparkles" size={11} />
            Deadline priority
          </span>
          {request.priority_note}
        </div>
      )}

      {request.suggestion && (
        <div className="explain good">
          <span className="explain-label">
            <Icon name="route" size={11} />
            Suggestion
          </span>
          {request.suggestion}
        </div>
      )}

      {request.risk_level === "high" && request.risk_note && !request.suggestion && (
        <div className="explain danger">
          <span className="explain-label">
            <Icon name="alert" size={11} />
            At risk
          </span>
          {request.risk_note}
        </div>
      )}

      <div className="card-actions">
        {role === "owner" && status === "pending" && (
          <>
            <button type="button" className="btn btn-primary btn-sm" onClick={approve} disabled={Boolean(busy)}>
              <Icon name="check" size={13} />
              {busy === "approve" ? "Approving…" : "Approve"}
            </button>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={() => setDeclineOpen(true)}
              disabled={Boolean(busy)}
            >
              <Icon name="x" size={13} />
              Decline
            </button>
          </>
        )}

        {role === "owner" && (status === "accepted" || status === "unfulfilled") && onOptimize && (
          <button type="button" className="btn btn-primary btn-sm" onClick={onOptimize}>
            <Icon name="sparkles" size={13} />
            Schedule now
          </button>
        )}

        {role === "farmer" && (status === "rejected" || status === "unfulfilled") && onFollowUp && (
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => onFollowUp(request)}>
            <Icon name="refresh" size={13} />
            Request another window
          </button>
        )}

        {role === "farmer" && status === "pending" && (
          <span className="hint">Waiting for {request.owner_farm || "the owner"} to respond.</span>
        )}

        {role === "farmer" && (status === "scheduled" || status === "rescheduled") && (
          <span className="hint">
            {OPERATIONS[request.operation]?.label} planned — you will be notified if anything changes.
          </span>
        )}
      </div>

      <Modal
        open={declineOpen}
        onClose={() => setDeclineOpen(false)}
        title="Decline this request?"
        subtitle={`${request.farmer_name} · ${opLabel(request.operation)} of ${request.plot_name}`}
        sm
        footer={
          <>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setDeclineOpen(false)}>
              Keep request
            </button>
            <button
              type="button"
              className="btn btn-danger btn-sm"
              onClick={decline}
              disabled={busy === "decline"}
            >
              {busy === "decline" ? "Declining…" : "Decline request"}
            </button>
          </>
        }
      >
        <label className="field">
          <span className="label">Reason for the farmer (optional)</span>
          <textarea
            className="textarea"
            rows={3}
            value={declineReason}
            onChange={(event) => setDeclineReason(event.target.value)}
            placeholder="Example: All harvesters are already committed until the end of the month."
          />
        </label>
        <div className="hint" style={{ marginTop: 8 }}>
          The farmer sees this reason in their request list and gets a notification.
        </div>
      </Modal>
    </article>
  );
}
