import Icon from "../icons.jsx";
import { fmtDate, fmtMinutes, fmtTimeRange, money } from "../format.js";

export default function BookingLine({ booking, role = "farmer", compact = false }) {
  if (!booking) return null;
  return (
    <div className={`booking-line ${compact ? "compact" : ""}`}>
      <span className="booking-ic">
        <Icon name={role === "owner" ? "calendar" : "tractor"} size={14} />
      </span>
      <div className="grow">
        <div className="booking-main">
          <strong>{booking.equipment_name}</strong>
          <span className="booking-when">
            {fmtDate(booking.date, { weekday: true })} · {fmtTimeRange(booking.start_time, booking.end_time)}
          </span>
        </div>
        <div className="booking-meta">
          {role === "owner" && booking.farmer_name && <span>{booking.farmer_name}</span>}
          {role !== "owner" && booking.owner_farm && <span>{booking.owner_farm}</span>}
          <span>{booking.plot_name}</span>
          <span>{fmtMinutes(booking.job_minutes)} job</span>
          <span>
            + {booking.setup_time} min setup, {booking.travel_time} min travel
            {booking.travel_km ? ` (${booking.travel_km} km)` : ""}
          </span>
          <span>Est. {money(booking.cost)}</span>
          {booking.is_blocked_by_weather && (
            <span className="text-danger">
              <Icon name="rain" size={12} /> On a rain-blocked day
            </span>
          )}
        </div>
        {!compact && booking.travel_from && (
          <div className="booking-note">
            Travel starts from{" "}
            {String(booking.travel_from).startsWith("Plot") || booking.travel_from === "the machine base"
              ? booking.travel_from
              : `Plot ${booking.travel_from}`}{" "}
            — the block on the timeline already includes travel and setup.
          </div>
        )}
      </div>
    </div>
  );
}
