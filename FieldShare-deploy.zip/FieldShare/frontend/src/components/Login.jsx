import { useEffect, useState } from "react";
import Icon from "../icons.jsx";
import { Avatar, Brand } from "./ui.jsx";

const FEATURES = [
  {
    icon: "shield",
    text: "Every booking includes travel time and 30 minutes of setup, so machines are never double-booked.",
  },
  {
    icon: "clock",
    text: "Jobs are ranked by the tightest deadline first, and every decision is explained in plain words.",
  },
  {
    icon: "rain",
    text: "Rain or a broken machine? Affected jobs are re-planned automatically and farmers are notified.",
  },
];

export default function Login({ api, onAuth, notice }) {
  const [accounts, setAccounts] = useState([]);
  const [loadingAccounts, setLoadingAccounts] = useState(true);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [showEmail, setShowEmail] = useState(false);
  const [email, setEmail] = useState("maria@valleyag.demo");
  const [password, setPassword] = useState("demo123");

  useEffect(() => {
    let alive = true;
    api
      .demoAccounts()
      .then((data) => {
        if (alive) setAccounts(data.accounts || []);
      })
      .catch(() => {
        if (alive) setError("Cannot reach the server. Start the backend and refresh this page.");
      })
      .finally(() => {
        if (alive) setLoadingAccounts(false);
      });
    return () => {
      alive = false;
    };
  }, [api]);

  async function signIn(kind, payload) {
    setBusy(kind);
    setError("");
    try {
      const data =
        kind === "email"
          ? await api.login(payload.email, payload.password)
          : await api.demoLogin(payload.role, payload.userId);
      onAuth(data.token, data.user);
    } catch (err) {
      setError(err.message);
      setBusy("");
    }
  }

  const owners = accounts.filter((account) => account.role === "owner");
  const farmers = accounts.filter((account) => account.role === "farmer");

  return (
    <div className="login-page">
      <aside className="login-hero">
        <div className="login-brand">
          <span className="brand-mark">
            <Icon name="leaf" size={23} strokeWidth={1.9} />
          </span>
          <span className="brand-text">
            <span className="brand-name">FieldShare</span>
            <span className="brand-tag">Shared farm equipment scheduler</span>
          </span>
        </div>

        <div className="login-hero-main">
          <span className="login-kicker">
            <Icon name="wheat" size={13} /> Small farms, shared machines
          </span>
          <h1 className="login-title">
            The right machine,
            <br />
            on the <em>right day.</em>
          </h1>
          <p className="login-lede">
            Neighbours share tractors, harvesters, sprayers and seeders without phone-tag. FieldShare
            builds a clash-free plan around travel time, rain days and every farmer&apos;s deadline.
          </p>
          <div className="login-features">
            {FEATURES.map((feature) => (
              <div className="login-feature" key={feature.text}>
                <span className="feature-mark">
                  <Icon name={feature.icon} size={14} />
                </span>
                {feature.text}
              </div>
            ))}
          </div>
        </div>

        <div className="login-hero-foot">
          <div>
            <strong>3</strong>
            Equipment owners
          </div>
          <div>
            <strong>5</strong>
            Small farms
          </div>
          <div>
            <strong>8</strong>
            Shared machines
          </div>
          <div>
            <strong>15</strong>
            Sample requests
          </div>
        </div>
      </aside>

      <section className="login-panel">
        <div className="login-card">
          <div className="login-mobile-brand">
            <Brand />
          </div>
          <h2>Sign in</h2>
          <div className="sub">
            Demo accounts are ready to use — no sign-up needed. Choose a role to see the same farm from
            both sides.
          </div>

          {(error || notice) && (
            <div className={`alert ${error ? "danger" : "info"}`} style={{ marginBottom: 14 }}>
              <span className="alert-icon">
                <Icon name={error ? "alert" : "info"} size={17} />
              </span>
              <div className="alert-text">{error || notice}</div>
            </div>
          )}

          <div className="demo-buttons">
            <button
              type="button"
              className="demo-btn owner"
              disabled={Boolean(busy)}
              onClick={() => signIn("owner", { role: "owner", userId: owners[0]?.id })}
            >
              <span className="demo-ic">
                <Icon name="tractor" size={19} />
              </span>
              <span className="demo-title">{busy === "owner" ? "Signing in…" : "Login as Owner"}</span>
              <span className="demo-sub">See machines, approve jobs and reschedule around rain.</span>
            </button>
            <button
              type="button"
              className="demo-btn farmer"
              disabled={Boolean(busy)}
              onClick={() => signIn("farmer", { role: "farmer", userId: farmers[0]?.id })}
            >
              <span className="demo-ic">
                <Icon name="wheat" size={19} />
              </span>
              <span className="demo-title">{busy === "farmer" ? "Signing in…" : "Login as Farmer"}</span>
              <span className="demo-sub">Request machines, follow deadlines and track answers.</span>
            </button>
          </div>

          <div className="login-divider">Or choose a demo account</div>

          {loadingAccounts ? (
            <div className="list-tight">
              <div className="skeleton" />
              <div className="skeleton" />
            </div>
          ) : (
            <div className="accounts">
              <div className="account-grid">
                {accounts.map((account) => (
                  <button
                    type="button"
                    key={account.id}
                    className="account-item"
                    disabled={Boolean(busy)}
                    onClick={() => signIn("account", { role: account.role, userId: account.id })}
                    title={`${account.email} · password demo123`}
                  >
                    <Avatar name={account.name} role={account.role} />
                    <span className="grow" style={{ minWidth: 0 }}>
                      <span className="nm" style={{ display: "block" }}>
                        {account.name}
                      </span>
                      <span className="fm" style={{ display: "block" }}>
                        {account.farm_name} · {account.role === "owner" ? "Owner" : "Farmer"}
                      </span>
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="login-divider">Or use email and password</div>
          <button
            type="button"
            className="email-toggle"
            onClick={() => setShowEmail((value) => !value)}
            aria-expanded={showEmail}
          >
            <Icon name={showEmail ? "chevronDown" : "chevronRight"} size={13} />
            {showEmail ? "Hide email sign-in" : "Show email sign-in"}
          </button>

          {showEmail && (
            <form
              style={{ marginTop: 12 }}
              onSubmit={(event) => {
                event.preventDefault();
                signIn("email", { email, password });
              }}
            >
              <div className="form-grid">
                <label className="field full">
                  <span className="label">Email</span>
                  <input
                    className="input"
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    autoComplete="username"
                    required
                  />
                </label>
                <label className="field full">
                  <span className="label">Password</span>
                  <input
                    className="input"
                    type="password"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    autoComplete="current-password"
                    required
                  />
                </label>
              </div>
              <button
                type="submit"
                className="btn btn-primary btn-block btn-lg"
                style={{ marginTop: 12 }}
                disabled={Boolean(busy)}
              >
                {busy === "email" ? "Signing in…" : "Sign in"}
              </button>
            </form>
          )}

          <div className="login-note">
            <Icon name="info" size={15} />
            <div>
              Demo password for every account is <strong>demo123</strong>. Data resets from the menu
              after you sign in. This is a demo — no real money or personal data is involved.
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
