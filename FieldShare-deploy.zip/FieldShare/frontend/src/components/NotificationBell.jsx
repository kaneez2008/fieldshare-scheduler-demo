import { useEffect, useRef, useState } from "react";
import Icon from "../icons.jsx";
import { relativeTime } from "../format.js";
import { Empty } from "./ui.jsx";

const KIND_ICON = {
  success: "check",
  warning: "alert",
  danger: "alert",
  info: "info",
};

export default function NotificationBell({ notifications = [], unread = 0, onRead, onReadAll }) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const click = (event) => {
      if (wrapRef.current && !wrapRef.current.contains(event.target)) setOpen(false);
    };
    const key = (event) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", click);
    document.addEventListener("keydown", key);
    return () => {
      document.removeEventListener("mousedown", click);
      document.removeEventListener("keydown", key);
    };
  }, [open]);

  return (
    <div className="notif-wrap" ref={wrapRef}>
      <button
        type="button"
        className="icon-btn"
        aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}
        onClick={() => setOpen((value) => !value)}
      >
        <Icon name="bell" size={18} />
        {unread > 0 && <span className="bell-badge">{unread > 9 ? "9+" : unread}</span>}
      </button>
      {open && (
        <div className="notif-panel" role="dialog" aria-label="Notifications">
          <div className="notif-head">
            <div>
              <strong>Notifications</strong>
              <div className="tiny muted">
                {unread ? `${unread} unread` : "You are all caught up"}
              </div>
            </div>
            {unread > 0 && (
              <button type="button" className="btn btn-ghost btn-sm" onClick={onReadAll}>
                Mark all read
              </button>
            )}
          </div>
          <div className="notif-list">
            {notifications.length === 0 && (
              <Empty
                icon="bell"
                title="Nothing here yet"
                text="Scheduling updates, rain alerts and owner decisions will appear here."
              />
            )}
            {notifications.slice(0, 14).map((notification) => (
              <button
                type="button"
                key={notification.id}
                className={`notif-item ${notification.read ? "" : "unread"}`}
                onClick={() => onRead?.(notification)}
              >
                <span className={`notif-kind ${notification.kind || "info"}`}>
                  <Icon name={KIND_ICON[notification.kind] || "info"} size={13} />
                </span>
                <span className="grow" style={{ minWidth: 0 }}>
                  <span className="notif-title" style={{ display: "block" }}>
                    {notification.title}
                  </span>
                  <span className="notif-body">{notification.body}</span>
                  <span className="notif-time">{relativeTime(notification.created_at)}</span>
                </span>
                <span className="notif-dot" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
