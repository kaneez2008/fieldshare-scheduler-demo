import Icon from "../icons.jsx";
import { addDaysISO, fmtDayMonth, fmtTimeRange, parseDay, typeLabel } from "../format.js";
import { Empty, MachineIcon } from "./ui.jsx";

const DAY_START = 420;
const DAY_END = 1140;
const PX = 104;

function toMinutes(hm) {
  if (!hm || !hm.includes(":")) return DAY_START;
  return Number(hm.slice(0, 2)) * 60 + Number(hm.slice(3, 5));
}

function blockStyle(booking) {
  const start = Math.min(DAY_END, Math.max(DAY_START, toMinutes(booking.occupied_start)));
  const end = Math.min(DAY_END, Math.max(start + 15, toMinutes(booking.occupied_end)));
  const top = ((start - DAY_START) / (DAY_END - DAY_START)) * PX;
  const height = Math.max(19, ((end - start) / (DAY_END - DAY_START)) * PX);
  return { top: `${top}px`, height: `${Math.min(height, PX - top)}px` };
}

export default function Timeline({
  bookings = [],
  machines = [],
  days = 14,
  today,
  weather = [],
  breakdowns = [],
  role = "owner",
  onSelectBooking,
}) {
  const weatherByDate = new Map(weather.map((block) => [block.date, block]));
  const dayList = Array.from({ length: days }, (_, index) => addDaysISO(today, index));
  const grid = { gridTemplateColumns: `repeat(${days}, minmax(0, 1fr))` };

  if (!machines.length) {
    return (
      <div className="timeline-card">
        <Empty
          icon="tractor"
          title={role === "owner" ? "No machines scheduled yet" : "No jobs booked yet"}
          text={
            role === "owner"
              ? "Add a machine and approve a request, then run the optimizer to fill this timeline."
              : "Once an owner schedules one of your requests, its block appears here."
          }
        />
      </div>
    );
  }

  return (
    <div className="timeline-card">
      <div className="timeline-scroll">
        <div className="timeline">
          <div className="tl-head">
            <div className="tl-corner">
              Machine · {days} days
            </div>
            <div className="tl-days" style={grid}>
              {dayList.map((day) => {
                const isToday = day === today;
                const rain = weatherByDate.get(day);
                return (
                  <div
                    className={`tl-day-head ${isToday ? "today" : ""} ${rain ? "rain" : ""}`}
                    key={day}
                    title={rain ? `Rain: ${rain.reason}` : undefined}
                  >
                    <span className="dow">{parseDay(day).toLocaleDateString(undefined, { weekday: "short" })}</span>
                    <span className="dom">{fmtDayMonth(day)}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {machines.map((machine) => {
            const broken = breakdowns.filter((block) => block.equipment_id === machine.id);
            return (
              <div className="tl-row" key={machine.id}>
                <div className="tl-label">
                  <div className="tl-machine-name">
                    <MachineIcon type={machine.type} size={15} />
                    {machine.name}
                  </div>
                  <div className="tl-machine-sub">
                    {typeLabel(machine.type)} · {machine.work_rate} ac/h
                    {machine.status === "broken" ? " · broken" : ""}
                  </div>
                </div>
                <div className="tl-days" style={grid}>
                  {dayList.map((day) => {
                    const rows = bookings.filter(
                      (booking) => booking.equipment_id === machine.id && booking.date === day,
                    );
                    const rain = weatherByDate.get(day);
                    const isBroken = broken.some((block) => block.start_date <= day && day <= block.end_date);
                    return (
                      <div
                        className={`tl-day ${rain ? "rain" : ""} ${isBroken ? "broken" : ""}`}
                        key={day}
                        title={
                          isBroken
                            ? `Broken: ${broken.find((block) => block.start_date <= day && day <= block.end_date)?.note || ""}`
                            : rain
                              ? `Rain: ${rain.reason}`
                              : undefined
                        }
                      >
                        {rows.map((booking) => {
                          const moved = booking.created_by === "reschedule" || booking.request_status === "rescheduled";
                          return (
                            <button
                              type="button"
                              key={booking.id}
                              className={`tl-block ${moved ? "rescheduled" : ""} ${
                                role === "farmer" ? "farmer-owned" : ""
                              }`}
                              style={blockStyle(booking)}
                              onClick={() => onSelectBooking?.(booking)}
                              title={`${booking.plot_name} — ${booking.start_time}–${booking.end_time} (incl. travel + setup). ${
                                role === "owner" ? booking.farmer_name : booking.equipment_name
                              }`}
                            >
                              <span className="b-plot">{booking.plot_name}</span>
                              <span className="b-time">{fmtTimeRange(booking.start_time, booking.end_time)}</span>
                            </button>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <div className="tl-legend">
        <span className="tl-key">
          <i style={{ background: "linear-gradient(150deg,#35774f,#1e5336)" }} /> Booked job
        </span>
        <span className="tl-key">
          <i style={{ background: "linear-gradient(150deg,#b57841,#8a5326)" }} /> Moved by rain / breakdown
        </span>
        <span className="tl-key">
          <i className="rain-swatch" /> Rain day
        </span>
        <span className="tl-key">
          <i className="broken-swatch" /> Machine broken
        </span>
        <span className="tl-key">
          <Icon name="info" size={11} /> Blocks include travel + 30 min setup
        </span>
      </div>
    </div>
  );
}
