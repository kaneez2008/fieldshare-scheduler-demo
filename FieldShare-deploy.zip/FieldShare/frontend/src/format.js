export function parseDay(value) {
  if (!value) return null;
  const [y, m, d] = value.slice(0, 10).split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function todayISO() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(
    now.getDate(),
  ).padStart(2, "0")}`;
}

export function addDaysISO(value, days) {
  const d = typeof value === "string" ? parseDay(value) : new Date(value);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;
}

export function fmtDate(value, { weekday = false, year = true, short = false } = {}) {
  const d = parseDay(value);
  if (!d) return "—";
  const options = { day: "numeric", month: short ? "short" : "short" };
  if (weekday) options.weekday = "short";
  if (year) options.year = "numeric";
  return d.toLocaleDateString(undefined, options);
}

export function fmtDayMonth(value) {
  const d = parseDay(value);
  if (!d) return "—";
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short" });
}

export function fmtTime(hm) {
  if (!hm || !hm.includes(":")) return "—";
  const [h, m] = hm.split(":").map(Number);
  const suffix = h >= 12 ? "PM" : "AM";
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${String(m).padStart(2, "0")} ${suffix}`;
}

export function fmtTimeRange(start, end) {
  if (!start || !end) return "—";
  return `${fmtTime(start)} – ${fmtTime(end)}`;
}

export function fmtMinutes(mins) {
  const m = Math.round(Number(mins) || 0);
  const h = Math.floor(m / 60);
  const rest = m % 60;
  if (h && rest) return `${h} h ${rest} min`;
  if (h) return `${h} h`;
  return `${rest} min`;
}

export function money(value) {
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
  }).format(Number(value) || 0);
}

export function acres(value) {
  return `${Number(value || 0).toLocaleString(undefined, { maximumFractionDigits: 1 })} ac`;
}

export function km(value) {
  return `${Number(value || 0).toLocaleString(undefined, { maximumFractionDigits: 1 })} km`;
}

export function relativeTime(iso) {
  if (!iso) return "";
  const then = new Date(iso).getTime();
  const seconds = Math.round((Date.now() - then) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  const days = Math.round(hours / 24);
  if (days < 7) return `${days} d ago`;
  return new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short" });
}

export function daysUntil(value) {
  const d = parseDay(value);
  if (!d) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((d.getTime() - today.getTime()) / 86400000);
}

export function deadlineText(days) {
  if (days < 0) return `${Math.abs(days)} day${Math.abs(days) === 1 ? "" : "s"} overdue`;
  if (days === 0) return "due today";
  if (days === 1) return "1 day left";
  return `${days} days left`;
}

export function haversineKm(a, b) {
  if (!a || !b) return 0;
  const R = 6371.0088;
  const rad = (x) => (x * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export const STATUS = {
  pending: { label: "Waiting for owner", tone: "amber" },
  accepted: { label: "Approved", tone: "blue" },
  scheduled: { label: "Scheduled", tone: "green" },
  rescheduled: { label: "Rescheduled", tone: "orange" },
  unfulfilled: { label: "Not scheduled", tone: "red" },
  rejected: { label: "Declined", tone: "gray" },
};

export const RISK = {
  high: { label: "At risk", tone: "red" },
  medium: { label: "Tight", tone: "amber" },
  low: { label: "On track", tone: "green" },
};

export const OPERATIONS = {
  sowing: { label: "Sowing", types: ["tractor", "seeder"] },
  spraying: { label: "Spraying", types: ["sprayer"] },
  harvesting: { label: "Harvesting", types: ["harvester"] },
};

export const MACHINE_TYPES = {
  tractor: { label: "Tractor", icon: "tractor" },
  harvester: { label: "Harvester", icon: "harvester" },
  sprayer: { label: "Sprayer", icon: "sprayer" },
  seeder: { label: "Seeder", icon: "seeder" },
};

export function opLabel(op) {
  return OPERATIONS[op]?.label || op;
}

export function typeLabel(type) {
  return MACHINE_TYPES[type]?.label || type;
}

export function rateLabel(type) {
  return type === "per_acre" ? "per acre" : "per hour";
}

export function plural(n, word) {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

export function initials(name = "") {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase();
}
