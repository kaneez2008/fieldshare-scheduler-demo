"""Tiny database adapter.

Runs on real MongoDB through PyMongo when it is reachable. When no MongoDB
server is running (common on a fresh demo machine) it transparently falls back
to a persistent, file-backed document store with the same small API, so the app
always starts. Set MONGODB_URI to point at a MongoDB instance to use it.
"""

from __future__ import annotations

import copy
import json
import os
import threading
import uuid
from pathlib import Path
from typing import Any, Callable, Iterable

from . import config


def _matches(doc: dict, filt: dict | None) -> bool:
    if not filt:
        return True
    for key, expected in filt.items():
        actual = doc.get(key)
        if isinstance(expected, dict):
            for op, val in expected.items():
                if op == "$in" and actual not in val:
                    return False
                if op == "$nin" and actual in val:
                    return False
                if op == "$ne" and actual == val:
                    return False
                if op == "$gte" and not (actual is not None and actual >= val):
                    return False
                if op == "$lte" and not (actual is not None and actual <= val):
                    return False
                if op == "$gt" and not (actual is not None and actual > val):
                    return False
                if op == "$lt" and not (actual is not None and actual < val):
                    return False
        elif actual != expected:
            return False
    return True


class Database:
    def __init__(self) -> None:
        self.kind = "json"
        self._lock = threading.RLock()
        self._client = None
        self._db = None
        self._path: Path = config.JSON_STORE_PATH
        self._memory: dict[str, list[dict]] = {}
        self._connect()

    # ------------------------------------------------------------------ setup
    def _connect(self) -> None:
        try:
            from pymongo import MongoClient
            from pymongo.errors import PyMongoError

            client = MongoClient(config.MONGODB_URI, serverSelectionTimeoutMS=900)
            client.admin.command("ping")
            self._client = client
            self._db = client[config.MONGODB_DB]
            self.kind = "mongodb"
            self._ensure_indexes()
            print(f"[db] connected to MongoDB at {config.MONGODB_URI}/{config.MONGODB_DB}")
            return
        except Exception as exc:  # noqa: BLE001 - fallback is intentional
            print(f"[db] MongoDB unavailable ({type(exc).__name__}); using embedded JSON store")

        self._path.parent.mkdir(parents=True, exist_ok=True)
        if self._path.exists():
            try:
                self._memory = json.loads(self._path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                self._memory = {}
        self._memory.setdefault("_meta", [])

    def _ensure_indexes(self) -> None:
        try:
            for name in ("sessions", "bookings", "requests", "notifications", "weather_blocks"):
                self._db[name].create_index([("_id", 1)])
            self._db["bookings"].create_index([("equipment_id", 1), ("date", 1)])
            self._db["requests"].create_index([("farmer_id", 1), ("status", 1)])
            self._db["notifications"].create_index([("user_id", 1), ("created_at", -1)])
            self._db["weather_blocks"].create_index([("date", 1)], unique=True)
        except Exception:  # index creation must never block startup
            pass

    def _coll(self, name: str):
        return self._db[name]

    def _save(self) -> None:
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._memory, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, self._path)

    # ------------------------------------------------------------------ reads
    def find(self, name: str, filt: dict | None = None, sort: str | None = None) -> list[dict]:
        if self.kind == "mongodb":
            cursor = self._coll(name).find(filt or {})
            if sort:
                cursor = cursor.sort(sort, 1)
            return [copy.deepcopy(d) for d in cursor]
        with self._lock:
            docs = [copy.deepcopy(d) for d in self._memory.get(name, []) if _matches(d, filt)]
            if sort:
                docs.sort(key=lambda d: (d.get(sort) is None, d.get(sort)))
            return docs

    def get(self, name: str, doc_id: str | None) -> dict | None:
        if not doc_id:
            return None
        if self.kind == "mongodb":
            doc = self._coll(name).find_one({"_id": doc_id})
            return copy.deepcopy(doc) if doc else None
        with self._lock:
            for doc in self._memory.get(name, []):
                if doc.get("_id") == doc_id:
                    return copy.deepcopy(doc)
            return None

    def find_one(self, name: str, filt: dict) -> dict | None:
        docs = self.find(name, filt)
        return docs[0] if docs else None

    def count(self, name: str, filt: dict | None = None) -> int:
        if self.kind == "mongodb":
            return self._coll(name).count_documents(filt or {})
        with self._lock:
            return sum(1 for d in self._memory.get(name, []) if _matches(d, filt))

    # ----------------------------------------------------------------- writes
    def insert(self, name: str, doc: dict) -> dict:
        doc = copy.deepcopy(doc)
        doc.setdefault("_id", uuid.uuid4().hex)
        if self.kind == "mongodb":
            self._coll(name).insert_one(copy.deepcopy(doc))
        else:
            with self._lock:
                self._memory.setdefault(name, []).append(doc)
                self._save()
        return copy.deepcopy(doc)

    def insert_many(self, name: str, docs: Iterable[dict]) -> list[dict]:
        out = []
        for doc in docs:
            out.append(self.insert(name, doc))
        return out

    def update(self, name: str, doc_id: str, changes: dict) -> dict | None:
        if self.kind == "mongodb":
            if changes:
                self._coll(name).update_one({"_id": doc_id}, {"$set": copy.deepcopy(changes)})
            doc = self._coll(name).find_one({"_id": doc_id})
            return copy.deepcopy(doc) if doc else None
        with self._lock:
            for doc in self._memory.get(name, []):
                if doc.get("_id") == doc_id:
                    doc.update(copy.deepcopy(changes))
                    self._save()
                    return copy.deepcopy(doc)
            return None

    def replace(self, name: str, doc_id: str, doc: dict) -> dict:
        doc = copy.deepcopy(doc)
        doc["_id"] = doc_id
        if self.kind == "mongodb":
            self._coll(name).replace_one({"_id": doc_id}, doc, upsert=True)
        else:
            with self._lock:
                docs = self._memory.setdefault(name, [])
                for i, existing in enumerate(docs):
                    if existing.get("_id") == doc_id:
                        docs[i] = doc
                        break
                else:
                    docs.append(doc)
                self._save()
        return copy.deepcopy(doc)

    def delete(self, name: str, filt: dict) -> int:
        if self.kind == "mongodb":
            return self._coll(name).delete_many(filt).deleted_count
        with self._lock:
            docs = self._memory.get(name, [])
            keep = [d for d in docs if not _matches(d, filt)]
            removed = len(docs) - len(keep)
            self._memory[name] = keep
            if removed:
                self._save()
            return removed

    def delete_where(self, name: str, predicate: Callable[[dict], bool]) -> int:
        if self.kind == "mongodb":
            ids = [d["_id"] for d in self.find(name) if predicate(d)]
            if ids:
                return self.delete(name, {"_id": {"$in": ids}})
            return 0
        with self._lock:
            docs = self._memory.get(name, [])
            keep = [d for d in docs if not predicate(d)]
            removed = len(docs) - len(keep)
            self._memory[name] = keep
            if removed:
                self._save()
            return removed

    def wipe(self) -> None:
        if self.kind == "mongodb":
            for name in self._client[config.MONGODB_DB].list_collection_names():
                if not name.startswith("system."):
                    self._coll(name).delete_many({})
            return
        with self._lock:
            self._memory = {"_meta": []}
            self._save()


db = Database()
