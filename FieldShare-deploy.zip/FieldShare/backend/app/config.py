import os
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = BACKEND_DIR.parent
DATA_DIR = BACKEND_DIR / "data"
FRONTEND_DIST = PROJECT_DIR / "frontend" / "dist"

MONGODB_URI = os.environ.get("MONGODB_URI", "mongodb://127.0.0.1:27017")
MONGODB_DB = os.environ.get("MONGODB_DB", "fieldshare")
JSON_STORE_PATH = Path(os.environ.get("FIELD_SHARE_STORE", DATA_DIR / "store.json"))

WORKDAY_START = 7 * 60          # 07:00, minutes from midnight
WORKDAY_END = 19 * 60           # 19:00
SETUP_MINUTES = 30
TRAVEL_KMH = 20.0
SCHEDULE_HORIZON_DAYS = 30      # how far beyond a deadline we look for suggestions
AT_RISK_DAYS = 3
SEED_VERSION = 1
