"""Realistic demo data: 3 owners, 5 farmers, 8 machines, 12 plots and 15
requests with deliberate deadline conflicts, a rain day and a broken sprayer."""

from __future__ import annotations

import hashlib
from datetime import date, datetime, timedelta, timezone

from . import config
from .db import db
from .scheduling import Scheduler, iso, parse_date
from .services import (
    build_booking_explanation,
    load_ctx,
    notify,
    now_iso,
    refresh_machine_statuses,
)


def _hash_password(password: str) -> str:
    return hashlib.sha256(f"fieldshare::{password}".encode()).hexdigest()


def _days(today: date, n: int) -> str:
    return iso(today + timedelta(days=n))


def seed_if_needed() -> bool:
    meta = db.find_one("_meta", {"key": "seed_version"})
    if meta and meta.get("value") == config.SEED_VERSION:
        refresh_machine_statuses()
        return False
    seed(force=False)
    return True


def reset_demo() -> None:
    seed(force=True)


def seed(force: bool = True) -> None:
    today = date.today()
    now = datetime.now(timezone.utc)
    db.wipe()

    def uid() -> str:
        import uuid
        return uuid.uuid4().hex

    # ------------------------------------------------------------------ users
    owners = [
        {
            "name": "Rajesh Patel",
            "farm_name": "Patel Machinery",
            "email": "rajesh@patelmachinery.demo",
            "phone": "(559) 555-0142",
            "lat": 36.8002,
            "lng": -119.8701,
        },
        {
            "name": "Maria Gonzalez",
            "farm_name": "Valley Ag Services",
            "email": "maria@valleyag.demo",
            "phone": "(559) 555-0177",
            "lat": 36.6902,
            "lng": -119.7602,
        },
        {
            "name": "Tom Becker",
            "farm_name": "Becker Equipment Co.",
            "email": "tom@beckerequipment.demo",
            "phone": "(559) 555-0119",
            "lat": 36.7703,
            "lng": -119.6204,
        },
    ]
    farmers = [
        {
            "name": "Amrit Singh",
            "farm_name": "Singh Family Farm",
            "email": "amrit@singhfarm.demo",
            "phone": "(559) 555-0210",
            "lat": 36.7352,
            "lng": -119.8003,
        },
        {
            "name": "Luis Romero",
            "farm_name": "Romero Orchards",
            "email": "luis@romero.demo",
            "phone": "(559) 555-0233",
            "lat": 36.8151,
            "lng": -119.7352,
        },
        {
            "name": "Grace Okafor",
            "farm_name": "Okafor Produce",
            "email": "grace@okafor.demo",
            "phone": "(559) 555-0248",
            "lat": 36.7058,
            "lng": -119.8451,
        },
        {
            "name": "David Chen",
            "farm_name": "Chen Row Crops",
            "email": "david@chenrows.demo",
            "phone": "(559) 555-0261",
            "lat": 36.7521,
            "lng": -119.6903,
        },
        {
            "name": "Fatima Noor",
            "farm_name": "Noor Fields",
            "email": "fatima@noorfields.demo",
            "phone": "(559) 555-0276",
            "lat": 36.7952,
            "lng": -119.7002,
        },
    ]

    user_ids: dict[str, str] = {}
    for owner in owners:
        doc = db.insert(
            "users",
            {
                **owner,
                "role": "owner",
                "password_hash": _hash_password("demo123"),
                "created_at": (now - timedelta(days=90)).isoformat(),
            },
        )
        user_ids[owner["email"]] = doc["_id"]
    for farmer in farmers:
        doc = db.insert(
            "users",
            {
                **farmer,
                "role": "farmer",
                "password_hash": _hash_password("demo123"),
                "created_at": (now - timedelta(days=60)).isoformat(),
            },
        )
        user_ids[farmer["email"]] = doc["_id"]

    owner1 = user_ids["rajesh@patelmachinery.demo"]
    owner2 = user_ids["maria@valleyag.demo"]
    owner3 = user_ids["tom@beckerequipment.demo"]
    amrit = user_ids["amrit@singhfarm.demo"]
    luis = user_ids["luis@romero.demo"]
    grace = user_ids["grace@okafor.demo"]
    david = user_ids["david@chenrows.demo"]
    fatima = user_ids["fatima@noorfields.demo"]

    # ------------------------------------------------------------------ plots
    plot_rows = [
        (amrit, "North 40", 12.0, "Wheat", 36.7421, -119.7922),
        (amrit, "Creek Bottom", 6.5, "Alfalfa", 36.7291, -119.8121),
        (luis, "Orchard East", 9.0, "Almonds", 36.8222, -119.7271),
        (luis, "Orchard West", 7.0, "Almonds", 36.8081, -119.7453),
        (grace, "Home Field", 14.0, "Corn", 36.7122, -119.8521),
        (grace, "River Plot", 5.0, "Tomatoes", 36.6981, -119.8332),
        (david, "South Quarter", 18.0, "Soybeans", 36.7581, -119.6811),
        (david, "Hilltop", 4.5, "Canola", 36.7440, -119.7002),
        (fatima, "Sunrise Field", 11.0, "Barley", 36.8031, -119.6922),
        (fatima, "Long Strip", 8.0, "Cotton", 36.7880, -119.7091),
        (fatima, "Pumpkin Patch", 3.0, "Pumpkins", 36.7981, -119.7122),
        (fatima, "Dry Creek", 10.0, "Wheat", 36.7801, -119.6881),
    ]
    plot_ids: dict[tuple[str, str], str] = {}
    for farmer_id, name, area, crop, lat, lng in plot_rows:
        doc = db.insert(
            "plots",
            {
                "farmer_id": farmer_id,
                "name": name,
                "area": area,
                "crop": crop,
                "lat": lat,
                "lng": lng,
                "created_at": (now - timedelta(days=45)).isoformat(),
                "notes": "",
            },
        )
        plot_ids[(farmer_id, name)] = doc["_id"]

    # --------------------------------------------------------------- machines
    machine_rows = [
        (owner1, "Green Giant", "tractor", "hourly", 55.0, 3.2, 36.8002, -119.8701, "Active workhorse for tillage and sowing."),
        (owner1, "Harvest King", "harvester", "per_acre", 48.0, 3.5, 36.8002, -119.8701, "Combine harvester, 2019 model."),
        (owner2, "Little Red", "tractor", "hourly", 48.0, 2.8, 36.6902, -119.7602, "Compact tractor for small plots."),
        (owner2, "SeedMaster", "seeder", "per_acre", 22.0, 5.0, 36.6902, -119.7602, "Precision row seeder."),
        (owner2, "Swift Sprayer", "sprayer", "hourly", 70.0, 7.0, 36.6902, -119.7602, "Boom sprayer, 18 m width."),
        (owner3, "Big Blue", "harvester", "per_acre", 52.0, 4.0, 36.7703, -119.6204, "New combine, low hours."),
        (owner3, "Drill Pro", "seeder", "hourly", 60.0, 4.5, 36.7703, -119.6204, "No-till drill."),
        (owner3, "RainMaker", "sprayer", "hourly", 65.0, 6.5, 36.7703, -119.6204, "Orchard and field sprayer."),
    ]
    machine_ids: dict[str, str] = {}
    for owner_id, name, mtype, rate_type, rate, work_rate, lat, lng, notes in machine_rows:
        doc = db.insert(
            "equipment",
            {
                "owner_id": owner_id,
                "name": name,
                "type": mtype,
                "rate_type": rate_type,
                "rate": rate,
                "work_rate": work_rate,
                "lat": lat,
                "lng": lng,
                "status": "active",
                "notes": notes,
                "created_at": (now - timedelta(days=70)).isoformat(),
            },
        )
        machine_ids[name] = doc["_id"]

    # ------------------------------------------------------------- disruptions
    db.insert(
        "weather_blocks",
        {
            "date": _days(today, 2),
            "reason": "Heavy rain forecast (18 mm) — fields too wet for machinery.",
            "created_at": now_iso(),
        },
    )
    db.insert(
        "breakdowns",
        {
            "equipment_id": machine_ids["RainMaker"],
            "start_date": _days(today, 1),
            "end_date": _days(today, 4),
            "note": "Hydraulic pump failure — waiting for parts.",
            "created_at": now_iso(),
        },
    )
    db.insert(
        "breakdowns",
        {
            "equipment_id": machine_ids["Little Red"],
            "start_date": _days(today, 0),
            "end_date": _days(today, 2),
            "note": "Engine repair at the workshop.",
            "created_at": now_iso(),
        },
    )
    refresh_machine_statuses()

    # ---------------------------------------------------------------- requests
    request_rows = [
        # farmer, plot, operation, preferred, owner, start, end, status, note
        (amrit, "North 40", "harvesting", "harvester", owner1, 1, 2, "accepted", ""),
        (luis, "Orchard East", "harvesting", "harvester", owner1, 2, 6, "accepted", ""),
        (grace, "Home Field", "harvesting", "harvester", owner3, 1, 3, "accepted", ""),
        (david, "South Quarter", "sowing", "seeder", owner2, 1, 5, "accepted", ""),
        (fatima, "Sunrise Field", "sowing", "tractor", owner1, 3, 8, "accepted", ""),
        (amrit, "Creek Bottom", "spraying", "sprayer", owner2, 2, 5, "accepted", ""),
        (grace, "River Plot", "spraying", "sprayer", owner2, 2, 4, "accepted", ""),
        (fatima, "Long Strip", "spraying", "sprayer", owner3, 2, 4, "accepted", ""),
        (david, "Hilltop", "sowing", "seeder", owner2, 1, 2, "pending", ""),
        (luis, "Orchard West", "harvesting", "harvester", owner3, 3, 5, "accepted", ""),
        (fatima, "Pumpkin Patch", "harvesting", "harvester", owner1, 1, 2, "pending", ""),
        (fatima, "Dry Creek", "sowing", "tractor", owner1, 1, 3, "rejected", ""),
        (amrit, "North 40", "spraying", "sprayer", owner2, 4, 6, "pending", ""),
        (grace, "Home Field", "harvesting", "harvester", owner3, 9, 12, "accepted", ""),
        (david, "South Quarter", "harvesting", "harvester", owner1, 1, 2, "accepted", ""),
    ]
    request_ids: list[str] = []
    for index, (farmer_id, plot_name, operation, preferred, owner_id, start, end, status, note) in enumerate(request_rows):
        created = now - timedelta(hours=40 - index * 2)
        doc = db.insert(
            "requests",
            {
                "farmer_id": farmer_id,
                "plot_id": plot_ids[(farmer_id, plot_name)],
                "owner_id": owner_id,
                "operation": operation,
                "window_start": _days(today, start),
                "window_end": _days(today, end),
                "preferred_type": preferred,
                "status": status,
                "reason": note,
                "explanation": "",
                "priority_note": "",
                "suggestion": "",
                "booking_id": None,
                "created_at": created.isoformat(),
            },
        )
        request_ids.append(doc["_id"])

    # Notify owners about new requests, farmers about decisions.
    for index, req_id in enumerate(request_ids):
        req = db.get("requests", req_id)
        plot = db.get("plots", req["plot_id"])
        farmer = db.get("users", req["farmer_id"])
        owner_label = db.get("users", req["owner_id"])["farm_name"]
        if req["status"] == "pending":
            notify(
                req["owner_id"],
                f"New {req['operation']} request",
                f"{farmer['name']} asked for a {req['preferred_type']} for {plot['name']} "
                f"({plot['area']:g} acres) between {req['window_start']} and {req['window_end']}.",
                "info",
                req_id,
            )
        elif req["status"] == "rejected":
            req["reason"] = "Owner declined: the tractor is already committed to my own sowing this week."
            db.update("requests", req_id, {"reason": req["reason"]})
            notify(
                req["farmer_id"],
                "Request declined",
                f"{owner_label} declined the {req['operation']} request for {plot['name']}. "
                f"Reason: {req['reason']}",
                "warning",
                req_id,
            )
        else:
            notify(
                req["owner_id"],
                f"Request approved for {plot['name']}",
                f"You approved {farmer['name']}'s {req['operation']} request. "
                f"Use Optimize Schedule to assign a machine.",
                "success",
                req_id,
            )
            notify(
                req["farmer_id"],
                "Request approved",
                f"{owner_label} approved your {req['operation']} request for {plot['name']}. "
                f"It is waiting to be scheduled.",
                "success",
                req_id,
            )

    # --------------------------------------------------------- run optimizer
    ctx = load_ctx()
    accepted = [
        r for r in db.find("requests") if r["status"] == "accepted"
    ]
    scheduler = Scheduler(
        equipment=ctx.equipment,
        plots=ctx.plots,
        bookings=[],
        users_by_id=ctx.users_by_id,
        weather_days=ctx.weather_days,
        breakdowns=ctx.breakdowns,
        today=today,
    )
    outcome = scheduler.schedule(accepted)
    notes = {r["request"]["_id"]: r.get("priority_note", "") for r in outcome["results"]}

    for result in outcome["results"]:
        request = result["request"]
        req_id = request["_id"]
        plot = ctx.plots_by_id.get(request["plot_id"], {})
        owner = ctx.users_by_id.get(request["owner_id"], {})
        if result["ok"]:
            booking = db.insert("bookings", result["booking"])
            explanation = build_booking_explanation(request, {**booking, "_id": booking["_id"]}, load_ctx())
            db.update(
                "requests",
                req_id,
                {
                    "status": "scheduled",
                    "booking_id": booking["_id"],
                    "explanation": explanation,
                    "priority_note": notes.get(req_id, ""),
                    "suggestion": "",
                    "reason": "",
                },
            )
            notify(
                request["farmer_id"],
                f"{request['operation'].capitalize()} scheduled for {plot.get('name')}",
                explanation,
                "success",
                req_id,
                booking["_id"],
            )
            notify(
                request["owner_id"],
                f"{result['machine']['name']} assigned to {plot.get('name')}",
                f"{plot.get('name')} is booked on {booking['date']} from {booking['start_time']} "
                f"to {booking['end_time']}. Travel {booking['travel_time']} min + setup 30 min is included.",
                "info",
                req_id,
                booking["_id"],
            )
        else:
            suggestion = scheduler.suggestion_for(request)
            reason = result["reason"]
            db.update(
                "requests",
                req_id,
                {
                    "status": "unfulfilled",
                    "booking_id": None,
                    "reason": reason,
                    "explanation": reason,
                    "suggestion": suggestion,
                },
            )
            notify(
                request["farmer_id"],
                f"Cannot schedule {plot.get('name')} yet",
                f"{reason} {suggestion}",
                "danger",
                req_id,
            )
            notify(
                request["owner_id"],
                f"Request could not be scheduled: {plot.get('name')}",
                reason,
                "warning",
                req_id,
            )

    # A recent weather alert for everyone.
    for user in db.find("users"):
        notify(
            user["_id"],
            "Heavy rain expected in 2 days",
            "The scheduler has blocked that day for field work. If rain dates change, use "
            "'Simulate heavy rain' on the schedule page and affected jobs will be re-planned automatically.",
            "info",
        )

    db.insert(
        "_meta",
        {
            "key": "seed_version",
            "value": config.SEED_VERSION,
            "seeded_at": now_iso(),
            "demo_today": iso(today),
        },
    )
    print("[seed] demo data created")
