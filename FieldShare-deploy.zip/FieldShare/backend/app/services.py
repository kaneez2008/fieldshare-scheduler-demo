"""Shared helpers: context loading, plain-language explanations, notifications
and public API representations."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone

from . import config
from .db import db
from .scheduling import (
    cost_estimate,
    deadline_days,
    fmt_date,
    fmt_duration,
    parse_date,
    is_broken,
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def public(doc: dict | None) -> dict | None:
    if doc is None:
        return None
    out = dict(doc)
    out["id"] = out.pop("_id")
    return out


@dataclass
class Ctx:
    today: date
    users: list[dict]
    users_by_id: dict[str, dict]
    equipment: list[dict]
    equipment_by_id: dict[str, dict]
    plots: list[dict]
    plots_by_id: dict[str, dict]
    requests: list[dict]
    requests_by_id: dict[str, dict]
    bookings: list[dict]
    bookings_by_id: dict[str, dict]
    bookings_by_request: dict[str, dict]
    weather: list[dict]
    weather_days: set[str]
    breakdowns: list[dict]

    def user(self, uid: str | None) -> dict:
        return self.users_by_id.get(uid or "", {})

    def owner_label(self, machine: dict) -> str:
        owner = self.user(machine.get("owner_id"))
        return owner.get("farm_name") or owner.get("name") or "Owner"


def load_ctx() -> Ctx:
    users = db.find("users", sort="name")
    equipment = db.find("equipment", sort="name")
    plots = db.find("plots", sort="name")
    requests = db.find("requests", sort="created_at")
    bookings = db.find("bookings", sort="date")
    weather = db.find("weather_blocks", sort="date")
    breakdowns = db.find("breakdowns", sort="start_date")
    return Ctx(
        today=date.today(),
        users=users,
        users_by_id={u["_id"]: u for u in users},
        equipment=equipment,
        equipment_by_id={m["_id"]: m for m in equipment},
        plots=plots,
        plots_by_id={p["_id"]: p for p in plots},
        requests=requests,
        requests_by_id={r["_id"]: r for r in requests},
        bookings=bookings,
        bookings_by_id={b["_id"]: b for b in bookings},
        bookings_by_request={b["request_id"]: b for b in bookings},
        weather=weather,
        weather_days={w["date"] for w in weather},
        breakdowns=breakdowns,
    )


# --------------------------------------------------------------- notifications
def notify(
    user_id: str,
    title: str,
    body: str,
    kind: str = "info",
    request_id: str | None = None,
    booking_id: str | None = None,
) -> dict:
    return db.insert(
        "notifications",
        {
            "user_id": user_id,
            "title": title,
            "body": body,
            "kind": kind,
            "request_id": request_id,
            "booking_id": booking_id,
            "read": False,
            "created_at": now_iso(),
        },
    )


def notification_public(doc: dict) -> dict:
    return public(doc)


# --------------------------------------------------------------- explanations
def build_booking_explanation(
    request: dict,
    booking: dict,
    ctx: Ctx,
) -> str:
    plot = ctx.plots_by_id.get(request["plot_id"], {})
    machine = ctx.equipment_by_id.get(booking["equipment_id"], {})
    owner = ctx.users_by_id.get(machine.get("owner_id"), {})
    owner_label = owner.get("farm_name") or owner.get("name") or "the owner"
    buffer = deadline_days(request["window_end"], parse_date(booking["date"]))
    if buffer <= 0:
        buffer_text = f"right on your deadline ({fmt_date(request['window_end'])})"
    elif buffer == 1:
        buffer_text = f"1 day before your deadline ({fmt_date(request['window_end'])})"
    else:
        buffer_text = f"{buffer} days before your deadline ({fmt_date(request['window_end'])})"
    cost = cost_estimate(plot.get("area", 0), machine, int(booking.get("job_minutes", 0)))
    rate_unit = "acre" if machine.get("rate_type") == "per_acre" else "hour"
    rate_line = f" Estimated cost ${cost:,.2f} ({machine.get('rate_type', 'hourly').replace('_', ' ')} rate ${machine.get('rate', 0):,.2f}/{rate_unit})." if machine else ""
    travel_from = booking.get("travel_from", "the machine base")
    if not str(travel_from).startswith("Plot") and travel_from != "the machine base":
        travel_from = f"Plot {travel_from}"
    return (
        f"{machine.get('name', 'A machine')} from {owner_label} is booked for {plot.get('name', 'the plot')} "
        f"on {fmt_date(booking['date'])}, {booking['start_time']}–{booking['end_time']}. "
        f"The job takes {fmt_duration(int(booking.get('job_minutes', 0)))} "
        f"({plot.get('area', 0):g} acres at {machine.get('work_rate', 0):g} acres/hour), plus "
        f"{booking.get('setup_time', config.SETUP_MINUTES)} minutes setup and "
        f"{booking.get('travel_time', 0)} minutes travel from {travel_from}. "
        f"It finishes {buffer_text}.{rate_line}"
    )


def risk_for(req: dict, booking: dict | None, today: date) -> tuple[str, str]:
    """Return (level, plain note) for a request."""
    days_left = deadline_days(req["window_end"], today)
    status = req.get("status")
    if status == "unfulfilled":
        return "high", "No machine is assigned. This operation currently has no way to be completed in time."
    if status == "rejected":
        return "low", "The owner declined this request."
    if status in ("pending", "accepted"):
        if days_left < 0:
            return "high", f"The deadline ({fmt_date(req['window_end'])}) has passed and no machine was assigned."
        if days_left == 0:
            return "high", f"The deadline is today ({fmt_date(req['window_end'])}) and no machine is assigned yet."
        if days_left <= config.AT_RISK_DAYS:
            return "high", (
                f"The deadline is {fmt_date(req['window_end'])} — only {days_left} "
                f"day{'s' if days_left != 1 else ''} left and no machine is assigned yet."
            )
        return "low", f"Waiting for an owner to approve and schedule this job ({days_left} days left)."
    if status in ("scheduled", "rescheduled") and booking:
        buffer = (parse_date(req["window_end"]) - parse_date(booking["date"])).days
        if buffer <= 0:
            return "medium", (
                f"Scheduled on {fmt_date(booking['date'])}, the last possible day — there is no room "
                f"for a rain delay."
            )
        if buffer <= 2:
            return "medium", (
                f"Scheduled on {fmt_date(booking['date'])}, only {buffer} "
                f"day{'s' if buffer != 1 else ''} before the deadline ({fmt_date(req['window_end'])}). "
                f"A rain day now would leave no spare room."
            )
        return "low", (
            f"Scheduled on {fmt_date(booking['date'])}, {buffer} days before the deadline "
            f"({fmt_date(req['window_end'])})."
        )
    return "low", ""


# --------------------------------------------------------------- serializers
def equipment_public(machine: dict, ctx: Ctx) -> dict:
    today = ctx.today.isoformat()
    active = [
        b for b in ctx.breakdowns
        if b["equipment_id"] == machine["_id"] and b["start_date"] <= today <= b["end_date"]
    ]
    upcoming = [
        b for b in ctx.breakdowns
        if b["equipment_id"] == machine["_id"] and b["start_date"] > today
    ]
    status = "broken" if active or (machine.get("status") == "broken" and not upcoming and not [
        b for b in ctx.breakdowns if b["equipment_id"] == machine["_id"]
    ]) else "active"
    out = public(machine)
    owner = ctx.user(machine.get("owner_id"))
    out.update(
        {
            "owner_name": owner.get("name"),
            "owner_farm": owner.get("farm_name"),
            "owner_phone": owner.get("phone"),
            "status": status,
            "active_breakdown": public(active[0]) if active else None,
            "upcoming_breakdown": public(upcoming[0]) if upcoming else None,
            "breakdowns": [public(b) for b in ctx.breakdowns if b["equipment_id"] == machine["_id"]],
            "bookings_count": sum(1 for b in ctx.bookings if b["equipment_id"] == machine["_id"]),
        }
    )
    return out


def plot_public(plot: dict, ctx: Ctx) -> dict:
    farmer = ctx.user(plot.get("farmer_id"))
    out = public(plot)
    out.update(
        {
            "farmer_name": farmer.get("name"),
            "farmer_farm": farmer.get("farm_name"),
            "farmer_phone": farmer.get("phone"),
            "requests_count": sum(1 for r in ctx.requests if r["plot_id"] == plot["_id"]),
        }
    )
    return out


def booking_public(booking: dict, ctx: Ctx) -> dict:
    machine = ctx.equipment_by_id.get(booking["equipment_id"], {})
    plot = ctx.plots_by_id.get(booking["plot_id"], {})
    farmer = ctx.user(booking.get("farmer_id"))
    owner = ctx.user(booking.get("owner_id"))
    request = ctx.requests_by_id.get(booking["request_id"], {})
    out = public(booking)
    try:
        start_min = int(booking["start_time"][:2]) * 60 + int(booking["start_time"][3:])
        end_min = int(booking["end_time"][:2]) * 60 + int(booking["end_time"][3:])
        duration = end_min - start_min
    except Exception:
        duration = 0
    out.update(
        {
            "equipment_name": machine.get("name"),
            "equipment_type": machine.get("type"),
            "work_rate": machine.get("work_rate"),
            "rate": machine.get("rate"),
            "rate_type": machine.get("rate_type"),
            "owner_name": owner.get("name"),
            "owner_farm": owner.get("farm_name"),
            "farmer_name": farmer.get("name"),
            "farmer_farm": farmer.get("farm_name"),
            "plot_name": plot.get("name"),
            "plot_area": plot.get("area"),
            "plot_crop": plot.get("crop"),
            "plot_lat": plot.get("lat"),
            "plot_lng": plot.get("lng"),
            "operation": request.get("operation"),
            "window_end": request.get("window_end"),
            "request_status": request.get("status"),
            "duration_minutes": duration,
            "cost": cost_estimate(plot.get("area", 0), machine, int(booking.get("job_minutes", 0))),
            "is_blocked_by_weather": booking["date"] in ctx.weather_days,
        }
    )
    return out


def request_public(req: dict, ctx: Ctx) -> dict:
    farmer = ctx.user(req.get("farmer_id"))
    owner = ctx.user(req.get("owner_id"))
    plot = ctx.plots_by_id.get(req.get("plot_id"), {})
    booking = ctx.bookings_by_request.get(req["_id"])
    level, note = risk_for(req, booking, ctx.today)
    out = public(req)
    out.update(
        {
            "farmer_name": farmer.get("name"),
            "farmer_farm": farmer.get("farm_name"),
            "owner_name": owner.get("name"),
            "owner_farm": owner.get("farm_name"),
            "plot_name": plot.get("name"),
            "plot_area": plot.get("area"),
            "plot_crop": plot.get("crop"),
            "plot_lat": plot.get("lat"),
            "plot_lng": plot.get("lng"),
            "days_left": deadline_days(req["window_end"], ctx.today),
            "risk_level": level,
            "risk_note": note,
            "booking": booking_public(booking, ctx) if booking else None,
        }
    )
    return out


# --------------------------------------------------------------- status sync
def refresh_machine_statuses(ctx: Ctx | None = None) -> None:
    """Mirror today's breakdown state into the equipment status field."""
    ctx = ctx or load_ctx()
    today = ctx.today.isoformat()
    for machine in ctx.equipment:
        broken_now = any(
            b["equipment_id"] == machine["_id"] and b["start_date"] <= today <= b["end_date"]
            for b in ctx.breakdowns
        )
        desired = "broken" if broken_now else "active"
        if machine.get("status") != desired:
            db.update("equipment", machine["_id"], {"status": desired})
