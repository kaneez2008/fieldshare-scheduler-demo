"""Scheduling engine: durations, travel buffers, deadline priority and
disruption-aware re-optimisation.

All times are stored as "HH:MM" strings and dates as ISO "YYYY-MM-DD".
Every booking reserves [travel start .. job end] on a machine; setup and travel
are included, so two bookings can never overlap.

Rules
-----
job duration  = plot area / machine work rate        (rounded up to 5 min)
travel time   = haversine distance / 20 km/h
setup time    = 30 minutes
workday       = 07:00 .. 19:00 (12 hours)
"""

from __future__ import annotations

import math
import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Iterable

from . import config

OP_TYPES: dict[str, tuple[str, ...]] = {
    "sowing": ("tractor", "seeder"),
    "spraying": ("sprayer",),
    "harvesting": ("harvester",),
}
TYPE_LABEL = {
    "tractor": "tractor",
    "harvester": "harvester",
    "sprayer": "sprayer",
    "seeder": "seeder",
}
OP_LABEL = {"sowing": "sowing", "spraying": "spraying", "harvesting": "harvesting"}


class ScheduleError(ValueError):
    """Raised when a requested placement would break the no-clash rule."""


# ------------------------------------------------------------------ helpers
def parse_date(value: str | date) -> date:
    if isinstance(value, date):
        return value
    return date.fromisoformat(value[:10])


def iso(d: date) -> str:
    return d.isoformat()


def fmt_date(value: str | date) -> str:
    d = parse_date(value)
    return f"{d.day} {d.strftime('%b %Y')}"


def fmt_short_date(value: str | date) -> str:
    d = parse_date(value)
    return f"{d.day} {d.strftime('%b')}"


def fmt_duration(minutes: int) -> str:
    minutes = int(round(minutes))
    h, m = divmod(minutes, 60)
    if h and m:
        return f"{h} h {m} min"
    if h:
        return f"{h} h"
    return f"{m} min"


def hm_to_minutes(value: str) -> int:
    h, m = value.split(":")
    return int(h) * 60 + int(m)


def minutes_to_hm(value: int | float) -> str:
    value = int(round(value))
    h, m = divmod(value, 60)
    return f"{h:02d}:{m:02d}"


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def travel_minutes(from_point: tuple[float, float], to_point: tuple[float, float]) -> int:
    km = haversine_km(from_point[0], from_point[1], to_point[0], to_point[1])
    return max(0, int(round(km / config.TRAVEL_KMH * 60)))


def job_minutes(area: float, work_rate: float) -> int:
    if not work_rate or work_rate <= 0:
        raise ScheduleError("This machine has no valid work rate.")
    raw = float(area) / float(work_rate) * 60
    return max(15, int(math.ceil(raw / 5.0) * 5))


def operation_types(preferred_type: str) -> list[str]:
    base = list(OP_TYPES.get(preferred_type, ()))
    if preferred_type in base:
        base.remove(preferred_type)
        return [preferred_type, *base]
    return [preferred_type, *base]


def machine_can_do(machine: dict, operation: str) -> bool:
    return machine.get("type") in OP_TYPES.get(operation, ())


def machine_rank(machine: dict, preferred_type: str) -> int:
    order = operation_types(preferred_type)
    try:
        return order.index(machine.get("type", ""))
    except ValueError:
        return 99


def is_weather_blocked(day: str, weather_days: set[str]) -> bool:
    return day in weather_days


def is_broken(equipment_id: str, day: str, breakdowns: Iterable[dict]) -> bool:
    for breakdown in breakdowns:
        if breakdown.get("equipment_id") != equipment_id:
            continue
        if breakdown.get("start_date") <= day <= breakdown.get("end_date"):
            return True
    return False


def cost_estimate(area: float, machine: dict, duration_min: int) -> float:
    if machine.get("rate_type") == "per_acre":
        return round(area * float(machine.get("rate", 0)), 2)
    return round(duration_min / 60.0 * float(machine.get("rate", 0)), 2)


def deadline_days(window_end: str | date, today: date) -> int:
    return (parse_date(window_end) - today).days


def priority_key(request: dict) -> tuple:
    return (request.get("window_end", ""), request.get("created_at", ""), request.get("_id", ""))


def date_range(start: date, end: date) -> Iterable[date]:
    current = start
    while current <= end:
        yield current
        current += timedelta(days=1)


def format_days(n: int) -> str:
    if n < 0:
        return f"{-n} day{'s' if n != -1 else ''} ago"
    if n == 0:
        return "today"
    if n == 1:
        return "tomorrow"
    return f"in {n} days"


# ------------------------------------------------------------------ scheduler
class Scheduler:
    """Greedy deadline-priority scheduler over a set of fixed bookings."""

    def __init__(
        self,
        equipment: list[dict],
        plots: list[dict],
        bookings: list[dict],
        users_by_id: dict[str, dict],
        weather_days: set[str],
        breakdowns: list[dict],
        today: date,
    ) -> None:
        self.equipment = equipment
        self.equipment_by_id = {m["_id"]: m for m in equipment}
        self.plots = plots
        self.plot_by_id = {p["_id"]: p for p in plots}
        self.bookings = list(bookings)
        self.users_by_id = users_by_id
        self.weather_days = set(weather_days)
        self.breakdowns = list(breakdowns)
        self.today = today

    # ------------------------------------------------------------- utilities
    def _plot(self, plot_id: str) -> dict:
        return self.plot_by_id.get(plot_id, {})

    def _point(self, plot: dict) -> tuple[float, float]:
        return (float(plot.get("lat", 0)), float(plot.get("lng", 0)))

    def _owner_label(self, machine: dict) -> str:
        owner = self.users_by_id.get(machine.get("owner_id"), {})
        return owner.get("farm_name") or owner.get("name") or "the owner"

    def _day_bookings(self, equipment_id: str, day: str) -> list[dict]:
        rows = [
            b
            for b in self.bookings
            if b.get("equipment_id") == equipment_id and b.get("date") == day
        ]
        return sorted(rows, key=lambda b: (b.get("occupied_start", "00:00"), b.get("_id", "")))

    def machine_usable(self, machine: dict, day: str) -> bool:
        if machine.get("status") == "retired":
            return False
        return not is_broken(machine["_id"], day, self.breakdowns)

    # ------------------------------------------------------------ placement
    def _candidate(self, request: dict, machine: dict, day: date) -> dict | None:
        plot = self._plot(request["plot_id"])
        if not plot:
            return None
        duration = job_minutes(plot.get("area", 0), machine.get("work_rate", 0))
        day_str = iso(day)
        day_rows = self._day_bookings(machine["_id"], day_str)
        if day_rows:
            last = day_rows[-1]
            prev_end = hm_to_minutes(last["occupied_end"])
            from_plot = self._plot(last["plot_id"])
            from_point = self._point(from_plot)
            away_label = f"Plot {from_plot.get('name', 'previous job')}"
        else:
            prev_end = config.WORKDAY_START
            from_point = (float(machine.get("lat", 0)), float(machine.get("lng", 0)))
            away_label = "the machine base"

        travel = travel_minutes(from_point, self._point(plot))
        job_start = prev_end + travel + config.SETUP_MINUTES
        job_end = job_start + duration
        if job_end > config.WORKDAY_END:
            return None
        travel_start = job_start - travel - config.SETUP_MINUTES
        return {
            "_id": uuid.uuid4().hex,
            "request_id": request["_id"],
            "equipment_id": machine["_id"],
            "owner_id": machine.get("owner_id"),
            "farmer_id": request.get("farmer_id"),
            "plot_id": request.get("plot_id"),
            "date": day_str,
            "start_time": minutes_to_hm(job_start),
            "end_time": minutes_to_hm(job_end),
            "travel_time": travel,
            "setup_time": config.SETUP_MINUTES,
            "travel_start": minutes_to_hm(travel_start),
            "occupied_start": minutes_to_hm(travel_start),
            "occupied_end": minutes_to_hm(job_end),
            "job_minutes": duration,
            "travel_km": round(haversine_km(*from_point, *self._point(plot)), 2),
            "travel_from": away_label,
            "created_by": "optimizer",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "_score": (day.toordinal(), travel, machine_rank(machine, request.get("preferred_type", "")), machine["_id"]),
        }

    def find_best(
        self,
        request: dict,
        start: date | None = None,
        end: date | None = None,
        owner_id: str | None = None,
        horizon_end: date | None = None,
    ) -> tuple[dict | None, dict | None]:
        """Return (booking, machine) for the earliest safe slot, else (None, None)."""
        window_start = start or parse_date(request["window_start"])
        window_end = end or parse_date(request["window_end"])
        window_start = max(window_start, self.today)
        if horizon_end:
            window_end = min(window_end, horizon_end)
        if window_end < window_start:
            return None, None

        owner = owner_id or request.get("owner_id")
        candidates = [
            m
            for m in self.equipment
            if m.get("owner_id") == owner and machine_can_do(m, request["operation"])
        ]
        candidates.sort(key=lambda m: (machine_rank(m, request.get("preferred_type", "")), m["_id"]))
        best: tuple[tuple, dict, dict] | None = None
        for day in date_range(window_start, window_end):
            if is_weather_blocked(iso(day), self.weather_days):
                continue
            for machine in candidates:
                if not self.machine_usable(machine, iso(day)):
                    continue
                placement = self._candidate(request, machine, day)
                if not placement:
                    continue
                score = placement["_score"]
                if best is None or score < best[0]:
                    best = (score, placement, machine)
        if not best:
            return None, None
        booking, machine = best[1], best[2]
        booking.pop("_score", None)
        return booking, machine

    def find_other_owner_alternative(self, request: dict) -> dict | None:
        """Search other owners who have a compatible machine, earliest possible."""
        best = None
        for machine in self.equipment:
            if machine.get("owner_id") == request.get("owner_id"):
                continue
            if not machine_can_do(machine, request["operation"]):
                continue
            scan = self._scan_machine(request, machine)
            if scan and (best is None or scan["_score"] < best["_score"]):
                best = scan
        if not best:
            return None
        best = dict(best)
        best.pop("_score", None)
        return best

    def _scan_machine(self, request: dict, machine: dict) -> dict | None:
        start = max(parse_date(request["window_start"]), self.today)
        end = parse_date(request["window_end"])
        horizon = self.today + timedelta(days=config.SCHEDULE_HORIZON_DAYS)
        scans = [(start, end), (max(end + timedelta(days=1), start), horizon)]
        for window_start, window_end in scans:
            for day in date_range(window_start, window_end):
                if day > horizon:
                    break
                if is_weather_blocked(iso(day), self.weather_days):
                    continue
                if not self.machine_usable(machine, iso(day)):
                    continue
                placement = self._candidate(request, machine, day)
                if placement:
                    placement["within_window"] = day <= end
                    return placement
        return None

    def next_slot_same_owner(self, request: dict, after: date | None = None) -> dict | None:
        start = (after or parse_date(request["window_end"])) + timedelta(days=1)
        horizon = self.today + timedelta(days=config.SCHEDULE_HORIZON_DAYS)
        for day in date_range(max(start, self.today), horizon):
            if is_weather_blocked(iso(day), self.weather_days):
                continue
            for machine in self.equipment:
                if machine.get("owner_id") != request.get("owner_id"):
                    continue
                if not machine_can_do(machine, request["operation"]):
                    continue
                if not self.machine_usable(machine, iso(day)):
                    continue
                placement = self._candidate(request, machine, day)
                if placement:
                    placement.pop("_score", None)
                    return placement
        return None

    # ------------------------------------------------------------- schedule
    def schedule(self, requests: Iterable[dict], competitor_notes: bool = True) -> dict:
        ordered = sorted(requests, key=priority_key)
        results: list[dict] = []
        for index, request in enumerate(ordered):
            booking, machine = self.find_best(request)
            if booking:
                self.bookings.append(booking)
                request = dict(request)
                request["_priority_index"] = index
                results.append(
                    {
                        "ok": True,
                        "request": request,
                        "booking": booking,
                        "machine": machine,
                    }
                )
            else:
                results.append(
                    {
                        "ok": False,
                        "request": request,
                        "reason": self.failure_reason(request),
                    }
                )

        if competitor_notes:
            self._attach_priority_notes(results)
        return {"ordered": [r["request"] for r in results], "results": results}

    def _attach_priority_notes(self, results: list[dict]) -> None:
        """Explain, in plain language, why each request went where it did."""
        groups: dict[tuple, list[dict]] = {}
        for result in results:
            request = result["request"]
            if not result["ok"]:
                continue
            group_key = (request.get("owner_id"), request["operation"])
            groups.setdefault(group_key, []).append(result)

        for _, group in groups.items():
            group.sort(key=lambda r: priority_key(r["request"]))
            for i, result in enumerate(group):
                request = result["request"]
                mine = deadline_days(request["window_end"], self.today)
                my_label = self._plot(request["plot_id"]).get("name", "your plot")
                prev = group[i - 1] if i > 0 else None
                nxt = group[i + 1] if i + 1 < len(group) else None
                if prev:
                    other = prev["request"]
                    other_days = deadline_days(other["window_end"], self.today)
                    other_label = self._plot(other["plot_id"]).get("name", "another plot")
                    if other["window_end"] == request["window_end"]:
                        why = (
                            f"Placed after {other_label} because both windows end on "
                            f"{fmt_date(request['window_end'])} ({format_days(mine)}), and {other_label} "
                            f"was requested earlier — the tie-break for equal deadlines."
                        )
                    else:
                        why = (
                            f"Placed after {other_label} because {other_label}'s {request['operation']} window "
                            f"ends sooner ({fmt_date(other['window_end'])}, {format_days(other_days)}) than "
                            f"{my_label}'s ({fmt_date(request['window_end'])}, {format_days(mine)})."
                        )
                elif nxt:
                    other = nxt["request"]
                    other_days = deadline_days(other["window_end"], self.today)
                    other_label = self._plot(other["plot_id"]).get("name", "another plot")
                    if other["window_end"] == request["window_end"]:
                        why = (
                            f"{my_label} was prioritized because both windows end on "
                            f"{fmt_date(request['window_end'])} ({format_days(mine)}), but {my_label} "
                            f"was requested earlier."
                        )
                    else:
                        why = (
                            f"{my_label} was prioritized because its {request['operation']} window ends "
                            f"{format_days(mine)} ({fmt_date(request['window_end'])}), while {other_label}'s "
                            f"ends {format_days(other_days)} ({fmt_date(other['window_end'])})."
                        )
                else:
                    why = (
                        f"{my_label} was the only {request['operation']} request for this owner's "
                        f"machines, so no deadline competition applied."
                    )
                result["priority_note"] = why

    def failure_reason(self, request: dict) -> str:
        plot = self._plot(request["plot_id"])
        owner_id = request.get("owner_id")
        owner = self.users_by_id.get(owner_id, {})
        owner_label = owner.get("farm_name") or owner.get("name") or "the owner"
        preferred = request.get("preferred_type", "machine")
        window_start = parse_date(request["window_start"])
        window_end = parse_date(request["window_end"])
        effective_start = max(window_start, self.today)
        window_days = [iso(d) for d in date_range(effective_start, window_end)] if window_end >= effective_start else []

        owner_machines = [
            m for m in self.equipment
            if m.get("owner_id") == owner_id and machine_can_do(m, request["operation"])
        ]
        all_machines = [m for m in self.equipment if machine_can_do(m, request["operation"])]
        if not all_machines:
            return (
                f"No {preferred} is registered in FieldShare yet, so this {request['operation']} "
                f"request cannot be served."
            )
        if not owner_machines:
            types = " or ".join(TYPE_LABEL.get(t, t) for t in OP_TYPES[request["operation"]])
            return (
                f"{owner_label} does not offer a {types}, so no machine could be assigned. "
                f"Try another owner who has one."
            )
        if window_end < self.today:
            return f"The deadline ({fmt_date(window_end)}) has already passed."
        if not window_days:
            return f"The requested window has no usable days left (deadline {fmt_date(window_end)})."
        if all(is_weather_blocked(d, self.weather_days) for d in window_days):
            return (
                f"Every day in the window ({fmt_date(window_start)} to {fmt_date(window_end)}) is "
                f"blocked by heavy rain, so the job could not be done safely."
            )
        usable_days = [
            d for d in window_days
            if not all(is_broken(m["_id"], d, self.breakdowns) for m in owner_machines)
        ]
        if not usable_days:
            breakdown = next(
                (b for b in self.breakdowns if b.get("equipment_id") in {m["_id"] for m in owner_machines}),
                None,
            )
            until = f" until {fmt_date(breakdown['end_date'])}" if breakdown else ""
            return (
                f"All of {owner_label}'s {preferred} machines are broken{until}. "
                f"Try again after the repair or ask another owner."
            )
        durations = [
            job_minutes(plot.get("area", 0), m.get("work_rate", 1)) for m in owner_machines
        ]
        min_duration = min(durations) if durations else 0
        if min_duration + config.SETUP_MINUTES >= config.WORKDAY_END - config.WORKDAY_START:
            return (
                f"The plot is too large for a single working day: the job needs "
                f"{fmt_duration(min_duration)} plus {config.SETUP_MINUTES} minutes setup, which is longer "
                f"than the 12-hour workday."
            )
        next_slot = self.next_slot_same_owner(request)
        detail = ""
        if next_slot:
            detail = (
                f" The next free slot with {owner_label} is {fmt_date(next_slot['date'])} "
                f"({format_days(deadline_days(next_slot['date'], self.today))})."
            )
        return (
            f"No {preferred} from {owner_label} was free between {fmt_date(window_start)} and "
            f"{fmt_date(window_end)} after allowing for travel and setup — the machines were already "
            f"booked by jobs with earlier deadlines.{detail}"
        )

    def suggestion_for(self, request: dict) -> str:
        """Plain-language alternatives for an unfulfilled request."""
        window_end = parse_date(request["window_end"])
        owner = self.users_by_id.get(request.get("owner_id"), {})
        owner_label = owner.get("farm_name") or owner.get("name") or "the owner"
        parts: list[str] = []
        alt_other = self.find_other_owner_alternative(request)
        if alt_other:
            machine = self.equipment_by_id.get(alt_other["equipment_id"], {})
            other_owner = self.users_by_id.get(machine.get("owner_id"), {})
            within = parse_date(alt_other["date"]) <= window_end
            when = fmt_date(alt_other["date"])
            if within:
                parts.append(
                    f"Ask {other_owner.get('farm_name', 'another owner')} — {machine.get('name')} "
                    f"is free on {when}, inside your window."
                )
            else:
                days_late = (parse_date(alt_other["date"]) - window_end).days
                parts.append(
                    f"{other_owner.get('farm_name', 'Another owner')}'s {machine.get('name')} could do it "
                    f"on {when} — {days_late} day{'s' if days_late != 1 else ''} after your deadline."
                )
        next_slot = self.next_slot_same_owner(request)
        if next_slot:
            late = (parse_date(next_slot["date"]) - window_end).days
            if late > 0:
                parts.append(
                    f"{owner_label} could fit it on {fmt_date(next_slot['date'])} "
                    f"({late} day{'s' if late != 1 else ''} after the deadline)."
                )
            else:
                parts.append(
                    f"{owner_label} has a slot on {fmt_date(next_slot['date'])}, but it still clashes "
                    f"with work already booked."
                )
        if not parts:
            parts.append(
                "No compatible machine has a free slot in the next month. Extend the deadline or add "
                "another machine."
            )
        return " ".join(parts)


def place_manual(
    request: dict,
    machine: dict,
    plot: dict,
    day_bookings: list[dict],
    plot_by_id: dict[str, dict],
    new_date: str,
    new_start: str,
    weather_days: set[str],
    breakdowns: list[dict],
    ignore_booking_id: str | None = None,
) -> dict:
    """Validate a manual move and return the updated booking fields.

    Raises ScheduleError with a farmer-friendly explanation when the move would
    clash, break the travel buffer, fall outside the request window or hit a
    rain/breakdown block.
    """
    window_start = parse_date(request["window_start"])
    window_end = parse_date(request["window_end"])
    new_day = parse_date(new_date)
    if new_day < window_start or new_day > window_end:
        raise ScheduleError(
            f"{fmt_date(new_date)} is outside this request's window "
            f"({fmt_date(window_start)} to {fmt_date(window_end)}). Pick a date inside the window."
        )
    if new_date in weather_days:
        raise ScheduleError(
            f"{fmt_date(new_date)} is blocked by heavy rain. Pick another working day."
        )
    if is_broken(machine["_id"], new_date, breakdowns):
        ranges = [
            b for b in breakdowns
            if b["equipment_id"] == machine["_id"] and b["start_date"] <= new_date <= b["end_date"]
        ]
        until = f" until {fmt_date(ranges[0]['end_date'])}" if ranges else ""
        raise ScheduleError(
            f"{machine.get('name', 'This machine')} is broken{until}. Pick a day after the repair."
        )
    try:
        job_start = hm_to_minutes(new_start)
    except Exception as exc:
        raise ScheduleError("Start time must look like 08:30 (24-hour clock).") from exc
    duration = job_minutes(plot.get("area", 0), machine.get("work_rate", 0))
    job_end = job_start + duration
    if job_end > config.WORKDAY_END:
        latest = minutes_to_hm(config.WORKDAY_END - duration)
        raise ScheduleError(
            f"This job needs {fmt_duration(duration)}, so the latest possible start is {latest}. "
            f"Starting at {new_start} would run past 19:00."
        )
    others = [
        b for b in day_bookings
        if b.get("date") == new_date and b.get("_id") != ignore_booking_id
    ]
    others.sort(key=lambda b: (b.get("start_time", "00:00"), b.get("_id", "")))
    prev = None
    nxt = None
    for booking in others:
        booking_start = hm_to_minutes(booking["start_time"])
        if booking_start < job_start:
            prev = booking
        else:
            nxt = booking
            break

    if prev:
        prev_plot = plot_by_id.get(prev["plot_id"], {})
        if hm_to_minutes(prev["occupied_end"]) > job_start:
            raise ScheduleError(
                f"That time clashes with another {machine.get('type')} job for "
                f"{prev_plot.get('name', 'a plot')} ({prev['start_time']}–{prev['end_time']}, "
                f"plus travel from {prev['travel_start']}). Choose a later time."
            )
        from_point = (float(prev_plot.get("lat", 0)), float(prev_plot.get("lng", 0)))
        from_label = f"Plot {prev_plot.get('name', 'previous job')}"
        earliest_from = hm_to_minutes(prev["occupied_end"])
    else:
        from_point = (float(machine.get("lat", 0)), float(machine.get("lng", 0)))
        from_label = "the machine base"
        earliest_from = config.WORKDAY_START
    travel = travel_minutes(from_point, (float(plot.get("lat", 0)), float(plot.get("lng", 0))))
    travel_start = job_start - travel - config.SETUP_MINUTES
    if travel_start < earliest_from or travel_start < config.WORKDAY_START:
        earliest_start = max(earliest_from, config.WORKDAY_START) + travel + config.SETUP_MINUTES
        raise ScheduleError(
            f"The travel buffer does not fit. Coming from {from_label} takes {travel} min, plus "
            f"{config.SETUP_MINUTES} min setup, so the earliest possible start is "
            f"{minutes_to_hm(earliest_start)}. Choose a later time."
        )
    if nxt:
        nxt_plot = plot_by_id.get(nxt["plot_id"], {})
        if job_end > hm_to_minutes(nxt["occupied_start"]):
            raise ScheduleError(
                f"This job would run until {minutes_to_hm(job_end)}, but "
                f"{nxt_plot.get('name', 'the next plot')} is already booked at "
                f"{nxt['start_time']} (its travel starts at {nxt['travel_start']}). "
                f"Choose an earlier time or another day."
            )
    return {
        "date": new_date,
        "start_time": minutes_to_hm(job_start),
        "end_time": minutes_to_hm(job_end),
        "travel_time": travel,
        "setup_time": config.SETUP_MINUTES,
        "travel_start": minutes_to_hm(travel_start),
        "occupied_start": minutes_to_hm(travel_start),
        "occupied_end": minutes_to_hm(job_end),
        "job_minutes": duration,
        "travel_km": round(haversine_km(*from_point, *(
            float(plot.get("lat", 0)), float(plot.get("lng", 0))
        )), 2),
        "travel_from": from_label,
    }


# ------------------------------------------------------------------ invariants
def reflow_day(
    machine: dict,
    day: str,
    day_bookings: list[dict],
    plot_by_id: dict[str, dict],
) -> tuple[list[dict], list[dict]]:
    """Recompute travel buffers for surviving bookings on a machine-day.

    Returns (valid_bookings_with_updated_travel, conflicting_bookings). Conflicting
    bookings must be rescheduled because their travel buffer no longer fits.
    """
    rows = sorted(day_bookings, key=lambda b: (b.get("start_time", "00:00"), b.get("_id", "")))
    removed: set[str] = set()
    while True:
        prev_end = config.WORKDAY_START
        prev_point = (float(machine.get("lat", 0)), float(machine.get("lng", 0)))
        prev_label = "the machine base"
        conflicts: list[dict] = []
        current: list[dict] = []
        for booking in rows:
            if booking["_id"] in removed:
                continue
            plot = plot_by_id.get(booking["plot_id"], {})
            point = (float(plot.get("lat", 0)), float(plot.get("lng", 0)))
            travel = travel_minutes(prev_point, point)
            start = hm_to_minutes(booking["start_time"])
            end = hm_to_minutes(booking["end_time"])
            travel_start = start - travel - config.SETUP_MINUTES
            if travel_start < prev_end or travel_start < config.WORKDAY_START:
                conflicts.append(booking)
                continue
            updated = dict(booking)
            updated.update(
                {
                    "travel_time": travel,
                    "travel_start": minutes_to_hm(travel_start),
                    "occupied_start": minutes_to_hm(travel_start),
                    "occupied_end": minutes_to_hm(end),
                    "travel_km": round(haversine_km(*prev_point, *point), 2),
                    "travel_from": prev_label,
                }
            )
            current.append(updated)
            prev_end = end
            prev_point = point
            prev_label = f"Plot {plot.get('name', 'previous job')}"
        if not conflicts:
            return current, []
        new_conflicts = [b for b in conflicts if b["_id"] not in removed]
        if not new_conflicts:
            return current, []
        removed.update(b["_id"] for b in new_conflicts)
        # Loop again: removing a booking can change the travel chain for the rest.


def validate_schedule(
    bookings: list[dict],
    equipment: list[dict],
    plots: list[dict],
    weather_days: set[str] | None = None,
    breakdowns: list[dict] | None = None,
    check_blocks: bool = False,
) -> list[str]:
    """Return a list of human-readable invariant violations (empty == valid)."""
    problems: list[str] = []
    equipment_by_id = {m["_id"]: m for m in equipment}
    plot_by_id = {p["_id"]: p for p in plots}
    weather_days = weather_days or set()
    breakdowns = breakdowns or []
    grouped: dict[tuple[str, str], list[dict]] = {}
    for booking in bookings:
        grouped.setdefault((booking.get("equipment_id", "?"), booking.get("date", "?")), []).append(booking)

    for (equipment_id, day), rows in grouped.items():
        machine = equipment_by_id.get(equipment_id)
        if not machine:
            problems.append(f"{day}: booking references unknown machine {equipment_id}.")
            continue
        if check_blocks:
            if is_weather_blocked(day, weather_days):
                problems.append(f"{day}: {machine.get('name')} has a booking on a rain-blocked day.")
            if is_broken(equipment_id, day, breakdowns):
                problems.append(f"{day}: {machine.get('name')} has a booking during a breakdown.")
        rows.sort(key=lambda b: (b.get("travel_start", "00:00"), b.get("_id", "")))
        prev_end = -1
        prev_point = (float(machine.get("lat", 0)), float(machine.get("lng", 0)))
        for booking in rows:
            occupied_start = hm_to_minutes(booking["occupied_start"])
            occupied_end = hm_to_minutes(booking["occupied_end"])
            job_start = hm_to_minutes(booking["start_time"])
            job_end = hm_to_minutes(booking["end_time"])
            travel_start = hm_to_minutes(booking["travel_start"])
            travel = int(booking["travel_time"])
            setup = int(booking.get("setup_time", config.SETUP_MINUTES))
            plot = plot_by_id.get(booking.get("plot_id"))
            if not plot:
                problems.append(f"{day}: booking references unknown plot {booking.get('plot_id')}.")
                continue
            if occupied_start < config.WORKDAY_START:
                problems.append(f"{day}: {machine.get('name')} starts before 07:00.")
            if occupied_end > config.WORKDAY_END:
                problems.append(f"{day}: {machine.get('name')} works past 19:00.")
            if prev_end >= 0 and occupied_start < prev_end:
                problems.append(
                    f"{day}: {machine.get('name')} is double-booked ({booking['start_time']}–{booking['end_time']})."
                )
            if travel_start + travel + setup != job_start:
                problems.append(f"{day}: travel/setup buffer does not add up for {plot.get('name')}.")
            expected_travel = travel_minutes(
                prev_point, (float(plot.get("lat", 0)), float(plot.get("lng", 0)))
            )
            if travel != expected_travel:
                problems.append(
                    f"{day}: travel time for {plot.get('name')} is {travel} min, "
                    f"expected {expected_travel} min."
                )
            expected_duration = job_minutes(plot.get("area", 0), machine.get("work_rate", 1))
            if job_end - job_start != expected_duration:
                problems.append(
                    f"{day}: job duration for {plot.get('name')} is {job_end - job_start} min, "
                    f"expected {expected_duration} min."
                )
            if booking.get("travel_start") != minutes_to_hm(travel_start):
                problems.append(f"{day}: inconsistent travel start.")
            if booking["date"] != day:
                problems.append(f"{day}: booking date mismatch.")
            prev_end = max(prev_end, occupied_end)
            prev_point = (float(plot.get("lat", 0)), float(plot.get("lng", 0)))

    return problems
