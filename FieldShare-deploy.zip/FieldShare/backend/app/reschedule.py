"""Disruption handling: block rain days or a broken machine, then re-plan only
the affected jobs by deadline priority while leaving everything else untouched."""

from __future__ import annotations

import logging
from datetime import date as date_cls

from . import config
from .db import db
from .scheduling import (
    Scheduler,
    date_range,
    fmt_date,
    reflow_day,
    validate_schedule,
)
from .services import (
    build_booking_explanation,
    load_ctx,
    notify,
    now_iso,
    refresh_machine_statuses,
    request_public,
)

log = logging.getLogger("fieldshare.reschedule")


def _describe(booking: dict | None, ctx) -> str:
    if not booking:
        return "no booking"
    machine = ctx.equipment_by_id.get(booking["equipment_id"], {})
    return (
        f"{fmt_date(booking['date'])} {booking['start_time']}–{booking['end_time']} "
        f"with {machine.get('name', 'a machine')}"
    )


def apply_rain(start: str, end: str, reason: str, actor: dict) -> dict:
    dates = list(date_range(date_cls.fromisoformat(start), date_cls.fromisoformat(end)))
    for day in dates:
        existing = db.find_one("weather_blocks", {"date": day.isoformat()})
        if existing:
            db.update("weather_blocks", existing["_id"], {"reason": reason})
        else:
            db.insert(
                "weather_blocks",
                {"date": day.isoformat(), "reason": reason, "created_at": now_iso()},
            )
    date_set = {d.isoformat() for d in dates}
    cause = (
        f"Heavy rain blocked field work on {fmt_date(start)}"
        if start == end
        else f"Heavy rain blocked field work from {fmt_date(start)} to {fmt_date(end)}"
    )
    return _reschedule(
        actor=actor,
        cause=cause,
        affected_predicate=lambda b: b["date"] in date_set,
        meta={"kind": "rain", "dates": sorted(date_set), "reason": reason},
    )


def apply_breakdown(equipment_id: str, start: str, end: str, note: str, actor: dict) -> dict:
    db.insert(
        "breakdowns",
        {
            "equipment_id": equipment_id,
            "start_date": start,
            "end_date": end,
            "note": note,
            "created_by": actor["_id"],
            "created_at": now_iso(),
        },
    )
    refresh_machine_statuses()
    machine = db.get("equipment", equipment_id) or {}
    cause = (
        f"{machine.get('name', 'A machine')} was marked broken from {fmt_date(start)} to {fmt_date(end)}"
        f" ({note})"
    )
    return _reschedule(
        actor=actor,
        cause=cause,
        affected_predicate=lambda b: (
            b["equipment_id"] == equipment_id and start <= b["date"] <= end
        ),
        meta={"kind": "breakdown", "equipment_id": equipment_id, "start_date": start, "end_date": end, "note": note},
    )


def _reschedule(actor: dict, cause: str, affected_predicate, meta: dict) -> dict:
    before_ctx = load_ctx()
    affected_bookings = [b for b in before_ctx.bookings if affected_predicate(b)]
    affected_ids = {b["request_id"] for b in affected_bookings}
    affected_machine_days = {(b["equipment_id"], b["date"]) for b in affected_bookings}
    before_desc = {
        b["request_id"]: {
            "booking": b,
            "text": _describe(b, before_ctx),
        }
        for b in affected_bookings
    }

    for booking in affected_bookings:
        db.delete("bookings", {"_id": booking["_id"]})

    # Keep the remaining bookings on touched machine-days consistent: travel
    # buffers may now start from a different previous farm.
    cascaded: set[str] = set()
    for equipment_id, day in sorted(affected_machine_days):
        machine = before_ctx.equipment_by_id.get(equipment_id)
        if not machine:
            continue
        rows = db.find("bookings", {"equipment_id": equipment_id, "date": day})
        valid, conflicts = reflow_day(machine, day, rows, before_ctx.plots_by_id)
        for row in valid:
            original = before_ctx.bookings_by_id.get(row["_id"], {})
            if any(
                row.get(key) != original.get(key)
                for key in ("travel_time", "travel_start", "travel_from", "travel_km", "occupied_start")
            ):
                db.replace("bookings", row["_id"], row)
        for conflict in conflicts:
            cascaded.add(conflict["request_id"])
            before_desc.setdefault(
                conflict["request_id"],
                {"booking": conflict, "text": _describe(conflict, before_ctx)},
            )
            db.delete("bookings", {"_id": conflict["_id"]})

    affected_ids |= cascaded
    affected_requests = []
    for request_id in affected_ids:
        request = db.get("requests", request_id)
        if not request:
            continue
        if request.get("status") in ("rejected",):
            continue
        db.update(
            "requests",
            request_id,
            {
                "status": "rescheduled",
                "booking_id": None,
                "explanation": "Waiting to be re-scheduled after the disruption.",
                "reason": "",
            },
        )
        affected_requests.append(request)

    ctx = load_ctx()
    scheduler = Scheduler(
        equipment=ctx.equipment,
        plots=ctx.plots,
        bookings=ctx.bookings,
        users_by_id=ctx.users_by_id,
        weather_days=ctx.weather_days,
        breakdowns=ctx.breakdowns,
        today=ctx.today,
    )
    outcome = scheduler.schedule(affected_requests)
    notes = {r["request"]["_id"]: r.get("priority_note", "") for r in outcome["results"]}

    moved: list[dict] = []
    unfulfilled: list[dict] = []
    notifications_sent = 0
    for result in outcome["results"]:
        request = result["request"]
        plot = ctx.plots_by_id.get(request["plot_id"], {})
        farmer = ctx.users_by_id.get(request["farmer_id"], {})
        owner = ctx.users_by_id.get(request["owner_id"], {})
        old = before_desc.get(request["_id"], {})
        old_text = old.get("text", "no booking")
        if result["ok"]:
            booking = db.insert(
                "bookings",
                {
                    **result["booking"],
                    "created_by": "reschedule",
                },
            )
            fresh_ctx = load_ctx()
            explanation = build_booking_explanation(request, booking, fresh_ctx)
            db.update(
                "requests",
                request["_id"],
                {
                    "status": "rescheduled",
                    "booking_id": booking["_id"],
                    "explanation": explanation,
                    "priority_note": notes.get(request["_id"], ""),
                    "reason": "",
                    "suggestion": "",
                },
            )
            new_text = _describe(booking, ctx)
            notify(
                request["farmer_id"],
                f"Rescheduled: {plot.get('name')}",
                f"{cause}. Your {request['operation']} job was moved from {old_text} to {new_text}. "
                f"{explanation}",
                "warning",
                request["_id"],
                booking["_id"],
            )
            notifications_sent += 1
            moved.append(
                {
                    "request_id": request["_id"],
                    "plot_name": plot.get("name"),
                    "farmer_name": farmer.get("name"),
                    "operation": request["operation"],
                    "before": old.get("text", "no booking"),
                    "after": new_text,
                    "before_date": old.get("booking", {}).get("date"),
                    "after_date": booking["date"],
                    "equipment_before": ctx.equipment_by_id.get(
                        old.get("booking", {}).get("equipment_id", ""), {}
                    ).get("name"),
                    "equipment_after": result["machine"]["name"],
                    "explanation": explanation,
                    "priority_note": notes.get(request["_id"], ""),
                    "farmer_id": request["farmer_id"],
                    "owner_name": owner.get("name"),
                }
            )
        else:
            suggestion = scheduler.suggestion_for(request)
            reason = result["reason"]
            db.update(
                "requests",
                request["_id"],
                {
                    "status": "unfulfilled",
                    "booking_id": None,
                    "reason": reason,
                    "explanation": reason,
                    "suggestion": suggestion,
                },
            )
            notify(
                request["farmer_id"],
                f"At risk: {plot.get('name')} cannot be re-scheduled",
                f"{cause}. Your {request['operation']} job was previously {old_text}, but no machine "
                f"could take it before the deadline. {reason} {suggestion}",
                "danger",
                request["_id"],
            )
            notifications_sent += 1
            unfulfilled.append(
                {
                    "request_id": request["_id"],
                    "plot_name": plot.get("name"),
                    "farmer_name": farmer.get("name"),
                    "operation": request["operation"],
                    "before": old.get("text", "no booking"),
                    "reason": reason,
                    "suggestion": suggestion,
                    "owner_name": owner.get("name"),
                }
            )

    notify(
        actor["_id"],
        "Rescheduling complete",
        f"{cause}. {len(moved)} booking{'s' if len(moved) != 1 else ''} moved automatically and "
        f"{len(unfulfilled)} job{'s' if len(unfulfilled) != 1 else ''} could not be re-scheduled. "
        f"Unaffected bookings were left unchanged.",
        "info",
    )
    notifications_sent += 1

    final_ctx = load_ctx()
    problems = validate_schedule(
        final_ctx.bookings,
        final_ctx.equipment,
        final_ctx.plots,
        final_ctx.weather_days,
        final_ctx.breakdowns,
        check_blocks=True,
    )
    if problems:
        log.error("schedule invariant violated after reschedule: %s", problems)

    affected_farmer_ids = {r["farmer_id"] for r in affected_requests}
    at_risk = []
    for request in final_ctx.requests:
        if request.get("farmer_id") not in affected_farmer_ids:
            continue
        public = request_public(request, final_ctx)
        if public["risk_level"] in ("high", "medium") and public["status"] in (
            "unfulfilled",
            "pending",
            "accepted",
            "scheduled",
            "rescheduled",
        ):
            at_risk.append(public)

    unchanged = len(final_ctx.bookings) - len(moved)
    return {
        "ok": True,
        "cause": cause,
        "meta": meta,
        "affected_count": len(affected_ids),
        "moved": moved,
        "unfulfilled": unfulfilled,
        "unchanged_bookings": max(0, unchanged),
        "notifications_sent": notifications_sent,
        "at_risk": sorted(at_risk, key=lambda r: (r["risk_level"] != "high", r["days_left"])),
        "integrity": {"ok": not problems, "problems": problems},
    }
