from __future__ import annotations

import hashlib
import logging
import secrets
import threading
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Literal

from . import config
from .db import db
from .reschedule import apply_breakdown, apply_rain
from .scheduling import (
    OP_TYPES,
    ScheduleError,
    Scheduler,
    cost_estimate,
    deadline_days,
    fmt_date,
    is_broken,
    operation_types,
    parse_date,
    place_manual,
    validate_schedule,
)
from .seed import reset_demo, seed_if_needed
from .services import (
    booking_public,
    build_booking_explanation,
    equipment_public,
    load_ctx,
    notify,
    notification_public,
    plot_public,
    public,
    refresh_machine_statuses,
    request_public,
    risk_for,
    now_iso,
)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("fieldshare")
WRITE_LOCK = threading.RLock()


@asynccontextmanager
async def lifespan(_: FastAPI):
    seed_if_needed()
    yield


app = FastAPI(title="FieldShare API", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(ScheduleError)
async def schedule_error_handler(_, exc: ScheduleError):
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.exception_handler(RequestValidationError)
async def validation_error_handler(_, exc: RequestValidationError):
    first = exc.errors()[0] if exc.errors() else {}
    field = ".".join(str(p) for p in first.get("loc", []) if p not in ("body", "query"))
    message = first.get("msg", "Invalid input.")
    return JSONResponse(
        status_code=400,
        content={"detail": f"{field}: {message}" if field else message},
    )


# --------------------------------------------------------------------- auth
def _hash(password: str) -> str:
    return hashlib.sha256(f"fieldshare::{password}".encode()).hexdigest()


def user_card(user: dict) -> dict:
    return {
        "id": user["_id"],
        "name": user["name"],
        "role": user["role"],
        "farm_name": user.get("farm_name"),
        "email": user.get("email"),
        "phone": user.get("phone"),
        "lat": user.get("lat"),
        "lng": user.get("lng"),
    }


def create_session(user: dict) -> str:
    token = secrets.token_urlsafe(28)
    db.insert(
        "sessions",
        {
            "_id": token,
            "user_id": user["_id"],
            "created_at": now_iso(),
        },
    )
    return token


def current_user(authorization: str | None = Header(default=None)) -> dict:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Please log in to continue.")
    token = authorization.split(" ", 1)[1].strip()
    session = db.get("sessions", token)
    user = db.get("users", session["user_id"]) if session else None
    if not user:
        raise HTTPException(status_code=401, detail="Your session has expired. Please log in again.")
    return user


def require_owner(user: dict = Depends(current_user)) -> dict:
    if user.get("role") != "owner":
        raise HTTPException(status_code=403, detail="Only equipment owners can do that.")
    return user


def require_farmer(user: dict = Depends(current_user)) -> dict:
    if user.get("role") != "farmer":
        raise HTTPException(status_code=403, detail="Only farmers can do that.")
    return user


class LoginIn(BaseModel):
    email: str
    password: str


class DemoLoginIn(BaseModel):
    role: Literal["owner", "farmer"]
    user_id: str | None = None


@app.post("/api/auth/login")
def login(body: LoginIn):
    email = body.email.strip().lower()
    user = db.find_one("users", {"email": email})
    if not user or user.get("password_hash") != _hash(body.password):
        raise HTTPException(status_code=401, detail="Email or password is incorrect.")
    token = create_session(user)
    return {"token": token, "user": user_card(user)}


@app.post("/api/auth/demo")
def demo_login(body: DemoLoginIn):
    users = db.find("users", {"role": body.role})
    if body.user_id:
        user = next((u for u in users if u["_id"] == body.user_id), None)
    else:
        user = users[0] if users else None
    if not user:
        raise HTTPException(status_code=404, detail="No demo account found for that role.")
    token = create_session(user)
    return {"token": token, "user": user_card(user)}


@app.get("/api/auth/me")
def me(user: dict = Depends(current_user)):
    return {"user": user_card(user)}


@app.post("/api/auth/logout")
def logout(authorization: str | None = Header(default=None)):
    if authorization and authorization.lower().startswith("bearer "):
        db.delete("sessions", {"_id": authorization.split(" ", 1)[1].strip()})
    return {"ok": True}


@app.get("/api/demo/accounts")
def demo_accounts():
    users = db.find("users")
    order = {"owner": 0, "farmer": 1}
    users.sort(key=lambda u: (order.get(u.get("role"), 2), u.get("name", "")))
    return {"accounts": [user_card(u) for u in users], "password": "demo123"}


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "database": db.kind,
        "today": date.today().isoformat(),
        "counts": {
            "users": db.count("users"),
            "equipment": db.count("equipment"),
            "plots": db.count("plots"),
            "requests": db.count("requests"),
            "bookings": db.count("bookings"),
        },
    }


@app.get("/api/health/schedule")
def schedule_health():
    ctx = load_ctx()
    problems = validate_schedule(
        ctx.bookings, ctx.equipment, ctx.plots, ctx.weather_days, ctx.breakdowns, check_blocks=True
    )
    return {"ok": not problems, "problems": problems, "bookings_checked": len(ctx.bookings)}


# --------------------------------------------------------------------- state
def _stats(user: dict, ctx, reqs: list[dict], bookings: list[dict], unread: int) -> dict:
    today = ctx.today.isoformat()
    high_risk = 0
    for request in reqs:
        booking = ctx.bookings_by_request.get(request["_id"])
        level, _ = risk_for(request, booking, ctx.today)
        if level in ("high", "medium"):
            high_risk += 1
    my_equipment = [m for m in ctx.equipment if m.get("owner_id") == user["_id"]]
    my_plots = [p for p in ctx.plots if p.get("farmer_id") == user["_id"]]
    booked_minutes = sum(int(b.get("job_minutes", 0)) for b in bookings)
    travel_km = round(sum(float(b.get("travel_km", 0)) for b in bookings), 1)
    value = 0.0
    for booking in bookings:
        machine = ctx.equipment_by_id.get(booking["equipment_id"], {})
        plot = ctx.plots_by_id.get(booking["plot_id"], {})
        value += cost_estimate(plot.get("area", 0), machine, int(booking.get("job_minutes", 0)))
    upcoming = sorted(
        [b for b in bookings if b.get("date", "") >= today],
        key=lambda b: (b.get("date", ""), b.get("start_time", "")),
    )
    return {
        "machines": len(my_equipment),
        "active_machines": sum(
            1 for m in my_equipment
            if not any(
                b["equipment_id"] == m["_id"] and b["start_date"] <= today <= b["end_date"]
                for b in ctx.breakdowns
            )
        ),
        "broken_machines": sum(
            1 for m in my_equipment
            if any(
                b["equipment_id"] == m["_id"] and b["start_date"] <= today <= b["end_date"]
                for b in ctx.breakdowns
            )
        ),
        "plots": len(my_plots),
        "acres": round(sum(float(p.get("area", 0)) for p in my_plots), 1),
        "pending": sum(1 for r in reqs if r.get("status") == "pending"),
        "accepted": sum(1 for r in reqs if r.get("status") == "accepted"),
        "scheduled": len(bookings),
        "unfulfilled": sum(1 for r in reqs if r.get("status") == "unfulfilled"),
        "at_risk": high_risk,
        "unread": unread,
        "booked_hours": round(booked_minutes / 60.0, 1),
        "travel_km": travel_km,
        "value": round(value, 2),
        "next_job": booking_public(upcoming[0], ctx) if upcoming else None,
    }


def build_state(user: dict) -> dict:
    refresh_machine_statuses()
    ctx = load_ctx()
    is_owner = user["role"] == "owner"
    if is_owner:
        requests = [r for r in ctx.requests if r.get("owner_id") == user["_id"]]
        bookings = [b for b in ctx.bookings if b.get("owner_id") == user["_id"]]
    else:
        requests = [r for r in ctx.requests if r.get("farmer_id") == user["_id"]]
        bookings = [b for b in ctx.bookings if b.get("farmer_id") == user["_id"]]
    requests.sort(key=lambda r: (r.get("created_at", ""), r["_id"]), reverse=True)
    bookings.sort(key=lambda b: (b.get("date", ""), b.get("start_time", "")))

    notifications = db.find("notifications", {"user_id": user["_id"]}, sort="created_at")
    notifications.sort(key=lambda n: n.get("created_at", ""), reverse=True)
    unread = sum(1 for n in notifications if not n.get("read"))

    public_requests = [request_public(r, ctx) for r in requests]
    public_bookings = [booking_public(b, ctx) for b in bookings]
    public_equipment = [equipment_public(m, ctx) for m in ctx.equipment]
    public_plots = [plot_public(p, ctx) for p in ctx.plots]

    at_risk = [
        r for r in public_requests
        if r["risk_level"] in ("high", "medium") and r["status"] != "rejected"
    ]
    at_risk.sort(key=lambda r: (r["risk_level"] != "high", r["days_left"]))

    stats = _stats(user, ctx, requests, bookings, unread)
    return {
        "user": user_card(user),
        "today": ctx.today.isoformat(),
        "users": [user_card(u) for u in ctx.users],
        "equipment": public_equipment,
        "plots": public_plots,
        "requests": public_requests,
        "bookings": public_bookings,
        "notifications": [notification_public(n) for n in notifications[:40]],
        "unread": unread,
        "weather": [
            {
                **public(w),
                "is_past": w["date"] < ctx.today.isoformat(),
            }
            for w in ctx.weather
        ],
        "breakdowns": [
            {
                **public(b),
                "equipment_name": ctx.equipment_by_id.get(b["equipment_id"], {}).get("name"),
                "owner_id": ctx.equipment_by_id.get(b["equipment_id"], {}).get("owner_id"),
            }
            for b in ctx.breakdowns
        ],
        "at_risk": at_risk,
        "stats": stats,
        "my_machines": [m["_id"] for m in ctx.equipment if m.get("owner_id") == user["_id"]],
        "my_plots": [p["_id"] for p in ctx.plots if p.get("farmer_id") == user["_id"]],
        "role": user["role"],
    }


@app.get("/api/state")
def state(user: dict = Depends(current_user)):
    return build_state(user)


# ------------------------------------------------------------------ registry
class EquipmentIn(BaseModel):
    name: str
    type: Literal["tractor", "harvester", "sprayer", "seeder"]
    rate_type: Literal["hourly", "per_acre"]
    rate: float
    work_rate: float
    lat: float
    lng: float
    notes: str = ""


class EquipmentPatch(BaseModel):
    name: str | None = None
    rate: float | None = None
    rate_type: Literal["hourly", "per_acre"] | None = None
    work_rate: float | None = None
    lat: float | None = None
    lng: float | None = None
    notes: str | None = None


class PlotIn(BaseModel):
    name: str
    area: float
    crop: str
    lat: float
    lng: float
    notes: str = ""


def _validate_coords(lat: float, lng: float) -> None:
    if not -90 <= lat <= 90 or not -180 <= lng <= 180:
        raise HTTPException(status_code=400, detail="Please pick a valid location on the map.")
    if abs(lat) < 0.01 and abs(lng) < 0.01:
        raise HTTPException(status_code=400, detail="Please pick a location on the map.")


@app.post("/api/equipment")
def add_equipment(body: EquipmentIn, user: dict = Depends(require_owner)):
    name = body.name.strip()
    if len(name) < 2:
        raise HTTPException(status_code=400, detail="Give the machine a name.")
    if body.rate <= 0:
        raise HTTPException(status_code=400, detail="Rate must be greater than zero.")
    if body.work_rate <= 0 or body.work_rate > 100:
        raise HTTPException(status_code=400, detail="Work rate must be between 0 and 100 acres per hour.")
    _validate_coords(body.lat, body.lng)
    with WRITE_LOCK:
        doc = db.insert(
            "equipment",
            {
                "owner_id": user["_id"],
                "name": name,
                "type": body.type,
                "rate_type": body.rate_type,
                "rate": round(float(body.rate), 2),
                "work_rate": round(float(body.work_rate), 2),
                "lat": body.lat,
                "lng": body.lng,
                "status": "active",
                "notes": body.notes.strip(),
                "created_at": now_iso(),
            },
        )
    ctx = load_ctx()
    return {"ok": True, "equipment": equipment_public(doc, ctx), "message": f"{name} added."}


@app.patch("/api/equipment/{equipment_id}")
def update_equipment(equipment_id: str, body: EquipmentPatch, user: dict = Depends(require_owner)):
    machine = db.get("equipment", equipment_id)
    if not machine or machine.get("owner_id") != user["_id"]:
        raise HTTPException(status_code=404, detail="Machine not found.")
    changes = {k: v for k, v in body.model_dump(exclude_none=True).items()}
    if "rate" in changes and changes["rate"] <= 0:
        raise HTTPException(status_code=400, detail="Rate must be greater than zero.")
    if "work_rate" in changes and (changes["work_rate"] <= 0 or changes["work_rate"] > 100):
        raise HTTPException(status_code=400, detail="Work rate must be between 0 and 100 acres per hour.")
    if "lat" in changes or "lng" in changes:
        _validate_coords(changes.get("lat", machine["lat"]), changes.get("lng", machine["lng"]))
    with WRITE_LOCK:
        db.update("equipment", equipment_id, changes)
    ctx = load_ctx()
    return {"ok": True, "equipment": equipment_public(db.get("equipment", equipment_id), ctx)}


@app.post("/api/plots")
def add_plot(body: PlotIn, user: dict = Depends(require_farmer)):
    name = body.name.strip()
    crop = body.crop.strip()
    if len(name) < 2:
        raise HTTPException(status_code=400, detail="Give the plot a name.")
    if not crop:
        raise HTTPException(status_code=400, detail="Add the crop growing on this plot.")
    if body.area <= 0 or body.area > 2000:
        raise HTTPException(status_code=400, detail="Area must be between 0 and 2,000 acres.")
    _validate_coords(body.lat, body.lng)
    with WRITE_LOCK:
        doc = db.insert(
            "plots",
            {
                "farmer_id": user["_id"],
                "name": name,
                "area": round(float(body.area), 2),
                "crop": crop,
                "lat": body.lat,
                "lng": body.lng,
                "notes": body.notes.strip(),
                "created_at": now_iso(),
            },
        )
    ctx = load_ctx()
    return {"ok": True, "plot": plot_public(doc, ctx), "message": f"{name} added."}


# ------------------------------------------------------------------ requests
class RequestIn(BaseModel):
    plot_id: str
    owner_id: str
    operation: Literal["sowing", "spraying", "harvesting"]
    preferred_type: str
    window_start: str
    window_end: str


class DecisionIn(BaseModel):
    reason: str | None = None


@app.post("/api/requests")
def create_request(body: RequestIn, user: dict = Depends(require_farmer)):
    plot = db.get("plots", body.plot_id)
    if not plot or plot.get("farmer_id") != user["_id"]:
        raise HTTPException(status_code=404, detail="Plot not found on your farm.")
    owner = db.get("users", body.owner_id)
    if not owner or owner.get("role") != "owner":
        raise HTTPException(status_code=400, detail="Choose an equipment owner.")
    if body.preferred_type not in OP_TYPES.get(body.operation, ()):
        raise HTTPException(
            status_code=400,
            detail=f"A {body.preferred_type} cannot do {body.operation}. Pick a compatible machine type.",
        )
    try:
        start = date.fromisoformat(body.window_start)
        end = date.fromisoformat(body.window_end)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Use valid dates for the request window.") from exc
    if end < start:
        raise HTTPException(status_code=400, detail="The deadline cannot be before the start date.")
    if end < date.today():
        raise HTTPException(status_code=400, detail="The deadline has already passed. Pick a future window.")
    if (end - start).days > 60:
        raise HTTPException(status_code=400, detail="Keep the request window to 60 days or less.")

    ctx = load_ctx()
    matching = [
        m for m in ctx.equipment
        if m.get("owner_id") == body.owner_id
        and m.get("type") == body.preferred_type
    ]
    if not matching:
        raise HTTPException(
            status_code=400,
            detail=f"{owner.get('farm_name', owner['name'])} does not offer a {body.preferred_type}. "
                   f"Choose another owner or machine type.",
        )
    with WRITE_LOCK:
        doc = db.insert(
            "requests",
            {
                "farmer_id": user["_id"],
                "plot_id": body.plot_id,
                "owner_id": body.owner_id,
                "operation": body.operation,
                "window_start": body.window_start,
                "window_end": body.window_end,
                "preferred_type": body.preferred_type,
                "status": "pending",
                "reason": "",
                "explanation": (
                    f"Request sent to {owner.get('farm_name', owner['name'])}. "
                    f"An owner must approve it before it can be scheduled."
                ),
                "priority_note": "",
                "suggestion": "",
                "booking_id": None,
                "created_at": now_iso(),
            },
        )
    days_left = (end - date.today()).days
    notify(
        body.owner_id,
        f"New {body.operation} request",
        f"{user['name']} asked for a {body.preferred_type} for {plot['name']} "
        f"({plot['area']:g} acres) between {fmt_date(start)} and {fmt_date(end)} — "
        f"{'today' if days_left == 0 else f'{days_left} days left'}.",
        "info",
        doc["_id"],
    )
    notify(
        user["_id"],
        "Request sent",
        f"Your {body.operation} request for {plot['name']} is waiting for "
        f"{owner.get('farm_name', owner['name'])} to approve it.",
        "info",
        doc["_id"],
    )
    return {"ok": True, "request": request_public(doc, ctx), "message": "Request sent to the owner."}


@app.post("/api/requests/{request_id}/accept")
def accept_request(request_id: str, user: dict = Depends(require_owner)):
    with WRITE_LOCK:
        request = db.get("requests", request_id)
        if not request or request.get("owner_id") != user["_id"]:
            raise HTTPException(status_code=404, detail="Request not found.")
        if request["status"] not in ("pending", "accepted"):
            raise HTTPException(status_code=400, detail="Only pending requests can be accepted.")
        db.update(
            "requests",
            request_id,
            {
                "status": "accepted",
                "explanation": (
                    "Approved by the owner. Use Optimize Schedule to assign a machine and time "
                    "inside the window."
                ),
                "reason": "",
            },
        )
    ctx = load_ctx()
    plot = ctx.plots_by_id.get(request["plot_id"], {})
    notify(
        request["farmer_id"],
        "Request approved",
        f"{user.get('farm_name', user['name'])} approved your {request['operation']} request for "
        f"{plot.get('name')}. It will be scheduled in the next optimization — deadline "
        f"{fmt_date(request['window_end'])}.",
        "success",
        request_id,
    )
    return {"ok": True, "request": request_public(db.get("requests", request_id), ctx)}


@app.post("/api/requests/{request_id}/reject")
def reject_request(request_id: str, body: DecisionIn, user: dict = Depends(require_owner)):
    reason = (body.reason or "").strip() or "The owner is not able to take this job."
    with WRITE_LOCK:
        request = db.get("requests", request_id)
        if not request or request.get("owner_id") != user["_id"]:
            raise HTTPException(status_code=404, detail="Request not found.")
        if request["status"] not in ("pending", "accepted"):
            raise HTTPException(status_code=400, detail="Only pending or approved requests can be declined.")
        booking = db.find_one("bookings", {"request_id": request_id})
        if booking:
            raise HTTPException(
                status_code=400,
                detail="This job already has a booking. Moving or cancelling a scheduled job is not supported here.",
            )
        db.update(
            "requests",
            request_id,
            {
                "status": "rejected",
                "reason": reason,
                "explanation": f"Owner declined this request. Reason: {reason}",
                "suggestion": "",
                "booking_id": None,
            },
        )
    ctx = load_ctx()
    plot = ctx.plots_by_id.get(request["plot_id"], {})
    notify(
        request["farmer_id"],
        "Request declined",
        f"{user.get('farm_name', user['name'])} declined your {request['operation']} request for "
        f"{plot.get('name')}. Reason: {reason}",
        "warning",
        request_id,
    )
    return {"ok": True, "request": request_public(db.get("requests", request_id), ctx)}


# ------------------------------------------------------------------ optimize
class OptimizeIn(BaseModel):
    include_pending: bool = True


@app.post("/api/optimize")
def optimize(body: OptimizeIn, user: dict = Depends(require_owner)):
    with WRITE_LOCK:
        ctx = load_ctx()
        candidates = []
        for request in ctx.requests:
            if request.get("owner_id") != user["_id"]:
                continue
            if request["status"] in ("accepted", "unfulfilled"):
                candidates.append(request)
            elif request["status"] == "pending" and body.include_pending:
                candidates.append(request)
        if not candidates:
            return {
                "ok": True,
                "scheduled": 0,
                "unfulfilled": 0,
                "message": "Nothing to schedule. Approve a pending request or add a new one first.",
                "details": [],
            }
        scheduler = Scheduler(
            equipment=ctx.equipment,
            plots=ctx.plots,
            bookings=ctx.bookings,
            users_by_id=ctx.users_by_id,
            weather_days=ctx.weather_days,
            breakdowns=ctx.breakdowns,
            today=ctx.today,
        )
        outcome = scheduler.schedule(candidates)
        notes = {r["request"]["_id"]: r.get("priority_note", "") for r in outcome["results"]}
        details = []
        scheduled_count = 0
        unfulfilled_count = 0
        total_travel = 0.0
        for result in outcome["results"]:
            request = result["request"]
            plot = ctx.plots_by_id.get(request["plot_id"], {})
            previous_status = request["status"]
            if result["ok"]:
                booking = db.insert("bookings", result["booking"])
                explanation = build_booking_explanation(request, booking, ctx)
                db.update(
                    "requests",
                    request["_id"],
                    {
                        "status": "scheduled",
                        "booking_id": booking["_id"],
                        "explanation": explanation,
                        "priority_note": notes.get(request["_id"], ""),
                        "reason": "",
                        "suggestion": "",
                    },
                )
                scheduled_count += 1
                total_travel += float(booking.get("travel_km", 0))
                notify(
                    request["farmer_id"],
                    f"{'Approved & scheduled' if previous_status == 'pending' else 'Scheduled'}: {plot.get('name')}",
                    explanation,
                    "success",
                    request["_id"],
                    booking["_id"],
                )
                details.append(
                    {
                        "request_id": request["_id"],
                        "plot_name": plot.get("name"),
                        "farmer_name": ctx.users_by_id.get(request["farmer_id"], {}).get("name"),
                        "operation": request["operation"],
                        "status": "scheduled",
                        "priority_note": notes.get(request["_id"], ""),
                        "explanation": explanation,
                        "machine_name": result["machine"]["name"],
                        "booking": booking_public(booking, ctx),
                    }
                )
            else:
                suggestion = scheduler.suggestion_for(request)
                reason = result["reason"]
                db.update(
                    "requests",
                    request["_id"],
                    {
                        "status": "unfulfilled",
                        "booking_id": None,
                        "reason": reason,
                        "explanation": reason,
                        "suggestion": suggestion,
                        "priority_note": "",
                    },
                )
                unfulfilled_count += 1
                notify(
                    request["farmer_id"],
                    f"Could not schedule {plot.get('name')}",
                    f"{reason} {suggestion}",
                    "danger",
                    request["_id"],
                )
                details.append(
                    {
                        "request_id": request["_id"],
                        "plot_name": plot.get("name"),
                        "farmer_name": ctx.users_by_id.get(request["farmer_id"], {}).get("name"),
                        "operation": request["operation"],
                        "status": "unfulfilled",
                        "reason": reason,
                        "suggestion": suggestion,
                    }
                )
        if unfulfilled_count:
            notify(
                user["_id"],
                "Some jobs could not be scheduled",
                f"{unfulfilled_count} request{'s' if unfulfilled_count != 1 else ''} did not fit before "
                f"the deadline. Open the requests list to see the reason and suggested alternatives.",
                "warning",
            )
        final_ctx = load_ctx()
        problems = validate_schedule(
            final_ctx.bookings,
            final_ctx.equipment,
            final_ctx.plots,
            final_ctx.weather_days,
            final_ctx.breakdowns,
            check_blocks=True,
        )
        return {
            "ok": not problems,
            "scheduled": scheduled_count,
            "unfulfilled": unfulfilled_count,
            "travel_km": round(total_travel, 1),
            "message": (
                f"Scheduled {scheduled_count} job{'s' if scheduled_count != 1 else ''}"
                + (f", {unfulfilled_count} could not be served." if unfulfilled_count else ".")
            ),
            "details": details,
            "integrity": {"ok": not problems, "problems": problems},
        }


# ------------------------------------------------------------------ bookings
class MoveIn(BaseModel):
    date: str
    start_time: str
    note: str | None = None


@app.post("/api/bookings/{booking_id}/move")
def move_booking(booking_id: str, body: MoveIn, user: dict = Depends(require_owner)):
    with WRITE_LOCK:
        ctx = load_ctx()
        booking = db.get("bookings", booking_id)
        if not booking:
            raise HTTPException(status_code=404, detail="Booking not found.")
        machine = ctx.equipment_by_id.get(booking["equipment_id"])
        if not machine or machine.get("owner_id") != user["_id"]:
            raise HTTPException(status_code=403, detail="This machine belongs to another owner.")
        request = ctx.requests_by_id.get(booking["request_id"])
        plot = ctx.plots_by_id.get(booking["plot_id"], {})
        if not request or not plot:
            raise HTTPException(status_code=404, detail="The related request was not found.")
        try:
            new_date = date.fromisoformat(body.date).isoformat()
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Pick a valid date.") from exc
        try:
            datetime.strptime(body.start_time, "%H:%M")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Start time must look like 08:30.") from exc
        fields = place_manual(
            request=request,
            machine=machine,
            plot=plot,
            day_bookings=[
                b for b in ctx.bookings
                if b.get("equipment_id") == machine["_id"] and b.get("date") == new_date
            ],
            plot_by_id=ctx.plots_by_id,
            new_date=new_date,
            new_start=body.start_time,
            weather_days=ctx.weather_days,
            breakdowns=ctx.breakdowns,
            ignore_booking_id=booking_id,
        )
        old_text = f"{fmt_date(booking['date'])} {booking['start_time']}–{booking['end_time']}"
        db.update("bookings", booking_id, {**fields, "created_by": "manual"})
        updated = db.get("bookings", booking_id)
        explanation = build_booking_explanation(request, updated, ctx)
        db.update(
            "requests",
            request["_id"],
            {
                "status": "rescheduled",
                "explanation": explanation,
                "reason": "",
                "suggestion": "",
            },
        )
        new_text = f"{fmt_date(new_date)} {fields['start_time']}–{fields['end_time']}"
        note = (body.note or "").strip() or "The owner adjusted the timing."
        notify(
            booking["farmer_id"],
            f"Time changed: {plot.get('name')}",
            f"Your {request['operation']} job with {machine.get('name')} moved from {old_text} to "
            f"{new_text}. {note} Travel ({fields['travel_time']} min) and setup (30 min) are included. "
            f"{explanation}",
            "warning",
            request["_id"],
            booking_id,
        )
        problems = validate_schedule(
            load_ctx().bookings,
            ctx.equipment,
            ctx.plots,
            ctx.weather_days,
            ctx.breakdowns,
            check_blocks=True,
        )
        return {
            "ok": not problems,
            "booking": booking_public(updated, load_ctx()),
            "message": f"Moved to {new_text}.",
            "integrity": {"ok": not problems, "problems": problems},
        }


@app.get("/api/equipment/{equipment_id}/availability")
def availability(equipment_id: str, day: str = Query(alias="date"), user: dict = Depends(current_user)):
    ctx = load_ctx()
    machine = ctx.equipment_by_id.get(equipment_id)
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found.")
    try:
        date.fromisoformat(day)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Use a valid date.") from exc
    rows = [
        b for b in ctx.bookings
        if b["equipment_id"] == equipment_id and b["date"] == day
    ]
    rows.sort(key=lambda b: b["occupied_start"])
    return {
        "equipment": equipment_public(machine, ctx),
        "date": day,
        "weather_block": next((public(w) for w in ctx.weather if w["date"] == day), None),
        "broken": is_broken(equipment_id, day, ctx.breakdowns),
        "bookings": [booking_public(b, ctx) for b in rows],
        "workday": {"start": "07:00", "end": "19:00"},
    }


# --------------------------------------------------------------- disruptions
class RainIn(BaseModel):
    start_date: str
    end_date: str
    reason: str | None = None


class BreakdownIn(BaseModel):
    equipment_id: str
    start_date: str
    end_date: str
    note: str | None = None


def _valid_range(start: str, end: str, max_days: int = 60) -> tuple[date, date]:
    try:
        s = date.fromisoformat(start)
        e = date.fromisoformat(end)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Use valid dates (YYYY-MM-DD).") from exc
    if e < s:
        raise HTTPException(status_code=400, detail="The end date cannot be before the start date.")
    if (e - s).days > max_days:
        raise HTTPException(status_code=400, detail=f"Keep the range to {max_days} days or less.")
    return s, e


@app.post("/api/disruptions/rain")
def simulate_rain(body: RainIn, user: dict = Depends(require_owner)):
    s, e = _valid_range(body.start_date, body.end_date, 21)
    reason = (body.reason or "Heavy rain — fields too wet for machinery.").strip()
    with WRITE_LOCK:
        result = apply_rain(s.isoformat(), e.isoformat(), reason, user)
    return result


@app.post("/api/disruptions/breakdown")
def simulate_breakdown(body: BreakdownIn, user: dict = Depends(require_owner)):
    machine = db.get("equipment", body.equipment_id)
    if not machine or machine.get("owner_id") != user["_id"]:
        raise HTTPException(status_code=404, detail="Machine not found.")
    s, e = _valid_range(body.start_date, body.end_date, 90)
    note = (body.note or "Unexpected machine breakdown.").strip()
    with WRITE_LOCK:
        result = apply_breakdown(body.equipment_id, s.isoformat(), e.isoformat(), note, user)
    return result


# --------------------------------------------------------------- notifications
@app.post("/api/notifications/read-all")
def read_all(user: dict = Depends(current_user)):
    with WRITE_LOCK:
        rows = db.find("notifications", {"user_id": user["_id"], "read": False})
        for row in rows:
            db.update("notifications", row["_id"], {"read": True})
    return {"ok": True, "marked": len(rows)}


@app.post("/api/notifications/{notification_id}/read")
def read_one(notification_id: str, user: dict = Depends(current_user)):
    row = db.get("notifications", notification_id)
    if not row or row.get("user_id") != user["_id"]:
        raise HTTPException(status_code=404, detail="Notification not found.")
    db.update("notifications", notification_id, {"read": True})
    return {"ok": True}


@app.post("/api/demo/reset")
def demo_reset(user: dict = Depends(current_user)):
    with WRITE_LOCK:
        reset_demo()
    return {
        "ok": True,
        "message": "Demo data was reset. Please log in again — your old session is no longer valid.",
    }


# --------------------------------------------------------------- static app
if config.FRONTEND_DIST.exists():
    assets_dir = config.FRONTEND_DIST / "assets"
    if assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

    @app.get("/{full_path:path}")
    def serve_frontend(full_path: str):
        if full_path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not found.")
        candidate = (config.FRONTEND_DIST / full_path).resolve()
        try:
            candidate.relative_to(config.FRONTEND_DIST.resolve())
        except ValueError:
            raise HTTPException(status_code=404, detail="Not found.")
        if candidate.is_file():
            return FileResponse(candidate)
        return FileResponse(config.FRONTEND_DIST / "index.html")
else:

    @app.get("/")
    def root_hint():
        return {
            "app": "FieldShare API",
            "message": "Backend is running. Start the React dev server (frontend: npm run dev) "
                       "or build it with npm run build to serve the full app here.",
            "api": "/api/health",
        }
